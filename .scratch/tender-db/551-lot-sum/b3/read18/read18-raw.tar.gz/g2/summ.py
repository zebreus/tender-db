import json,sys
d=json.load(open(sys.argv[1]))
for k in ('id','title','value','value_derivation','lots','procedure_key','source','kind','procedure_type','publication_id'): print(k, d.get(k))
print('amounts'); [print(' ',a) for a in d['amounts']]
print('lot_details'); [print(' ',l['lot_key'],(l.get('title') or '')[:80],l.get('value'),l.get('kind')) for l in d['lot_details']]
print('lot_results'); [print(' ',r['lot'],r['key'],r['notice_id'],r['awarded'],r['decided'],r['decision'],[w['organization_name'] for w in r['winners']]) for r in d['lot_results']]
print('versions'); [print(' ',v['seq'],v['caused_by_notice_id'],v['publication_id'],v['published_at'],v['notice_subtype']) for v in d['versions']]
print('contracts', len(d['contracts'])); [print(' ',c) for c in d['contracts'][:40]]
print('bids', len(d['bids'])); [print(' ',c) for c in d['bids'][:40]]
