import json,sys
KEEP=('LOT_NO','ITEM','CONTRACT_NO','TED-FORM','NO_DOC_OJS','NB_TENDERS_RECEIVED','AWARDED_TO_GROUP','OFFICIALNAME','DATE_CONCLUSION','LOT_NUMBER','BT-13713','BT-137','BT-161','BT-27','BT-720','BT-709','BT-660','BT-1118','BT-118','BT-150','BT-3202','BT-500','BT-142','BT-145','BT-151','NO_AWARDED','PROCUREMENT_UNSUCCESSFUL','NO_AWARDED_CONTRACT','AWARDED_CONTRACT','NOTICE_TYPE','BT-02','BT-03','TITLE','DIRECTIVE','HEADING','MODIFICATION','REF_NOTICE','NOTICE_NUMBER_OJ','BT-758','BT-1252','BT-125','OPP-090','NOTICE_UUID')
def val(v):
    if v.get('type')=='amount':
        return f"{v['cents']/100:,.2f} {v.get('currency')}"
    for k in ('value','code'):
        if k in v: return repr(v[k])[:90]
    return json.dumps(v)[:150]
full='-a' in sys.argv
for fn in sys.argv[1:]:
    if fn.startswith('-'): continue
    d=json.load(open(fn))
    print('=== notice',d['notice_id'])
    for s in d['sections']:
        out=[]
        for v in s['values']:
            f=v.get('field_id','')
            if f.startswith('TED-TI_'): continue
            if full or v.get('type')=='amount' or any(x in f for x in KEEP):
                if 'TITLE' in f and v.get('lang') not in (None,'EN','ET','DE','FR') : pass
                out.append(f'{f}={val(v)}')
        print(f'  [{s["kind"]} {s["section_id"]} <- {s.get("parent_section_id")}]', '; '.join(out))
