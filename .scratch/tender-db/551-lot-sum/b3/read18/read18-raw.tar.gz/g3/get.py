import fcntl, os, ssl, sys, time, urllib.error, urllib.request
API='https://tenders.zebreus.click'
D=os.path.dirname(os.path.abspath(__file__))
RAW=D+'/raw'
STAMP=os.path.join(D,'..','.last_get')
LOCK=os.path.join(D,'..','.last_get.lock')
GAP=2.1
ctx=ssl.create_default_context(cafile=os.environ.get('SSL_CERT_FILE') or None)
def wait():
    with open(LOCK,'a') as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        try: last=float(open(STAMP).read())
        except Exception: last=0.0
        d=time.time()-last
        if d<GAP: time.sleep(GAP-d)
        open(STAMP,'w').write(repr(time.time()))
        fcntl.flock(lk, fcntl.LOCK_UN)
def get(path):
    tries=0
    while True:
        wait()
        req=urllib.request.Request(API+path,headers={'Accept':'application/json','User-Agent':'tender-db issue-551 read18 g3'})
        try:
            with urllib.request.urlopen(req,timeout=90,context=ctx) as r: code,body=r.status,r.read()
        except urllib.error.HTTPError as e: code,body=e.code,e.read()
        if code==408 and tries==0:
            tries+=1; time.sleep(4); continue
        return code,body
force='--force' in sys.argv
for p in sys.argv[1:]:
    if p=='--force': continue
    fn=RAW+'/'+p.strip('/').replace('/','_')+'.json'
    if os.path.exists(fn) and not force: print('cached',fn); continue
    code,body=get(p)
    open(fn,'wb').write(body)
    print(code,len(body),fn,flush=True)
