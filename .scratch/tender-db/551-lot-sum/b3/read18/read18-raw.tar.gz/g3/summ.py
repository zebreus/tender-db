import json, sys, re
pat = re.compile(sys.argv[2]) if len(sys.argv) > 2 else re.compile(r'VAL|LOT_NO|AWARD|CONTRACT_NO|TITLE|AMOUNT|BT-|MODIF|INFO_ADD|SHORT_DESCR|PERCENT|CURRENCY|DATE_CONCL|NB_TENDERS|LOT_NUMBER|NOTICE')
d = json.load(open(sys.argv[1]))
for s in d['sections']:
    print('==', s.get('kind'), s.get('section_id'), 'parent=', s.get('parent_section_id'))
    for v in s['values']:
        if pat.search(v['field_id']):
            val = v.get('value', v.get('code'))
            if isinstance(val, str) and len(val) > 250: val = val[:250] + '...'
            extra = {k: v[k] for k in v if k not in ('field_id', 'value', 'ordinal', 'type', 'lang', 'is_ref', 'scheme', 'code')}
            print('  ', v['field_id'], v.get('ordinal'), repr(val), extra if extra else '')
