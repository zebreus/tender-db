import os, ssl, sys, time, fcntl, urllib.error, urllib.request
API='https://tenders.zebreus.click'
D=os.path.dirname(os.path.abspath(__file__))
RAW=D+'/raw'
STAMP=os.path.join(D,'..','.last_get')
LOCK=os.path.join(D,'..','.last_get.lock')
GAP=2.1
ctx=ssl.create_default_context(cafile=os.environ.get('SSL_CERT_FILE') or None)
def get1(path):
    with open(LOCK,'a') as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        try: last=float(open(STAMP).read())
        except Exception: last=0.0
        d=time.time()-last
        if d<GAP: time.sleep(GAP-d)
        open(STAMP,'w').write(repr(time.time()))
        fcntl.flock(lf, fcntl.LOCK_UN)
    req=urllib.request.Request(API+path,headers={'Accept':'application/json','User-Agent':'tender-db issue-551 read18 skeptic 6595330'})
    try:
        with urllib.request.urlopen(req,timeout=90,context=ctx) as r: return r.status,r.read()
    except urllib.error.HTTPError as e: return e.code,e.read()
def get(path):
    code,body=get1(path)
    if code==408: code,body=get1(path)
    return code,body
for p in sys.argv[1:]:
    fn=RAW+'/'+p.strip('/').replace('/','_')+'.json'
    if os.path.exists(fn): print('cached',fn); continue
    code,body=get(p)
    open(fn,'wb').write(body)
    print(code,len(body),fn)
