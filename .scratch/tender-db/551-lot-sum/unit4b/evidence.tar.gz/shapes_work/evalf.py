import json, sys
rows = json.load(open(sys.argv[1]))
feats = sorted({k for r in rows.values() if 'f' in r for k, v in r['f'].items() if isinstance(v, bool)})
have = [r for r in rows.values() if 'f' in r]
W = [r for r in have if r['verdict'] == 'wrong']
N = [r for r in have if r['verdict'] == 'neutral']
R = [r for r in have if r['verdict'] == 'right']
print(f'have {len(have)}: wrong {len(W)} neutral {len(N)} right {len(R)}')
show = sys.argv[2:] if len(sys.argv) > 2 else None
for k in feats:
    w = [r['id'] for r in W if r['f'][k]]
    n = [r['id'] for r in N if r['f'][k]]
    rt = [r['id'] for r in R if r['f'][k]]
    print(f'{k:28s} W {len(w):3d} N {len(n):2d} R {len(rt):3d}')
    if show and k in show:
        print('   W:', w)
        print('   N:', n)
        print('   R:', rt)
