#!/bin/bash
# sequential, >=2.5 s between GETs, a 408 retried at most once
cd "$(dirname "$0")"
while read -r id; do
  [ -z "$id" ] && continue
  [ -s "api/$id.json" ] && continue
  code=$(curl -sS -o "api/$id.tmp" -w '%{http_code}' --max-time 40 "https://tenders.zebreus.click/v1/tenders/$id")
  if [ "$code" = "408" ]; then sleep 5; code=$(curl -sS -o "api/$id.tmp" -w '%{http_code}' --max-time 40 "https://tenders.zebreus.click/v1/tenders/$id"); fi
  if [ "$code" = "200" ]; then mv "api/$id.tmp" "api/$id.json"; else echo "$id $code" >> fetch_errors.txt; rm -f "api/$id.tmp"; fi
  sleep 2.5
done < missing_ids.txt
echo FETCH-DONE
