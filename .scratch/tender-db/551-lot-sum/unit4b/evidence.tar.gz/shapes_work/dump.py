import json, sys
d=json.load(open(sys.argv[1]))
items={}; checks={}
for gr in d['groups']:
    for it in gr['items']: items[it['id']]=it
    for c in gr['checks']: checks[c['id']]=c
f=d['final']
sel=sys.argv[2]  # e.g. wrong:not_additive
verdict,cls=sel.split(':')
out=[]
for k,v in f.items():
    if v['verdict']!=verdict: continue
    if cls!='*' and v['class']!=cls: continue
    it=items[int(k)]
    out.append(f"=== {k} [{v['verdict']}/{v['class']}/{v['group']}] (first: {it['verdict']}/{it['class']})\nOLD: {it['old_figure']}\nSTATED: {it['stated_total']}\nWHY: {it['why']}")
    c=checks.get(int(k))
    if c:
        out.append(f"CHECK: refuted={c['verify'].get('refuted')} {c['verify'].get('verdict')}/{c['verify'].get('class')}: {c['verify']['why']}")
print("\n".join(out))
