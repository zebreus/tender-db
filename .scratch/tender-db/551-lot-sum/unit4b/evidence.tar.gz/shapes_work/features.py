"""Per-tender mechanical features of the path-W summed award set (issue 551 unit 4b shapes).

Reads each labelled tender's /v1/tenders/{id} detail (cached post-drain copies first, fresh
fetches second), rebuilds path W's LotSums awards set (each counted lot's LATEST award by notice
id, figure > 10.00 and not a sentinel), and computes observable features of that set.
Usage: python3 -I features.py <read_result.json> <cache_index.json> <api_dir> <out.json>
"""
import json, sys, os, re, collections, itertools

RR, IDX, API, OUT = sys.argv[1:5]
rr = json.load(open(RR))
idx = json.load(open(IDX))
final = rr['final']

FLOOR = 1000


def sentinel(c):
    if c <= 0:
        return True
    if c in (1, 100):
        return True
    major = str(c // 100)
    return len(major) >= 7 and len(set(major)) == 1 and c % 100 == 0


def load(tid):
    for p in idx.get(tid, []):
        try:
            return json.load(open(p)), 'cache'
        except Exception:
            pass
    p = os.path.join(API, f'{tid}.json')
    if os.path.exists(p):
        return json.load(open(p)), 'fresh'
    return None, None


def near(a, b, tol=0.01):
    return a > 0 and b > 0 and abs(a - b) <= tol * max(a, b)


def lotnum(key):
    k = key.strip()
    d = k[3:].lstrip('-_ ') if k[:3].lower() == 'lot' else k
    return d.lstrip('0') or '0' if d.isdigit() else None


def norm_title(t):
    return re.sub(r'\W+', ' ', (t or '').lower()).strip()


rows = {}
for tid, lab in final.items():
    x, src = load(tid)
    r = {'id': int(tid), 'verdict': lab['verdict'], 'class': lab['class'], 'group': lab['group'], 'src': src}
    rows[tid] = r
    if x is None:
        r['missing'] = True
        continue
    lots = {l['lot_key']: l for l in x.get('lot_details', [])}
    unit = 'Lot' if any(l['kind'] == 'Lot' for l in lots.values()) else 'Part'
    counted = {k for k, l in lots.items() if l['kind'] == unit}
    excluded = {k for k, l in lots.items() if l['kind'] != unit}
    # path W: latest award per lot by notice id, per currency
    by_cur = collections.defaultdict(dict)
    results_by_lot = collections.defaultdict(list)
    for lr in x.get('lot_results', []):
        if lr.get('lot'):
            results_by_lot[lr['lot']].append(lr)
        a = lr.get('awarded')
        if not lr.get('lot') or not a or a.get('cents') is None:
            continue
        if lr['lot'] in excluded or a['cents'] <= FLOOR or sentinel(a['cents']):
            continue
        cur = by_cur[a['currency']]
        prev = cur.get(lr['lot'])
        if prev is None or lr['notice_id'] >= prev['notice_id']:
            cur[lr['lot']] = lr
    if not by_cur:
        r['no_awards'] = True
        continue
    served = x.get('value') or {}
    cur = served.get('currency') if served.get('currency') in by_cur else max(by_cur, key=lambda c: (len(by_cur[c]), c))
    A = by_cur[cur]
    S = sum(lr['awarded']['cents'] for lr in A.values())
    r.update(currency=cur, n=len(A), S=S, served=served.get('cents'), served_cur=served.get('currency'),
             derived=bool(x.get('value_derivation')), reproduces=(served.get('cents') == S),
             source=x.get('source'), procedure_type=x.get('procedure_type'), country=x.get('country'),
             other_currency_awards=len(by_cur) > 1)
    figs = sorted((lr['awarded']['cents'] for lr in A.values()), reverse=True)
    r['max_share'] = figs[0] / S
    r['max_over_second'] = figs[0] / figs[1] if len(figs) > 1 and figs[1] else None
    # amounts
    amt = collections.defaultdict(lambda: collections.defaultdict(list))
    lotnull = []
    for a in x.get('amounts', []):
        if a['value']['currency'] != cur:
            continue
        if a['lot'] is None:
            lotnull.append((a['field'], a['value']['cents']))
        else:
            amt[a['field']][a['lot']].append(a['value']['cents'])
    est = {k: max(v) for k, v in amt['estimated_value'].items()}
    est_min = {k: min(v) for k, v in amt['estimated_value'].items()}
    bt709 = {k: max(v) for k, v in amt['result_framework_maximum'].items()}
    bt660 = {k: max(v) for k, v in amt['result_framework_reestimate'].items()}
    bt271 = {k: max(v) for k, v in amt['framework_maximum'].items()}
    r['lotnull'] = lotnull
    # bids per (notice, lot)
    bids = collections.defaultdict(list)
    for b in x.get('bids', []):
        v = b.get('value')
        if v and v.get('cents') and v['currency'] == cur:
            tenderers = tuple(sorted(p.get('organization_id') or p.get('mention_name') for p in b.get('parties', []) if p.get('role') == 'tenderer'))
            bids[(b['notice_id'], b['lot'])].append((v['cents'], tenderers))
    notices_of = collections.Counter(lr['notice_id'] for lr in A.values())
    # valued lot results per notice (any lot)
    valued_per_notice = collections.Counter()
    for lr in x.get('lot_results', []):
        a = lr.get('awarded')
        if lr.get('lot') and a and a.get('cents') and a['cents'] > FLOOR:
            valued_per_notice[lr['notice_id']] += 1
    subtypes = {v['caused_by_notice_id']: v.get('notice_subtype') for v in x.get('versions', [])}
    f = {}
    per = []
    winners_by_lot = {}
    for lot, lr in A.items():
        c = lr['awarded']['cents']
        wins = {w.get('organization_id') or w.get('organization_name') for w in lr.get('winners', [])}
        winners_by_lot[lot] = frozenset(wins)
        bl = bids.get((lr['notice_id'], lot), [])
        bvals = [b[0] for b in bl]
        later = [o for o in results_by_lot[lot] if o['notice_id'] > lr['notice_id']]
        earlier = [o for o in results_by_lot[lot] if o['notice_id'] < lr['notice_id'] and o.get('awarded') and o['awarded'].get('cents')]
        p = dict(lot=lot, cents=c, notice=lr['notice_id'], decision=lr.get('decision'), n_winners=len(wins),
                 n_valued_bids=len(bvals), bids_sum=sum(bvals), bids_equal=len(bvals) >= 2 and len(set(bvals)) < len(bvals),
                 award_eq_bid_sum=len(bvals) >= 2 and near(c, sum(bvals), 0.001),
                 award_gt_bid_sum=bool(bvals) and c > sum(bvals) * 1.01,
                 est=est.get(lot), est_min=est_min.get(lot), bt709=bt709.get(lot), bt660=bt660.get(lot), bt271=bt271.get(lot),
                 later_closed=any((o.get('decision') or '').startswith('clos') or (not o.get('winners') and not (o.get('awarded') or {}).get('cents')) for o in later),
                 earlier=[o['awarded']['cents'] for o in earlier],
                 title=norm_title(lots.get(lot, {}).get('title')), counted=lot in counted,
                 notice_single=valued_per_notice[lr['notice_id']] == 1, subtype=subtypes.get(lr['notice_id']))
        per.append(p)
    r['per'] = per
    # ---- features ----
    f['clos_nw'] = any((p['decision'] or '').startswith('clos') or p['n_winners'] == 0 for p in per)
    f['later_closed'] = any(p['later_closed'] for p in per)
    f['multiwin'] = any(p['n_winners'] >= 2 for p in per)
    f['multi_valued_bids'] = any(p['n_valued_bids'] >= 2 for p in per)
    f['award_eq_bid_sum'] = any(p['award_eq_bid_sum'] for p in per)
    f['bids_equal'] = any(p['bids_equal'] for p in per)
    f['award_gt_bid_sum'] = any(p['award_gt_bid_sum'] for p in per)
    f['gt_bt709'] = any(p['bt709'] and p['cents'] > 1.05 * p['bt709'] for p in per)
    f['gt2_bt709'] = any(p['bt709'] and p['cents'] >= 1.9 * p['bt709'] for p in per)
    f['ge10_est'] = any(p['est'] and p['cents'] >= 10 * p['est'] for p in per)
    f['ge10_est_min'] = any(p['est_min'] and p['cents'] >= 10 * p['est_min'] for p in per)
    f['ge3_est'] = any(p['est'] and p['cents'] >= 3 * p['est'] for p in per)
    f['ge15_est'] = any(p['est'] and p['cents'] >= 1.5 * p['est'] for p in per)
    est_all = [v for v in est.values()]
    f['award_eq_est_total'] = len(est) >= 2 and any(near(p['cents'], sum(est_all), 0.005) for p in per)
    # same winner on 2+ summed lots
    cnt = collections.Counter(w for ws in winners_by_lot.values() for w in ws)
    f['same_winner_2lots'] = any(v >= 2 for v in cnt.values())
    f['identical_winner_sets'] = len([ws for ws in winners_by_lot.values() if ws]) != len({ws for ws in winners_by_lot.values() if ws})
    titles = [p['title'] for p in per if p['title']]
    f['dup_title'] = len(titles) != len(set(titles))
    f['cross_notice'] = len(notices_of) >= 2
    f['all_single_lot_notices'] = all(p['notice_single'] for p in per)
    # a notice contributing >=2 summed awards beside a notice contributing exactly 1 (mixed)
    f['mixed_notice'] = len(notices_of) >= 2 and max(notices_of.values()) >= 2 and min(notices_of.values()) == 1
    keys = list(A)
    ted_keys = [k for k in keys if re.fullmatch(r'LOT-\d{1,3}', k)]
    f['ted_keys'] = bool(ted_keys) and len(ted_keys) == len(keys)
    f['ted_mixed_lot1'] = f['mixed_notice'] and any(p['lot'] == 'LOT-1' and notices_of[p['notice']] == 1 for p in per) and bool(ted_keys)
    f['lot0000'] = any(k in ('LOT-0000', 'LOT-0') for k in keys)
    f['all_modif'] = all((p['subtype'] or '') in ('38', '39', '40') for p in per)
    f['superseded'] = any(p['earlier'] for p in per)
    f['superseded_x'] = any(p['earlier'] and not any(near(p['cents'], e, 0.5) for e in p['earlier']) for p in per)
    # subset-sum: an award equals the sum of >=2 OTHER summed awards (any subset), n<=16
    sub = False
    vals = [(p['lot'], p['cents']) for p in per]
    if 3 <= len(vals) <= 16:
        for lot, c in vals:
            others = [v for l, v in vals if l != lot]
            for k in range(2, len(others) + 1):
                if any(near(c, sum(s), 0.002) for s in itertools.combinations(others, k)):
                    sub = True
                    break
            if sub:
                break
    f['subset_sum_awards'] = sub
    # an award equals the sum of every lot's figure in ANY one earlier round or kind (incl. its own)
    whole = False
    figure_sets = []
    for fld in ('estimated_value', 'result_framework_maximum', 'result_framework_reestimate', 'framework_maximum'):
        d = {k: max(v) for k, v in amt[fld].items()}
        if len(d) >= 2:
            figure_sets.append(sum(d.values()))
    rounds = collections.defaultdict(dict)
    for lr in x.get('lot_results', []):
        a = lr.get('awarded')
        if lr.get('lot') and a and a.get('cents') and a['cents'] > FLOOR and a['currency'] == cur:
            rounds[lr['notice_id']][lr['lot']] = a['cents']
    for nid, d in rounds.items():
        if len(d) >= 2:
            figure_sets.append(sum(d.values()))
    for p in per:
        if any(near(p['cents'], s, 0.005) for s in figure_sets):
            whole = True
    f['award_eq_whole'] = whole
    f['award_eq_lotnull'] = any(near(p['cents'], c, 0.0001) for p in per for _, c in lotnull)
    # the lot-null figure equal to an award comes from a notice awarding >=2 valued lots
    f['lotnull_from_multilot_notice'] = any(near(p['cents'], c, 0.0001) and valued_per_notice[p['notice']] >= 2 for p in per for _, c in lotnull)
    rv = [c for fld, c in lotnull if fld == 'result_value']
    f['rv_eq_award'] = any(near(p['cents'], c, 0.0001) for p in per for c in rv)
    f['rv_eq_award_multilot_notice'] = any(near(p['cents'], c, 0.0001) and valued_per_notice[p['notice']] >= 2 for p in per for c in rv)
    pf = [c for fld, c in lotnull if fld in ('estimated_value', 'framework_maximum')]
    f['proc_est_eq_award'] = any(near(p['cents'], c, 0.0001) for p in per for c in pf)
    # same contract id on two summed lots from different notices
    cids = collections.defaultdict(set)
    for k in x.get('contracts', []):
        if k.get('buyer_contract_id'):
            cids[k['notice_id']].add(k['buyer_contract_id'].strip().lower())
    f['same_contract_id'] = any(a['notice'] != b['notice'] and cids[a['notice']] & cids[b['notice']] and len(cids[a['notice']]) == 1 for a, b in itertools.combinations(per, 2))
    f['rekey_same_winners_modif'] = any(a['notice'] != b['notice'] and winners_by_lot[a['lot']] and winners_by_lot[a['lot']] == winners_by_lot[b['lot']] and (a['subtype'] in ('38','39','40') and b['subtype'] in ('38','39','40')) and (a['title'] == b['title'] or (cids[a['notice']] & cids[b['notice']])) for a, b in itertools.combinations(per, 2))
    f['g3_any_k'] = False
    if len(figs) >= 3:
        rest = S - figs[0]
        f['g3_any_k'] = any(near(figs[0], rest * 10 ** k, 0.01) for k in range(0, 4))
    f['dominant_slip'] = len(figs) >= 2 and figs[0] >= 10 * figs[1] and figs[0] / S >= 0.9
    f['dominant_slip_100'] = len(figs) >= 2 and figs[0] >= 100 * figs[1]
    f['exact10k_sibling'] = len(figs) >= 2 and any(near(a, b * 10 ** k, 0.001) for a in figs for b in figs if a != b for k in (1, 2, 3))
    f['tiny'] = S < 100000  # < 1,000.00 in native units
    f['dps'] = any(c.get('scheme') == 'dps' for c in x.get('classifications', []))
    f['has_bt709'] = bool(bt709)
    f['bt709_sum_lt_S'] = bool(bt709) and sum(bt709.get(p['lot'], 0) for p in per) > 0 and S > 1.5 * sum(bt709.get(p['lot'], 0) for p in per)
    f['bt709_same_all'] = len(bt709) >= 2 and len(set(bt709.values())) == 1
    f['est_sum_lt_S3'] = sum(est.get(p['lot'], 0) for p in per) > 0 and S > 3 * sum(est.get(p['lot'], 0) for p in per if est.get(p['lot']))
    f['n_versions'] = len(x.get('versions', []))
    f['ge15_est_min'] = any(p['est_min'] and p['cents'] >= 1.5 * p['est_min'] for p in per)
    f['ge10_est_min_incl'] = any(p['est_min'] and p['cents'] >= 9.99 * p['est_min'] for p in per)
    cents_list = [p['cents'] for p in per]
    f['identical_pair_any'] = len(cents_list) != len(set(cents_list))
    f['near_pair_cross_notice'] = any(a['notice'] != b['notice'] and a['cents'] != b['cents'] and near(a['cents'], b['cents'], 0.10) for a, b in itertools.combinations(per, 2))
    # procedure figure (lot-null, any field) equals a summed award that came from a NON-modification notice awarding >=2 valued lots
    nonmod = lambda q: (q['subtype'] or 'ted') not in ('38', '39', '40')
    f['procfig_eq_award_multilot'] = any(near(q['cents'], c, 0.0001) and valued_per_notice[q['notice']] >= 2 and nonmod(q) for q in per for _, c in lotnull)
    f['procfig_eq_award_multilot_any'] = any(near(q['cents'], c, 0.0001) and valued_per_notice[q['notice']] >= 2 for q in per for _, c in lotnull)
    pe = [c for fld, c in lotnull if fld == 'estimated_value']
    f['proc_est_eq_each_lot_est'] = len(est) >= 2 and any(all(near(v, c, 0.001) for v in est.values()) for c in pe)
    f['lot_est_all_equal'] = len(est) >= 2 and len(set(est.values())) == 1
    # TED single-section re-key on LOT-1: latest LOT-1 award from a 1-lot notice, beside >=1 multi-award notice,
    # and it is far from LOT-1's own earlier award (x1.5 either way) or within 10% of another summed lot
    def far_from_earlier(q):
        return bool(q['earlier']) and all(not (e / 1.5 <= q['cents'] <= e * 1.5) for e in q['earlier'])
    f['ted_rekey'] = f['ted_mixed_lot1'] and any(q['lot'] == 'LOT-1' and notices_of[q['notice']] == 1 and (far_from_earlier(q) or any(o['lot'] != q['lot'] and near(o['cents'], q['cents'], 0.10) for o in per)) for q in per)
    f['ted_rekey_any_earlier_far'] = f['ted_mixed_lot1'] and any(q['lot'] == 'LOT-1' and notices_of[q['notice']] == 1 and far_from_earlier(q) for q in per)
    f['rekey_eforms'] = any(a['notice'] != b['notice'] and winners_by_lot[a['lot']] and winners_by_lot[a['lot']] == winners_by_lot[b['lot']] and a['title'] and a['title'] == b['title'] for a, b in itertools.combinations(per, 2))
    # multi-winner parallel offers: a summed lot award = sum of >=2 valued bids with max/min <= 1.6
    def disp(q):
        bl = [b[0] for b in bids.get((q['notice'], q['lot']), [])]
        return max(bl) / min(bl) if len(bl) >= 2 and min(bl) > 0 else None
    f['parallel_offers'] = any(q['award_eq_bid_sum'] and disp(q) is not None and disp(q) <= 1.6 for q in per)
    f['parallel_offers_25'] = any(q['award_eq_bid_sum'] and disp(q) is not None and disp(q) <= 2.5 for q in per)
    # equal bids equal to the lot's own ceiling/estimate (copy of one ceiling per supplier)
    def ceil_copy(q):
        bl = [b[0] for b in bids.get((q['notice'], q['lot']), [])]
        dup = {v for v in bl if bl.count(v) >= 2}
        refs = [v for v in (q['bt709'], q['bt660'], q['est'], q['est_min'], q['bt271']) if v]
        return bool(dup) and any(near(d, r, 0.001) for d in dup for r in refs)
    f['equal_bids_eq_ceiling'] = any(ceil_copy(q) for q in per)
    big = max(per, key=lambda q: q['cents'])
    allnull = [c for _, c in lotnull]
    f['rv_eq_largest_multilot_half'] = any(near(big['cents'], c, 0.0001) for c in rv) and valued_per_notice[big['notice']] >= 2 and big['cents'] >= S - big['cents']
    f['proc_eq_largest_multilot_half'] = any(near(big['cents'], c, 0.0001) for c in allnull) and valued_per_notice[big['notice']] >= 2 and big['cents'] >= S - big['cents']
    f['rv_eq_largest_multilot_nonmod'] = any(near(big['cents'], c, 0.0001) for c in rv) and valued_per_notice[big['notice']] >= 2 and nonmod(big)
    f['proc_eq_largest_multilot_half_nonmod'] = f['proc_eq_largest_multilot_half'] and nonmod(big)
    f['rekey_value_trajectory'] = any(a['notice'] != b['notice'] and winners_by_lot[a['lot']] and winners_by_lot[a['lot']] == winners_by_lot[b['lot']]
        and any(near(a['cents'], v, 0.15) for v in [b['cents']] + b['earlier']) for a, b in itertools.permutations(per, 2))
    f['multiwin_sum_no_ref_or_over'] = any(q['award_eq_bid_sum'] and not (any(r for r in (q['bt709'], q['bt660'])) and q['cents'] <= 1.05 * max(r for r in (q['bt709'], q['bt660']) if r)) for q in per)
    f['award_n_times_ref'] = any(q['n_winners'] >= 2 and any(r and near(q['cents'], r * q['n_winners'], 0.001) for r in (q['bt709'], q['bt660'], q['est'], q['bt271'])) for q in per)
    r['f'] = f

json.dump(rows, open(OUT, 'w'), indent=0, default=list)
print('rows', len(rows), 'missing', sum(1 for r in rows.values() if r.get('missing')),
      'no_awards', sum(1 for r in rows.values() if r.get('no_awards')))
rep = [r for r in rows.values() if 'S' in r and r['derived']]
print('derived', len(rep), 'reproduce S==served', sum(1 for r in rep if r['reproduces']))
print('non-reproducing derived:', [(r['id'], r['S'], r['served']) for r in rep if not r['reproduces']][:20])
