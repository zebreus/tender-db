import json, sys
d=json.load(open(sys.argv[1]))
items={}; checks={}
for gr in d['groups']:
    for it in gr['items']: items[it['id']]=it
    for c in gr['checks']: checks[c['id']]=c
f=d['final']
verdict,cls=sys.argv[2].split(':')
skip=set(sys.argv[3].split(',')) if len(sys.argv)>3 else set()
lim=int(sys.argv[4]) if len(sys.argv)>4 else 600
for k,v in f.items():
    if k in skip or v['verdict']!=verdict or (cls!='*' and v['class']!=cls): continue
    it=items[int(k)]
    print(f"=== {k} [{v['verdict']}/{v['class']}/{v['group']}] (first {it['verdict']}/{it['class']})\nSTATED: {it['stated_total'][:300]}\nWHY: {it['why']}")
    c=checks.get(int(k))
    if c:
        vv=c['verify']; print(f"CHECK({vv.get('refuted')},{vv.get('verdict')}/{vv.get('class')}): {vv['why'][:lim]}")
