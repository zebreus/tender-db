"""Run unit 3's merge_rule.serve (path V + path W, the drained rule) on unit 1's 4,745 records; list the path-W fires
with the ctx-only facts the W2 guards can read. Read-only on the repo (run with python3 -I -B)."""
import json, os, sys, collections
U3 = '/home/user/tender-db/.scratch/tender-db/551-lot-sum/unit3'
sys.path.insert(0, U3)
import merge_rule as M  # noqa: E402
E = M.E
ctx = M.load_ctx()
recs = {}
for l in open(os.path.join(U3, '..', 'results-slim.jsonl')):
    r = json.loads(l)
    recs[r['id']] = r
out = {}
why = collections.Counter()
for tid, e in ctx.items():
    rates = M.rates_of(e)
    o = M.serve(e, rates)
    why[o['why']] += 1
    if o['derived'] and o['derived']['path'] == 'lot-sum-awards':
        versions, head, partners = M.build(e)
        by = M.lot_sums_by_currency(head)
        cur = o['derived']['currency']
        ls = by[cur]
        per = M.per_lot(ls, E.AWARDS)
        est = M.per_lot(ls, E.ESTIMATE)
        keys = e['keys']
        # award history per lot (all rounds, this currency)
        hist = collections.defaultdict(list)
        for rnd in head.rounds:
            for r in rnd.lot_results:
                if r.lot_key is not None and r.currency == cur and r.cents is not None:
                    hist[r.lot_key].append((rnd.notice_id, r.cents))
        latest = {lot: ls.awards[lot][0] for lot in per}
        p10 = any(c >= 10 * c0 or c * 10 <= c0 for lot, c in per.items() for (nid, c0) in hist[lot]
                  if nid < latest[lot] and c0 > 1000)
        e10 = any(lot in est and c >= 10 * est[lot] for lot, c in per.items())
        S = o['derived']['cents']
        allest = list(est.values()) + [f.cents for f in head.facts if f.field == 'estimated_value' and f.currency == cur and f.cents > 1000]
        out[tid] = dict(pop=recs[tid]['pop'], today=o['today'], eur=o['eur'], cur=cur, S=S, n=o['derived']['lots'],
                        lots={str(k): v for k, v in per.items()}, lot_keys={str(k): keys.get(k) for k in per},
                        latest_notice={str(k): v for k, v in latest.items()},
                        P10=p10, E=e10, tiny=S < 100000, est_branch=(bool(allest) and S > 10 * max(allest)),
                        est_sum_lt_S3=(sum(est.get(l, 0) for l in per) > 0 and S > 3 * sum(est.get(l, 0) for l in per if est.get(l))))
print('records', len(ctx))
print('why', why.most_common())
print('path W fires', len(out))
for t, o in sorted(out.items()):
    print(t, json.dumps(o))
json.dump({str(k): v for k, v in out.items()}, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'w_fires.json'), 'w'), indent=1)
