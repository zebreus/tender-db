"""Prepare a unified part-3-schema extraction ('px') over all 279 labelled ids.
Writes px/tenders/<id>.json (symlink to the detail each part used), px/notice_cache_index.json (union of every
notice cache), px/notice_need.json, px/version_notices.json, px/version_notices_skipped.json, px/notice_fetch.txt."""
import json, os, collections, glob
S = '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad'
W = S + '/d551w'
PX = W + '/px'
FLOOR = 1000
idx = json.load(open(W + '/shapes_work/cache_index.json'))
nc = {}
for f in glob.glob(f'{PX}/notices/*.json'):
    nc.setdefault(str(int(os.path.basename(f)[:-5])), f)
for p in ('p0', 'p2', 'p3'):
    for f in glob.glob(f'{W}/{p}/notices/*.json'):
        nc.setdefault(str(int(os.path.basename(f)[:-5])), f)
for f in glob.glob(f'{W}/p1/raw/n/*.json'):
    nc.setdefault(str(int(os.path.basename(f)[:-5])), f)
for p in ('p0', 'p2', 'p3'):
    for k, v in json.load(open(f'{W}/{p}/notice_cache_index.json')).items():
        if v and os.path.exists(v):
            nc.setdefault(str(int(k)), v)
parts = {}
for i in range(4):
    for r in json.load(open(f"{W}/features_part{i}.json")):
        parts[r['id']] = i


def detail_path(t, i):
    cand = {0: [f'{W}/p0/tenders/{t}.json'], 1: [f'{W}/p1/raw/t/{t}.json'], 2: [f'{W}/p2/tenders/{t}.json'], 3: [f'{W}/p3/tenders/{t}.json']}[i]
    for p in cand:
        if os.path.exists(p):
            return p
    for q in idx.get(str(t), []):
        p = os.path.join(S, q)
        if os.path.exists(p):
            return p
    raise SystemExit(f'no detail for {t}')


def sentinel(c):
    if c < 0:
        return True
    major = str(c // 100)
    return len(major) >= 7 and len(set(major)) == 1 and c % 100 == 0


def figure(c):
    return c is not None and c > FLOOR and not sentinel(c)


need, vnot, skipped, fetch = {}, {}, {}, set()
for t, i in sorted(parts.items()):
    p = detail_path(t, i)
    dst = f'{PX}/tenders/{t}.json'
    if not os.path.exists(dst):
        os.symlink(p, dst)
    x = json.load(open(p))
    lots = {l['lot_key']: l for l in x.get('lot_details', [])}
    unit = 'Lot' if any(l['kind'] == 'Lot' for l in lots.values()) else 'Part'
    excluded = {k for k, l in lots.items() if l['kind'] != unit}
    by_cur = collections.defaultdict(dict)
    for lr in x.get('lot_results', []):
        a = lr.get('awarded') or {}
        lot = lr.get('lot')
        if not lot or a.get('cents') is None or not a.get('currency') or lot in excluded or not figure(a['cents']):
            continue
        cur = by_cur[a['currency']]
        prev = cur.get(lot)
        if prev is None or lr['notice_id'] >= prev['notice_id']:
            cur[lot] = lr
    served = x.get('value') or {}
    k = served['currency'] if served.get('currency') in by_cur else (max(by_cur, key=lambda c: (len(by_cur[c]), c)) if by_cur else None)
    A = by_cur[k] if k else {}
    nids = {lr['notice_id'] for lr in A.values()}
    res = [lr['notice_id'] for lr in x.get('lot_results', []) if (lr.get('awarded') or {}).get('cents') is not None or lr.get('winners')]
    if res:
        nids.add(max(res))
    need[str(t)] = sorted(nids)
    vs = sorted({v['caused_by_notice_id'] for v in x.get('versions', [])})
    vnot[str(t)] = vs
    for n in nids:
        if str(n) not in nc:
            fetch.add(n)
    unc = [n for n in vs if str(n) not in nc and n not in nids]
    if len(unc) > 12:
        keep = set(unc[:2]) | {unc[-1]}
        skipped[str(t)] = [n for n in unc if n not in keep]
        fetch |= keep
    else:
        fetch |= set(unc)
json.dump(nc, open(f'{PX}/notice_cache_index.json', 'w'))
json.dump(need, open(f'{PX}/notice_need.json', 'w'))
json.dump(vnot, open(f'{PX}/version_notices.json', 'w'))
json.dump(skipped, open(f'{PX}/version_notices_skipped.json', 'w'))
open(f'{PX}/notice_fetch.txt', 'w').write(''.join(f'{n}\n' for n in sorted(fetch)))
json.dump(sorted(parts), open(f'{PX}/ids.json', 'w'))
print('ids', len(parts), 'cached notices', len(nc), 'to fetch', len(fetch), 'skipped', sum(len(v) for v in skipped.values()), {k: len(v) for k, v in skipped.items()})
