"""px2: the same unified extraction for out-of-sample path-W fires (no labels): the 4,745 records' fires that are not
among the 279 (585917, 5995030) and unit 2's fresh-holdout awards fires (467176, 294968, 7256284, 5977060)."""
import json, os, glob, collections, sys
W = '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w'
PX2 = W + '/px2'
ids = [l.strip() for l in open(PX2 + '/tender_ids.txt') if l.strip()]
nc = json.load(open(W + '/px/notice_cache_index.json'))
for f in glob.glob(PX2 + '/notices/*.json'):
    nc.setdefault(os.path.basename(f)[:-5], f)
FLOOR = 1000


def figure(c):
    if c is None or c <= FLOOR:
        return False
    major = str(c // 100)
    return not (len(major) >= 7 and len(set(major)) == 1 and c % 100 == 0)


need, vnot, fetch = {}, {}, set()
for t in ids:
    x = json.load(open(f'{PX2}/tenders/{t}.json'))
    lots = {l['lot_key']: l for l in x.get('lot_details', [])}
    unit = 'Lot' if any(l['kind'] == 'Lot' for l in lots.values()) else 'Part'
    excluded = {k for k, l in lots.items() if l['kind'] != unit}
    by_cur = collections.defaultdict(dict)
    for lr in x.get('lot_results', []):
        a = lr.get('awarded') or {}
        lot = lr.get('lot')
        if not lot or a.get('cents') is None or not a.get('currency') or lot in excluded or not figure(a['cents']):
            continue
        prev = by_cur[a['currency']].get(lot)
        if prev is None or lr['notice_id'] >= prev['notice_id']:
            by_cur[a['currency']][lot] = lr
    served = x.get('value') or {}
    k = served['currency'] if served.get('currency') in by_cur else (max(by_cur, key=lambda c: (len(by_cur[c]), c)) if by_cur else None)
    nids = {lr['notice_id'] for lr in (by_cur[k].values() if k else [])}
    res = [lr['notice_id'] for lr in x.get('lot_results', []) if (lr.get('awarded') or {}).get('cents') is not None or lr.get('winners')]
    if res:
        nids.add(max(res))
    need[t] = sorted(nids)
    vnot[t] = sorted({v['caused_by_notice_id'] for v in x.get('versions', [])})
    fetch |= {n for n in set(nids) | set(vnot[t]) if str(n) not in nc}
json.dump(nc, open(PX2 + '/notice_cache_index.json', 'w'))
json.dump(need, open(PX2 + '/notice_need.json', 'w'))
json.dump(vnot, open(PX2 + '/version_notices.json', 'w'))
json.dump({}, open(PX2 + '/version_notices_skipped.json', 'w'))
json.dump(ids, open(PX2 + '/ids.json', 'w'))
open(PX2 + '/notice_fetch.txt', 'w').write(''.join(f'{n}\n' for n in sorted(fetch)))
print('ids', ids, 'to fetch', len(fetch))
