#!/bin/bash
# usage: fetch.sh <list-file> <outdir> <url-prefix> <url-suffix>
# sequential, >= 2 s between GETs, a 408 retried at most once
list=$1; out=$2; pre=$3; suf=$4
mkdir -p "$out"
while read -r id; do
  [ -z "$id" ] && continue
  [ -s "$out/$id.json" ] && continue
  code=$(curl -sS -o "$out/$id.tmp" -w '%{http_code}' --max-time 60 "$pre$id$suf")
  echo "$id $code"
  if [ "$code" = "408" ]; then sleep 6; code=$(curl -sS -o "$out/$id.tmp" -w '%{http_code}' --max-time 60 "$pre$id$suf"); echo "$id retry $code"; fi
  if [ "$code" = "200" ]; then mv "$out/$id.tmp" "$out/$id.json"; else echo "$id $code" >> "$out/errors.txt"; rm -f "$out/$id.tmp"; fi
  sleep 2
done < "$list"
echo FETCH-DONE
