"""Issue 551 unit 4b: score candidate path-W guard sets against the 279 post-drain labels.

    python3 -I score.py [--json OUT] [--show CAND ...] [--all]

Inputs (all read-only):
- labels:   /home/user/tender-db/.scratch/tender-db/551-lot-sum/postdrain/read_result.json ("final")
- features: d551w/px/features_all.json -- ONE extractor (p3scripts/extract.py, paths re-pointed by
            score_work/pxscripts) run over all 279 ids, so every id has the same facts: the summed set rebuilt from
            /v1/tenders/{id} (equals the served lot-sum-awards value to the cent), per-lot award history with
            contractors, the published LOT_NO of each summed award's notice section/result, BT-765/766/TED framework
            codes and every stated total over EVERY version notice (chains with > 12 uncached version notices read a
            bounded set: oldest two, newest, all cached ones; listed in version_notices_not_fetched).
- shapes:   d551w/shapes_work/features.json -- the shapes pass's API-only features (reference tiers T0 / SH6).

A candidate REFUSES an id when its predicate is true: path W does not fire and today's head stays.
  wrong refused   = good (the bad sum is not served)
  right refused   = a lost fix
  neutral refused = no change in quality
Everything is in-sample: the 279 labels were used to describe the shapes, and every threshold below is a round number
(1 %, 10x) named in the task or the issue, not fitted, but the candidate list itself was written after reading the
labels, and C_title, P10, HI, DOM10 and Bm_g's consortium exception were added after reading the residual wrongs of
the first candidates. T0 is the shapes pass's 15 API features, each 0 rights on these labels by construction.

Rebuild the inputs (all under d551w/, one GET per >= 2 s, 408 retried once):
    python3 -I score_work/px_prep.py                       # px/: tender symlinks, notice need, fetch list
    score_work/fetch.sh px/notice_fetch.txt px/notices https://tenders.zebreus.click/v1/notices/ /content
    python3 -I -B score_work/pxscripts/extract.py          # px/features_all.json (279 rows)
    python3 -I score_work/px2_prep.py; ...pxscripts2/extract.py; shapes_work/features.py   # px2/: out-of-sample fires
    (cd score_work/u4745 && python3 -I -B run_w.py)       # merge_rule.serve over the 4,745 -> w_fires.json
"""
import json, math, re, sys, itertools, collections

RR = '/home/user/tender-db/.scratch/tender-db/551-lot-sum/postdrain/read_result.json'
W = '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w'
FEAT = W + '/px/features_all.json'
SHAPES = W + '/shapes_work/features.json'
POP_FIRES = 15352          # path-W corrections in the drain (project 2575)
SAMPLE_N = 50              # salted-uniform sample of those corrections ("sample" group)
FLOOR = 1000


def sentinel(c):
    if c is None or c < 0:
        return True
    major = str(c // 100)
    return len(major) >= 7 and len(set(major)) == 1 and c % 100 == 0


def figure(c):
    return c is not None and c > FLOOR and not sentinel(c)


# ---------------------------------------------------------------- exact binomial helpers
def binom_cdf(k, n, p):
    if k < 0:
        return 0.0
    if k >= n:
        return 1.0
    return sum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k + 1))


def cp_bounds(k, n, alpha=0.05):
    """Two-sided Clopper-Pearson 95 % interval (the issue's convention: 9/50 -> 9-31 %)."""
    if n == 0:
        return (0.0, 1.0)

    def solve(f, lo=0.0, hi=1.0):
        for _ in range(100):
            mid = (lo + hi) / 2
            if f(mid):
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2
    lower = 0.0 if k == 0 else solve(lambda p: 1 - binom_cdf(k - 1, n, p) < alpha / 2)
    upper = 1.0 if k == n else solve(lambda p: binom_cdf(k, n, p) > alpha / 2)
    return (lower, upper)


# ---------------------------------------------------------------- per-id atomic facts
def lot_nums(p):
    """Published lot number(s) as a set of tokens: 'LOT-0003' -> {'3'}, '1, 2, 3, 4, 6' -> 5 tokens, '1+2' -> 2,
    '1-4' -> {'1','2','3','4'}, '2a' -> {'2a'}. None when nothing is published."""
    if p is None:
        return None
    s = str(p).lower()
    out = set()
    for a, b in re.findall(r'(?<![\w])(\d+)\s*(?:-|–|to|bis|à|a)\s*(\d+)(?![\w])', s):
        a, b = int(a), int(b)
        if 0 < b - a <= 50:
            out |= {str(i) for i in range(a, b + 1)}
    for t in re.findall(r'\d+[a-z]?(?![a-z])', s):
        m = re.match(r'(\d+)([a-z]?)', t)
        out.add((m.group(1).lstrip('0') or '0') + m.group(2))
    return out or None


def ckey(ids, names):
    out = set()
    ids = ids or []
    names = names or []
    for i, oid in enumerate(ids):
        if oid is not None:
            out.add(f'id:{oid}')
        elif i < len(names) and names[i]:
            out.add('nm:' + re.sub(r'\W+', ' ', names[i].lower()).strip())
    if not ids:
        for n in names:
            if n:
                out.add('nm:' + re.sub(r'\W+', ' ', n.lower()).strip())
    return frozenset(out)


AWARD_TOTAL_KINDS = {'result_total', 'framework_max_total', 'framework_reestimate_total'}
ESTIMATE_TOTAL_KINDS = {'estimate_total'}


def facts(r, sh):
    """Atomic predicates for one labelled id (px schema = features_part3 schema)."""
    f = {}
    cur = r['summed_currency']
    summed = r['summed_lots']
    S = r['sum_cents']
    lots = {l['key']: l for l in r['lots']}
    f['n'] = len(summed)
    f['S'] = S
    f['cur'] = cur
    notices = {s['notice_id'] for s in summed}
    f['multi_notice'] = len(notices) >= 2

    # ---- A: framework / DPS (BT-765/766 framework or DPS code, TED FRAMEWORK/DPS field, dps classification;
    # over every version notice read)
    f['A'] = r.get('is_framework_all_versions') is True
    f['A_text'] = f['A'] or bool(r.get('framework_word_in_text'))
    f['A_known_not'] = r.get('is_framework_all_versions') is False

    # ---- B: contractors
    latest = {}
    for s in summed:
        latest[s['key']] = ckey(s.get('contractor_ids'), s.get('contractor_names'))
    hist_vary = False
    for s in summed:
        sets = {ckey(a.get('contractor_ids'), a.get('contractor_names')) for a in lots.get(s['key'], {}).get('awards', [])}
        sets.discard(frozenset())
        if len(sets) > 1:
            hist_vary = True
    cnt = collections.Counter(c for ws in latest.values() for c in ws)
    f['B1'] = hist_vary                                     # a summed lot's contractors differ across its award results
    f['B2'] = any(v >= 2 for v in cnt.values())              # one contractor holds 2+ summed lots
    f['Bm'] = any(len(ws) >= 2 for ws in latest.values())    # a multi-supplier lot (>= 2 contractors on the summed award)
    f['B0'] = any(len(ws) == 0 for ws in latest.values())    # a summed award with no contractor
    # Bm_t: a multi-TENDER lot -- the summed award's winners are not all on one tender (bid) of that lot in that
    # notice, i.e. >= 2 winning tenders (a consortium's members share one tender and do not fire). No tender rows for
    # the lot in that notice: fail closed (fires when >= 2 contractors), as the shapes table found TED/CH multi-award
    # lots with no bids.
    mt = False
    for s in summed:
        ids = [x for x in (s.get('contractor_ids') or []) if x is not None]
        if len(latest[s['key']]) < 2:
            continue
        bids = [b for b in lots.get(s['key'], {}).get('bids', []) if b.get('notice_id') == s['notice_id']]
        if not bids or len(ids) < len(s.get('contractor_ids') or []):
            mt = True
            continue
        if not any(set(ids) <= set(b.get('tenderer_ids') or []) for b in bids):
            mt = True
    f['Bm_t'] = mt
    # Bm_g: Bm_t, but a TED result flagged AWARDED_TO_GROUP (a consortium: one tender by a group of operators) is one
    # tender even with no tender rows (the Lyon-Turin trio's three groups).
    mg = False
    for s in summed:
        ids = [x for x in (s.get('contractor_ids') or []) if x is not None]
        if len(latest[s['key']]) < 2:
            continue
        nr = {}
        for a in lots.get(s['key'], {}).get('awards', []):
            if a['notice_id'] == s['notice_id'] and a.get('result_key') == s.get('result_key'):
                nr = a.get('notice_result') or {}
        group = nr.get('group') not in (None, 0, '0', False, 'false', 'NO') and 'no_group' not in nr
        bids = [b for b in lots.get(s['key'], {}).get('bids', []) if b.get('notice_id') == s['notice_id']]
        if not bids:
            if not group:
                mg = True
            continue
        if len(ids) < len(s.get('contractor_ids') or []) or not any(set(ids) <= set(b.get('tenderer_ids') or []) for b in bids):
            mg = True
    f['Bm_g'] = mg
    # Bm_v: >= 2 VALUED tenders of winners on a summed lot in the summed notice (each winner priced the lot: shares,
    # parallel offers or a ceiling copied per supplier). UK FTS frameworks that value only TEN-k-0 pass. No tender rows
    # for the lot in that notice: fail closed when >= 2 contractors.
    mv = False
    for s in summed:
        ws = set(x for x in (s.get('contractor_ids') or []) if x is not None)
        if len(latest[s['key']]) < 2:
            continue
        bids = [b for b in lots.get(s['key'], {}).get('bids', []) if b.get('notice_id') == s['notice_id']]
        if not bids or len(ws) < len(s.get('contractor_ids') or []):
            mv = True
            continue
        valued = {tuple(sorted(x for x in (b.get('tenderer_ids') or []) if x is not None)) for b in bids
                  if figure(b.get('cents')) and b.get('currency') == cur and ws & set(b.get('tenderer_ids') or [])}
        if len(valued) >= 2:
            mv = True
    f['Bm_v'] = mv
    f['B'] = f['B1'] or f['B2']

    # ---- C: published lot numbers (LOT_NO / BT-137 of the summed award's own notice, not the key)
    nums = {s['key']: lot_nums(s.get('published_lot_no')) for s in summed}
    share = False
    keys = list(nums)
    for a, b in itertools.combinations(keys, 2):
        if nums[a] and nums[b] and nums[a] & nums[b]:
            share = True
    f['C'] = share
    f['C_list'] = any(v and len(v) >= 2 for v in nums.values())
    f['C_absent'] = any(v is None for v in nums.values())
    # a key whose award notices name different published lots (TED LOT-k is a per-notice ordinal)
    vary = False
    for s in summed:
        L = lots.get(s['key'], {})
        secs = L.get('lot_section_by_version_notice') or {}
        seen = set()
        for a in L.get('awards', []):
            if a.get('cents') is None and not a.get('contractor_ids'):
                continue
            nid = str(a['notice_id'])
            no = (secs.get(nid) or {}).get('lot_no')
            if no is None:
                no = (L.get('lot_no_by_notice', {}).get(nid) or {}).get('lot_no')
            if no is None:
                no = (a.get('notice_result') or {}).get('lot_no')
            t = lot_nums(no)
            if t:
                seen.add(frozenset(t))
        if len(seen) > 1:
            vary = True
    f['C_vary'] = vary
    f['C_plus'] = f['C'] or f['C_list'] or vary or (f['multi_notice'] and f['C_absent'])
    f['distinct_lot_nos'] = (not f['C_absent']) and (not f['C_list']) and (not f['C']) and not vary

    # C_title (added after reading the residuals): two summed keys from DIFFERENT notices with the same non-empty
    # winner set and the same normalized lot title -- one lot re-keyed (eForms modification LOT-0000 -> LOT-0001,
    # TED single-section notices). The shapes pass's `rekey_eforms`.
    def nt(t):
        return re.sub(r'\W+', ' ', (t or '').lower()).strip()
    ct = False
    for a, b in itertools.combinations(summed, 2):
        if a['notice_id'] != b['notice_id'] and latest[a['key']] and latest[a['key']] == latest[b['key']] \
                and nt(lots.get(a['key'], {}).get('title')) and nt(lots.get(a['key'], {}).get('title')) == nt(lots.get(b['key'], {}).get('title')):
            ct = True
    f['C_title'] = ct
    # P10 (added after reading the residuals): a summed award >= 10x, or <= 1/10, of an EARLIER valued award on the
    # same key (a x10^k slip in a modification, 1110930), the same lot's own history as the reference.
    p10 = False
    for s in summed:
        for a in lots.get(s['key'], {}).get('awards', []):
            c = a.get('cents')
            if a['notice_id'] < s['notice_id'] and a.get('currency') == cur and figure(c):
                if s['cents'] >= 10 * c or s['cents'] * 10 <= c:
                    p10 = True
    f['P10'] = p10
    # HI (added after reading the residuals): a summed award above its own result's highest tender (BT-711 / TED HIGH)
    # by > 1 %: an aggregate of several tenders or a slip (441003).
    hi_v = False
    for s in summed:
        for a in lots.get(s['key'], {}).get('awards', []):
            if a['notice_id'] != s['notice_id'] or a.get('result_key') != s.get('result_key'):
                continue
            am = (a.get('notice_result') or {}).get('amounts') or {}
            hi = [c for fld in ('BT-711-LotResult', 'TED-HIGH', 'TED-HIGH_VALUE') for c, cu in am.get(fld, []) if cu == cur and figure(c)]
            if hi and s['cents'] > 1.01 * max(hi):
                hi_v = True
    f['HI'] = hi_v

    # DOM10 (added after reading the residuals): the largest summed award is >= 10x the second (a x10^k slip beside
    # its siblings, or a dominant lot whose sum adds <= 1/10 per other lot -- refusing it costs little value).
    vals = sorted((x['cents'] for x in summed), reverse=True)
    f['DOM10'] = len(vals) >= 2 and vals[0] >= 10 * vals[1]
    f['top_share'] = vals[0] / S if S else None

    # ---- stated totals and estimates (same currency; sentinels and 0 dropped)
    T, Tn, E = [], [], []
    for t in r.get('stated_totals_all_versions') or []:
        if t.get('currency') != cur or not figure(t.get('cents')):
            continue
        if t['kind'] in AWARD_TOTAL_KINDS:
            if t.get('equals_its_single_lot_award'):
                continue          # a single-lot notice's total equal to its own award is that lot's figure
            T.append(t['cents'])
            Tn.append((t['notice_id'], t['cents']))
        elif t['kind'] in ESTIMATE_TOTAL_KINDS:
            E.append(t['cents'])
    for a in r.get('lotnull_amounts') or []:
        if a['currency'] == cur and a['field'] in ('estimated_value', 'framework_maximum') and figure(a['cents']):
            E.append(a['cents'])
    lot_est = {}
    for k, L in lots.items():
        e = None
        if L.get('estimate_cents') is not None and L.get('currency') == cur and figure(L['estimate_cents']):
            e = L['estimate_cents']
        elif (L.get('estimate_by_published_lot_no') or {}).get('currency') == cur and figure(L['estimate_by_published_lot_no']['cents']):
            e = L['estimate_by_published_lot_no']['cents']
        if e is not None:
            lot_est[k] = e
            E.append(e)
    # per notice: a notice's award-type total against the summed awards it is the source of (own) or the summed
    # keys it awards at all (keys)
    byN = collections.defaultdict(list)
    for t in r.get('stated_totals_all_versions') or []:
        if t.get('currency') == cur and figure(t.get('cents')) and t['kind'] in AWARD_TOTAL_KINDS and not t.get('equals_its_single_lot_award'):
            byN[t['notice_id']].append(t['cents'])
    own_over = keys_over = False
    for nid, ts in byN.items():
        tN = max(ts)
        s_own = sum(s['cents'] for s in summed if s['notice_id'] == nid)
        s_keys = sum(s['cents'] for s in summed if any(a['notice_id'] == nid for a in lots.get(s['key'], {}).get('awards', [])))
        if s_own > tN * 1.01:
            own_over = True
        if s_keys > tN * 1.01:
            keys_over = True
    f['T_max'] = max(T) if T else None
    f['T_latest'] = max(Tn)[1] if Tn else None
    f['E_max'] = max(E) if E else None
    f['has_T'] = bool(T)

    def D(tol, which='max', est_x=10):
        t = f['T_max'] if which == 'max' else f['T_latest']
        if t is not None:
            return S > t * (1 + tol)
        if f['E_max'] is not None:
            return S > est_x * f['E_max']
        return False
    f['D'] = D(0.01)
    f['D_latest'] = D(0.01, 'latest')
    f['D5'] = D(0.05)
    f['D_total_only'] = f['T_max'] is not None and S > f['T_max'] * 1.01
    est_branch = (not T) and f['E_max'] is not None and S > 10 * f['E_max']
    f['D_own'] = own_over or est_branch
    f['D_keys'] = keys_over or est_branch
    f['S_le_T'] = f['T_max'] is not None and S <= f['T_max'] * 1.01
    f['S_le_10E'] = f['E_max'] is not None and S <= 10 * f['E_max']

    # ---- E: a summed award >= 10x its own lot's estimate (inclusive)
    f['E'] = any(s['key'] in lot_est and s['cents'] >= 10 * lot_est[s['key']] for s in summed)
    f['E_any_est'] = any(s['key'] in lot_est for s in summed)

    # ---- reference: the shapes pass's API-only features (shapes_work/features.json)
    g = (sh or {}).get('f', {})
    T0 = ('clos_nw', 'later_closed', 'award_eq_est_total', 'award_eq_whole', 'award_gt_bid_sum', 'gt2_bt709', 'bt709_sum_lt_S',
          'ge15_est_min', 'equal_bids_eq_ceiling', 'award_n_times_ref', 'tiny', 'proc_est_eq_each_lot_est', 'lot_est_all_equal',
          'est_sum_lt_S3', 'ge3_est')
    f['T0'] = any(g.get(k) for k in T0)
    f['SH6'] = f['T0'] or any(g.get(k) for k in ('rekey_eforms', 'multiwin_sum_no_ref_or_over', 'ted_rekey', 'dominant_slip_100',
                                                 'identical_pair_any'))
    f['tiny'] = bool(g.get('tiny'))
    f['clos'] = bool(g.get('clos_nw') or g.get('later_closed'))
    f['dps_cls'] = bool(g.get('dps'))
    f['coverage_bounded'] = bool(r.get('version_notices_not_fetched'))
    return f


# ---------------------------------------------------------------- candidates
def Z(f):
    """Path W only where: no framework flag, distinct contractors on distinct published lot numbers, and a stated
    total the sum does not exceed. Refuse = NOT all of these."""
    ok = (not f['A']) and f['distinct_lot_nos'] and not f['B2'] and not f['Bm'] and not f['B0'] and f['S_le_T']
    return not ok


def Z_nototal(f):
    """Unit 4b's note: sum only where NO total is stated, each summed award is a distinct contractor on a distinct
    published lot number, not a framework/DPS, no multi-supplier lot, and the sum is within 10x of every estimate."""
    ok = (not f['A']) and f['distinct_lot_nos'] and not f['B2'] and not f['Bm'] and not f['B0'] and (not f['has_T']) \
        and not (f['E_max'] is not None and f['S'] > 10 * f['E_max'])
    return not ok


def Z_either(f):
    """Z with either branch: (total stated and S <= T) or (no total and S <= 10x every estimate, or no estimate)."""
    ok = (not f['A']) and f['distinct_lot_nos'] and not f['B2'] and not f['Bm'] and not f['B0'] and not f['D']
    return not ok


def Z_strict(f):
    """Z, and the framework flag must be positively 'none' (a read eForms BT-765 none or a read TED F02/F03/F05/F06)."""
    return Z(f) or not f['A_known_not']


BASE = {
    'A': lambda f: f['A'],
    'B': lambda f: f['B'],
    'C': lambda f: f['C'],
    'D': lambda f: f['D'],
    'E': lambda f: f['E'],
}
EXTRA = {
    'A_text (A or framework word in title/text)': lambda f: f['A_text'],
    'B1 (contractors vary across a lot\'s results)': lambda f: f['B1'],
    'B2 (one contractor on 2+ summed lots)': lambda f: f['B2'],
    'Bm (multi-supplier summed lot)': lambda f: f['Bm'],
    'C_plus (C, list LOT_NO, key re-used by another lot, or absent in a multi-notice set)': lambda f: f['C_plus'],
    'D_latest (newest stated total)': lambda f: f['D_latest'],
    'D5 (5 % tolerance)': lambda f: f['D5'],
    'D_total_only (no estimate branch)': lambda f: f['D_total_only'],
    'Z (task: no fw flag, distinct contractors on distinct LOT_NOs, total stated and S <= total)': Z,
    'Z_strict (Z with BT-765 positively none)': Z_strict,
    'Z_nototal (4b note: no total stated, distinct, S <= 10x estimates)': Z_nototal,
    'Z_either (Z with the no-total branch of D)': Z_either,
    'Bm_t (multi-tender summed lot; consortia pass)': lambda f: f['Bm_t'],
    'D_own (a notice\'s total < the summed awards it sources)': lambda f: f['D_own'],
    'D_keys (a notice\'s total < the summed lots it awards)': lambda f: f['D_keys'],
    'R1 = A+Bm_t+C_plus+D_keys+E': lambda f: f['A'] or f['Bm_t'] or f['C_plus'] or f['D_keys'] or f['E'],
    'R2 = R1+B1': lambda f: f['A'] or f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'],
    'R3 = R2+T0': lambda f: f['A'] or f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'],
    'R4 = R3 without A': lambda f: f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'],
    'R5 = R3 with D (literal) for D_keys': lambda f: f['A'] or f['Bm_t'] or f['B1'] or f['C_plus'] or f['D'] or f['E'] or f['T0'],
    'C_title (same winners + same lot title on 2 keys, different notices)': lambda f: f['C_title'],
    'P10 (summed award >= 10x / <= 1/10 of the same key\'s earlier award)': lambda f: f['P10'],
    'HI (summed award > its result\'s highest tender)': lambda f: f['HI'],
    'R6 = R3+C_title+P10': lambda f: f['A'] or f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'] or f['C_title'] or f['P10'],
    'R7 = R6+HI': lambda f: f['A'] or f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'] or f['C_title'] or f['P10'] or f['HI'],
    'R8 = R7 without A': lambda f: f['Bm_t'] or f['B1'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'] or f['C_title'] or f['P10'] or f['HI'],
    'R9 = R8 without B1': lambda f: f['Bm_t'] or f['C_plus'] or f['D_keys'] or f['E'] or f['T0'] or f['C_title'] or f['P10'] or f['HI'],
    'Bm_v (>= 2 valued winning tenders on a summed lot)': lambda f: f['Bm_v'],
    'W2 = A+Bm_t+C_plus+D_keys+E+T0+C_title+P10': lambda f: any(f[c] for c in ('A', 'Bm_t', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'W3 = W2 with Bm_v for Bm_t': lambda f: any(f[c] for c in ('A', 'Bm_v', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'W4 = W3 without A': lambda f: any(f[c] for c in ('Bm_v', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'W5 = W3 with D_own for D_keys': lambda f: any(f[c] for c in ('A', 'Bm_v', 'C_plus', 'D_own', 'E', 'T0', 'C_title', 'P10')),
    'W6 = W3 without D': lambda f: any(f[c] for c in ('A', 'Bm_v', 'C_plus', 'E', 'T0', 'C_title', 'P10')),
    'W7 = W3 without T0 (no shapes-pass API features)': lambda f: any(f[c] for c in ('A', 'Bm_v', 'C_plus', 'D_keys', 'E', 'C_title', 'P10')),
    'W8 = A+Bm_v+C_plus+D_keys+E (task facts only)': lambda f: any(f[c] for c in ('A', 'Bm_v', 'C_plus', 'D_keys', 'E')),
    'Bm_g (Bm_t; a TED AWARDED_TO_GROUP result is one tender)': lambda f: f['Bm_g'],
    'W9 = W2 with Bm_g for Bm_t': lambda f: any(f[c] for c in ('A', 'Bm_g', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'W10 = W9 without A': lambda f: any(f[c] for c in ('Bm_g', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'W11 = W2 without A': lambda f: any(f[c] for c in ('Bm_t', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10')),
    'DOM10 (largest summed award >= 10x the second)': lambda f: f['DOM10'],
    'W12 = W9+DOM10': lambda f: any(f[c] for c in ('A', 'Bm_g', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10', 'DOM10')),
    'W13 = W12 without A': lambda f: any(f[c] for c in ('Bm_g', 'C_plus', 'D_keys', 'E', 'T0', 'C_title', 'P10', 'DOM10')),
    'A+Bm+C_plus+D+E': lambda f: f['A'] or f['Bm'] or f['C_plus'] or f['D'] or f['E'],
    'Bm+C_plus+D+E': lambda f: f['Bm'] or f['C_plus'] or f['D'] or f['E'],
    'Bm+B1+C_plus+D+E': lambda f: f['Bm'] or f['B1'] or f['C_plus'] or f['D'] or f['E'],
    'A+Bm+B1+C_plus+D+E': lambda f: f['A'] or f['Bm'] or f['B1'] or f['C_plus'] or f['D'] or f['E'],
    'A+Bm+B1+C_plus+D+E+T0': lambda f: f['A'] or f['Bm'] or f['B1'] or f['C_plus'] or f['D'] or f['E'] or f['T0'],
    'shapes T0 (15 API features)': lambda f: f['T0'],
    'shapes SH6 (T0 + 5 tiers)': lambda f: f['SH6'],
    'SH6+A+C_plus+D+E': lambda f: f['SH6'] or f['A'] or f['C_plus'] or f['D'] or f['E'],
    'refuse all (path W off)': lambda f: True,
    'refuse none (path W as drained)': lambda f: False,
}


def candidates(all_subsets=True):
    out = []
    names = list(BASE)
    sizes = range(1, 6) if all_subsets else (1, 5)
    for k in sizes:
        for combo in itertools.combinations(names, k):
            out.append(('+'.join(combo), (lambda c: (lambda f: any(BASE[x](f) for x in c)))(combo)))
    out += list(EXTRA.items())
    return out


# ---------------------------------------------------------------- scoring
def score(name, pred, ids, lab, F):
    res = {'name': name}
    groups = {'top': [], 'mid': [], 'sample': []}
    for i in ids:
        groups[lab[i]['group'].split('-')[0]].append(i)
    groups['band'] = groups['top'] + groups['mid']
    groups['all'] = ids
    for g, gi in groups.items():
        d = collections.Counter()
        for i in gi:
            v = lab[i]['verdict']
            ref = bool(pred(F[i]))
            d[('ref' if ref else 'ship', v)] += 1
            if not ref and v == 'wrong' and lab[i]['class'] == 'farther':
                d['farther_ship'] += 1
        ship = d[('ship', 'wrong')] + d[('ship', 'right')] + d[('ship', 'neutral')]
        res[g] = {'n': len(gi), 'W_ref': d[('ref', 'wrong')], 'R_ref': d[('ref', 'right')], 'N_ref': d[('ref', 'neutral')],
                  'ship': ship, 'W_ship': d[('ship', 'wrong')], 'R_ship': d[('ship', 'right')], 'N_ship': d[('ship', 'neutral')],
                  'farther_ship': d['farther_ship'],
                  'wrong_rate_ship': (d[('ship', 'wrong')] / ship) if ship else None}
    s = res['sample']
    lo, hi = cp_bounds(s['W_ship'], s['ship'])
    s['wrong_rate_cp95'] = (lo, hi)
    flo, fhi = cp_bounds(s['ship'], SAMPLE_N)
    s['proj_fires'] = round(POP_FIRES * s['ship'] / SAMPLE_N)
    s['proj_fires_cp95'] = (round(POP_FIRES * flo), round(POP_FIRES * fhi))
    s['proj_wrong_fires'] = round(POP_FIRES * s['W_ship'] / SAMPLE_N)
    s['proj_right_fires'] = round(POP_FIRES * s['R_ship'] / SAMPLE_N)
    s['proj_wrong_fires_cp95_upper'] = round(POP_FIRES * cp_bounds(s['W_ship'], SAMPLE_N)[1])
    p = s['wrong_rate_ship'] or 0.0
    s['p_pass_fresh30'] = binom_cdf(1, 30, p) if s['ship'] else None
    s['p_pass_fresh30_at_cp_upper'] = binom_cdf(1, 30, hi) if s['ship'] else None
    # the 4b bar, read on the labels: the sample's wrong rate among what ships at most 1 in 30 (point estimate) and
    # 0 farther shipped in the >= EUR 100 m band
    res['meets_bar_in_sample'] = (s['ship'] > 0 and s['W_ship'] * 30 <= s['ship'] and res['band']['farther_ship'] == 0)
    return res


def pct(x):
    return '-' if x is None else f'{100 * x:.0f} %'


def row(r):
    a, b, s = r['all'], r['band'], r['sample']
    lo, hi = s['wrong_rate_cp95']
    return (f"| {r['name']} | {a['W_ref']}/105 | {a['R_ref']}/160 | {a['N_ref']}/14 "
            f"| {r['top']['W_ref']}w {r['top']['R_ref']}r | {r['mid']['W_ref']}w {r['mid']['R_ref']}r | {s['W_ref']}w {s['R_ref']}r "
            f"| {b['ship']} ({b['W_ship']}w, {b['farther_ship']}f) {pct(b['wrong_rate_ship'])} "
            f"| {s['ship']} ({s['W_ship']}w) {pct(s['wrong_rate_ship'])} [CP95 {pct(lo)}-{pct(hi)}] "
            f"| ~{s['proj_fires']:,} ({s['proj_fires_cp95'][0]:,}-{s['proj_fires_cp95'][1]:,}), ~{s['proj_wrong_fires']:,} wrong |")


HEADER = ('| candidate (refuse when) | wrong refused | right refused | neutral refused | top 21 refused | mid 208 refused '
          '| sample 50 refused | band 229 ships (wrong, farther) wrong rate | sample ships (wrong) wrong rate [exact 95 %] '
          '| projected fires left of 15,352 |\n|---|---|---|---|---|---|---|---|---|---|')


KEY = ['A', 'B', 'C', 'D', 'E', 'A+B+C+D+E', 'B+C+D+E', 'A+C+D+E', 'C+D+E',
       'Z (task: no fw flag, distinct contractors on distinct LOT_NOs, total stated and S <= total)',
       'Z_nototal (4b note: no total stated, distinct, S <= 10x estimates)',
       'Z_either (Z with the no-total branch of D)',
       'shapes SH6 (T0 + 5 tiers)',
       'W8 = A+Bm_v+C_plus+D_keys+E (task facts only)',
       'W2 = A+Bm_t+C_plus+D_keys+E+T0+C_title+P10',
       'W9 = W2 with Bm_g for Bm_t',
       'W10 = W9 without A',
       'W12 = W9+DOM10',
       'W13 = W12 without A',
       'refuse none (path W as drained)']


def key_table(results):
    by = {r['name']: r for r in results}
    print('\n## Key candidates\n')
    print('| candidate | wrong refused | right refused (lost fixes) | band 229: ships / wrong / farther | sample 50: ships / wrong '
          '| sample wrong rate among shipped [exact 95 %] | P(<= 1 wrong in a fresh 30) at that upper bound '
          '| fires left of 15,352 [95 %] | wrong fires left, point / upper |\n|---|---|---|---|---|---|---|---|---|')
    for n in KEY:
        r = by[n]
        a, b, sm = r['all'], r['band'], r['sample']
        lo, hi = sm['wrong_rate_cp95']
        pp = sm['p_pass_fresh30_at_cp_upper']
        print(f"| {n} | {a['W_ref']}/105 | {a['R_ref']}/160 | {b['ship']} / {b['W_ship']} / {b['farther_ship']} "
              f"| {sm['ship']} / {sm['W_ship']} | {pct(sm['wrong_rate_ship'])} [{pct(lo)}-{pct(hi)}] "
              f"| {'-' if pp is None else f'{pp:.2f}'} | ~{sm['proj_fires']:,} [{sm['proj_fires_cp95'][0]:,}-{sm['proj_fires_cp95'][1]:,}] "
              f"| {sm['proj_wrong_fires']:,} / {sm['proj_wrong_fires_cp95_upper']:,} |")


OOS = W + '/px2/features_all.json'
OOS_SHAPES = W + '/px2/shapes_features.json'
OOS_TRUTH = {585917: 'right (unit 2 pin; one of the 4,745)', 5995030: 'right (unit 2 pin; one of the 4,745)',
             467176: 'right (unit 2 holdout read)', 294968: 'right (unit 2 holdout read)',
             7256284: 'right (unit 2 holdout read)', 5977060: 'closer (unit 2 holdout read)'}
U4745 = W + '/score_work/u4745/w_fires.json'


def oos_table(lab, F):
    """Path-W fires outside the 279: the 4,745 records' 6 fires (merge_rule.serve, score_work/u4745/run_w.py) and unit 2's
    4 fresh-holdout awards fires, each read right or closer by unit 2."""
    import os
    if not os.path.exists(OOS):
        return
    rows = {r['id']: r for r in json.load(open(OOS))}
    sh = json.load(open(OOS_SHAPES))
    Fo = {i: facts(r, sh.get(str(i))) for i, r in rows.items()}
    cands = dict(candidates())
    fires = json.load(open(U4745)) if os.path.exists(U4745) else {}
    ids = sorted(set(int(k) for k in fires) | set(rows))
    print('\n## Out-of-sample path-W fires (the 4,745 records and unit 2\'s holdout)\n')
    OK = ['W2 = A+Bm_t+C_plus+D_keys+E+T0+C_title+P10', 'W9 = W2 with Bm_g for Bm_t', 'W10 = W9 without A', 'W12 = W9+DOM10', 'W13 = W12 without A']
    print('| id | truth | in the 4,745 | S | predicates that fire | ' + ' | '.join(n.split(' ')[0] for n in OK) + ' | Z |')
    print('|---|---|---|---|---|' + '---|' * (len(OK) + 1))
    for i in ids:
        f = Fo.get(i) or F.get(i)
        truth = OOS_TRUTH.get(i) or (f"{lab[i]['verdict']} (labelled, {lab[i]['group']})" if i in lab else '?')
        on = [k for k in ('A', 'Bm_t', 'Bm_g', 'B1', 'B2', 'C', 'C_plus', 'D', 'D_keys', 'E', 'T0', 'C_title', 'P10', 'DOM10') if f[k]]
        dec = ['refuse' if cands[n](f) else 'SHIP' for n in OK] + ['refuse' if Z(f) else 'SHIP']
        print(f"| {i} | {truth} | {'yes' if str(i) in fires else 'no'} | {f['cur']} {f['S'] / 100:,.2f} | {', '.join(on) or '-'} | " + ' | '.join(dec) + ' |')


def load():
    rr = json.load(open(RR))
    lab = {int(k): v for k, v in rr['final'].items()}
    rows = json.load(open(FEAT))
    sh = json.load(open(SHAPES))
    F = {}
    for r in rows:
        F[r['id']] = facts(r, sh.get(str(r['id'])))
    ids = sorted(lab)
    assert set(ids) == set(F), (len(ids), len(F))
    return lab, F, ids


def main(argv):
    lab, F, ids = load()
    out = None
    if '--json' in argv:
        out = argv[argv.index('--json') + 1]
    show = argv[argv.index('--show') + 1:] if '--show' in argv else []
    # sanity: the rebuilt sum is the served derived value, n >= 2
    bad = [i for i in ids if F[i]['n'] < 2]
    print(f'labels {len(ids)}: ' + ', '.join(f'{v} {c}' for v, c in collections.Counter(lab[i]["verdict"] for i in ids).items())
          + f'; summed sets with n < 2: {bad}; chains read on a bounded notice set: '
          + str(sorted(i for i in ids if F[i]['coverage_bounded'])))
    # atomic predicate hit counts
    print('\n## Atomic predicates (W/N/R hits of 105/14/160)\n')
    keys = [k for k, v in F[ids[0]].items() if isinstance(v, bool)]
    for k in keys:
        c = collections.Counter(lab[i]['verdict'] for i in ids if F[i][k])
        print(f'- {k}: {c["wrong"]}/{c["neutral"]}/{c["right"]}')
    results = [score(n, p, ids, lab, F) for n, p in candidates('--all' in argv or True)]
    print('\n## Candidates\n')
    print(HEADER)
    for r in results:
        print(row(r))
    key_table(results)
    oos_table(lab, F)
    print('\nCandidates meeting the bar IN SAMPLE (wrong among shipped sample <= 1 per 30, 0 farther shipped in the band):',
          [r['name'] for r in results if r['meets_bar_in_sample']])
    for name in show:
        pred = dict(candidates())[name]
        for v in ('wrong', 'neutral', 'right'):
            ship = [i for i in ids if lab[i]['verdict'] == v and not pred(F[i])]
            ref = [i for i in ids if lab[i]['verdict'] == v and pred(F[i])]
            print(f'\n{name}: {v} shipped {len(ship)}: {ship}\n{name}: {v} refused {len(ref)}: {ref}')
    if out:
        json.dump({'results': results, 'facts': {str(i): F[i] for i in ids}}, open(out, 'w'), indent=1, default=str)


if __name__ == '__main__':
    main(sys.argv[1:])
