"""Issue 551 unit 4b feature extraction, part 3 of 4 (ids at index mod 4 == 3).

Reads p3/tenders/{id}.json (fresh /v1/tenders/{id}; its lot_details equal /v1/lots?tender={id})
and the notice contents in p3/notices (fresh) or the earlier reads' copies, and writes
features_part3.json.
"""
import json, re, sys, os, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/p3scripts')
from common import *

RR = '/home/user/tender-db/.scratch/tender-db/551-lot-sum/postdrain/read_result.json'
final = json.load(open(RR))['final']
ids = json.load(open(W + '/part3_ids.json'))
need = json.load(open(P0 + '/notice_need.json'))
ncache = json.load(open(P0 + '/notice_cache_index.json'))
# part 2 extension: every notice that caused a version of the tender (detail `versions`), and the
# post-drain readers' own stated-total / old-figure notes (label side, not API features)
vnotices = json.load(open(P0 + '/version_notices.json'))
# part 3: chains with more than 12 uncached version notices read a bounded set (oldest two, newest,
# and every already-cached one); the rest are listed per tender as version_notices_not_fetched
vskipped = json.load(open(P0 + '/version_notices_skipped.json'))
reader_notes = {}
for _g in json.load(open(RR))['groups']:
    for _it in _g['items']:
        reader_notes.setdefault(str(_it['id']), {'group': _g.get('group'), 'stated_total': _it.get('stated_total'),
                                                 'old_figure': _it.get('old_figure')})

FW_CODES = {'fa-wo-rc', 'fa-w-rc', 'fa-mix'}
DPS_CODES = {'dps-list', 'dps-nlist'}
RESULT_TOTAL_FIELDS = {'BT-161-NoticeResult': 'result_total', 'BT-118-NoticeResult': 'framework_max_total',
                       'BT-1118-NoticeResult': 'framework_reestimate_total', 'BT-27-Procedure': 'estimate_total',
                       'BT-271-Procedure': 'framework_max_total'}
TED_CN_FORMS = {'F01', 'F02', 'F04', 'F05', 'F07', 'F08', 'F12', 'F16', 'F17', 'F24'}
TED_ROOT_TOTALS = {'TED-VAL_TOTAL': 'result_total', 'TED-VAL_ESTIMATED_TOTAL': 'estimate_total'}


def load_notice(nid):
    p = f'{P0}/notices/{nid}.json'
    if os.path.exists(p):
        return json.load(open(p)), 'fresh-2026-10-17'
    q = ncache.get(str(nid))
    if q and os.path.exists(q):
        return json.load(open(q)), 'earlier-read-copy'
    return None, None


def val(v):
    if 'value' in v:
        return v['value']
    return v.get('code')


def title_lot_no(t):
    if not t:
        return None
    m = re.search(r'(?i)\b(?:lot|los|lote|lotto|lotu?|część|czesc|rész|resz|partie|part|del|osa|dalis|daļa|cast|časť|část|sklop|grupa|tranche|perceel|paket|delprocedure|teil)\s*(?:n[ro°º.]*\s*|no\.?\s*|nr\.?\s*|#\s*)?(\d{1,4}[a-z]?)\b', t)
    if m:
        return m.group(1)
    m = re.match(r'\s*(\d{1,3})\s*[.):\-–]\s+\S', t)
    return m.group(1) if m else None


TED_ROOT_KIND = {'TED-VAL_TOTAL': 'result_total', 'TED-VALUE': 'result_total', 'TED-VALUE_COST': 'result_total',
                 'TED-VAL_ESTIMATED_TOTAL': 'estimate_total', 'TED-TOTAL_ESTIMATED.LOW_VALUE': 'estimate_range_low',
                 'TED-TOTAL_ESTIMATED.HIGH_VALUE': 'estimate_range_high', 'TED-LOW_VALUE': 'estimate_range_low',
                 'TED-HIGH_VALUE': 'estimate_range_high', 'TED-LOW': 'result_range_low', 'TED-HIGH': 'result_range_high'}


def lot_number(key):
    """canonical.rs lot_number: the lot number a numbered lot key spells, else None."""
    k = (key or '').strip()
    d = k
    if k[:3].lower() == 'lot':
        d = k[3:]
        if d[:1] in ('-', ' ', '_'):
            d = d[1:]
    if not d or not d.isascii() or not d.isdigit():
        return None
    return d.lstrip('0') or '0'


def norm_no(p):
    """A published lot number reduced to its leading integer (\'Lot 3\' -> \'3\', \'LOT-0003\' -> \'3\')."""
    if p is None:
        return None
    m = re.search(r'\d+', str(p))
    return (m.group(0).lstrip('0') or '0') if m else None



def notice_facts(n, source):
    """Per notice: scheme, form, framework evidence, stated totals, per-lot and per-result facts."""
    out = {'form': None, 'framework': [], 'totals': [], 'lots': {}, 'results': {}, 'scheme': None}
    nted = nbt = 0
    for s in n['sections']:
        fids = {}
        for v in s['values']:
            fids.setdefault(v['field_id'], []).append(v)
            if v['field_id'].startswith('TED-'):
                nted += 1
            elif v['field_id'][:3] in ('BT-', 'OPT', 'OPP'):
                nbt += 1
        for f in ('BT-105-Procedure', 'DE1-TenderingProcess-ProcedureCode'):
            if f in fids and out.get('procedure') is None:
                out['procedure'] = val(fids[f][0])
        if out.get('procedure') is None:
            pts = [f[7:] for f in fids if f.startswith('TED-PT_')]
            if pts:
                out['procedure'] = 'TED:' + pts[0]
        for f in ('TED-FORM', 'BT-02-notice', 'OPP-070-notice', 'DE1-NoticeSubType-SubTypeCode'):
            if f in fids and out['form'] is None:
                out['form'] = val(fids[f][0])
        for f, vs in fids.items():
            if f in ('BT-765-Lot', 'BT-766-Lot'):
                for v in vs:
                    out['framework'].append({'section': s['section_id'], 'field': f, 'value': val(v)})
            elif f == 'DE1-ProcurementProjectLot-TenderingProcess-ContractingSystem-ContractingSystemTypeCode':
                for v in vs:
                    out['framework'].append({'section': s.get('parent_section_id'), 'field': 'BT-765-Lot' if str(val(v)).startswith('fa') else 'BT-766-Lot', 'value': val(v), 'de1': True})
            elif f.startswith('TED-') and ('FRAMEWORK' in f or f in ('TED-DPS', 'TED-DPS_ADDITIONAL_PURCHASERS')):
                out['framework'].append({'section': s['section_id'], 'field': f, 'value': val(vs[0])})
        for f, vs in fids.items():
            for v in vs:
                if v.get('type') != 'amount':
                    continue
                kind = None
                if f in RESULT_TOTAL_FIELDS:
                    kind = RESULT_TOTAL_FIELDS[f]
                elif s['kind'] == 'Notice' and f.startswith('TED-'):
                    kind = TED_ROOT_KIND.get(f, 'other:' + f)
                elif s['kind'] == 'Modification':
                    kind = 'modification:' + f
                if kind:
                    out['totals'].append({'field': f, 'kind': kind, 'cents': v.get('cents'), 'currency': v.get('currency'),
                                          'section': s['section_id']})
        if s['kind'] in ('Lot', 'Part', 'LotsGroup', 'ProcurementProjectLot'):
            L = {'kind': s['kind']}
            for f, lab in (('TED-LOT_NO', 'lot_no'), ('TED-LOT_NUMBER', 'lot_no'), ('BT-137-Lot', 'lot_no'), ('BT-137-Part', 'lot_no'),
                           ('BT-137-LotsGroup', 'lot_no'), ('TED-ITEM', 'item'), ('BT-22-Lot', 'internal_id'),
                           ('DE1-ProcurementProjectLot-ID', 'lot_no'), ('DE1-ProcurementProject-ID', 'internal_id'),
                           ('TED-TITLE', 'title'), ('BT-21-Lot', 'title'), ('BT-21-Part', 'title'), ('DE1-ProcurementProject-Name', 'title')):
                if f in fids and lab not in L:
                    L[lab] = val(fids[f][0])
            amts = {}
            for f, vs in fids.items():
                for v in vs:
                    if v.get('type') == 'amount':
                        amts.setdefault(f, []).append([v.get('cents'), v.get('currency')])
            if amts:
                L['amounts'] = amts
            out['lots'][s['section_id']] = L
        if s['kind'] == 'LotResult':
            R = {}
            for f, lab in (('TED-LOT_NO', 'lot_no'), ('TED-LOT_NUMBER', 'lot_no'), ('TED-ITEM', 'item'), ('TED-TITLE', 'title'),
                           ('TED-CONTRACT_NO', 'contract_no'), ('BT-13713-LotResult', 'lot_ref'), ('BT-142-LotResult', 'decision'),
                           ('DE1-NoticeResult-LotResult-TenderLot-ID', 'lot_ref'), ('DE1-NoticeResult-LotResult-TenderResultCode', 'decision')):
                if f in fids and lab not in R:
                    R[lab] = val(fids[f][0])
            amts = {}
            for f, vs in fids.items():
                for v in vs:
                    if v.get('type') == 'amount':
                        amts.setdefault(f, []).append([v.get('cents'), v.get('currency')])
            if amts:
                R['amounts'] = amts
            out['results'][s['section_id']] = R
    for s in n['sections']:
        par = s.get('parent_section_id')
        if par in out['results'] and s['kind'] != 'LotResult':
            for v in s['values']:
                if v.get('type') == 'amount':
                    out['results'][par].setdefault('amounts', {}).setdefault(v['field_id'], []).append([v.get('cents'), v.get('currency')])
    if source == 'fts':
        out['scheme'] = 'fts-ocds'
    else:
        nde = sum(1 for s2 in n['sections'] for v in s2['values'] if v['field_id'].startswith('DE1-'))
        out['scheme'] = 'eforms-de' if nde > max(nted, nbt) else ('ted-legacy' if nted > nbt else 'eforms')
    return out


def v_is_flag(v):
    return v.get('type') in ('integer', 'code', 'id', None) or isinstance(val(v), (int, bool))


rows = []
unread = []
for t in ids:
    lab = final[t]
    x, src = load_detail(t)
    row = {'id': int(t), 'label': {'verdict': lab['verdict'], 'class': lab['class'], 'group': lab['group']}}
    if x is None:
        row['unreadable'] = True
        rows.append(row); unread.append(int(t)); continue
    K, A, by_cur, counted, excluded, unit = path_w(x)
    row.update(detail_source=src, source=x.get('source'), country=x.get('country'), procedure_type=x.get('procedure_type'),
               served_value_at_fetch=x.get('value'), served_derivation_at_fetch=x.get('value_derivation'),
               unit=unit)
    # notices
    nfacts = {}
    nsrc = {}
    missing_n = []
    for nid in need.get(t, []):
        n, ns = load_notice(nid)
        if n is None:
            missing_n.append(nid); continue
        nfacts[nid] = notice_facts(n, x.get('source'))
        nsrc[nid] = ns
    row['notices_read'] = [{'notice_id': nid, 'src': nsrc[nid], 'scheme': nfacts[nid]['scheme'], 'form': nfacts[nid]['form']}
                           for nid in sorted(nfacts)]
    if missing_n:
        row['notices_unread'] = missing_n
    row['procedure_type_src'] = 'tender detail' if x.get('procedure_type') else None
    if not x.get('procedure_type'):
        for nid in sorted(nfacts, reverse=True):
            if nfacts[nid].get('procedure'):
                row['procedure_type'] = nfacts[nid]['procedure']
                row['procedure_type_src'] = f'notice {nid}'
                break
    # framework flag
    fw_ev = []
    for nid, nf in sorted(nfacts.items()):
        for e in nf['framework']:
            fw_ev.append(dict(e, notice_id=nid))
    dps_cls = [c for c in x.get('classifications', []) if c.get('scheme') == 'dps' or (c.get('field') or '').startswith('dps')]
    # True: any BT-765/766 framework or DPS code, any TED framework field, or a dps classification.
    # False: an eForms lot coded 'none' on both and nothing truthy; or a read legacy F02/F03/F05/F06
    # (forms that state FRAMEWORK when it applies) carrying no framework field. Else null.
    def truthy(e):
        v = e['value']
        if e['field'] in ('BT-765-Lot', 'BT-766-Lot'):
            return v in FW_CODES or v in DPS_CODES
        return v not in (0, '0', None, False, 'false', 'none')
    if any(truthy(e) for e in fw_ev) or dps_cls:
        is_fw = True
    elif any(e['field'] == 'BT-765-Lot' for e in fw_ev):
        is_fw = False
    elif any(nf['scheme'] == 'ted-legacy' and nf['form'] in ('F02', 'F03', 'F05', 'F06') for nf in nfacts.values()):
        is_fw = False
    else:
        is_fw = None
    tl = ' '.join([x.get('title') or ''] + [t.get('value') or '' for t in x.get('texts', []) if t.get('field') in ('title', 'description')])
    row['framework_word_in_text'] = bool(re.search(r'(?i)framework|rahmenvertrag|rahmenvereinbarung|accord[- ]cadre|accordo quadro|acuerdo marco|umow\w* ramow|keretmeg|raamovereenkomst|rammeaftale|ramavtal|puitesopimus|acordo-quadro|rámcov|okvirn|acord-cadru|рамково', tl))
    row['is_framework'] = is_fw
    row['framework_evidence'] = fw_ev[:40] + ([{'dps_classification': c} for c in dps_cls][:5])
    # stated totals
    totals = []
    for nid, nf in sorted(nfacts.items()):
        for tt in nf['totals']:
            totals.append(dict(tt, notice_id=nid))
    row['stated_totals'] = totals
    def nvalued(nid):
        return sum(1 for lr in x.get('lot_results', []) if lr['notice_id'] == nid and lr.get('lot')
                   and (lr.get('awarded') or {}).get('cents') is not None and figure(lr['awarded']['cents']))
    for tt in totals:
        tt['notice_valued_lot_results'] = nvalued(tt['notice_id'])
    prim = None
    order = ['result_total', 'framework_max_total', 'framework_reestimate_total', 'estimate_total']
    cand = [tt for tt in totals if tt['cents'] is not None and figure(tt['cents']) and tt['kind'] in order]
    if cand:
        # the notice awarding the most valued lots first (a single-lot notice's BT-161 is that lot's figure),
        # then result before framework-max before estimate, then the newest notice
        cand.sort(key=lambda tt: (-tt['notice_valued_lot_results'], order.index(tt['kind']), -tt['notice_id'], tt['field'] == 'TED-VALUE'))
        c0 = cand[0]
        prim = {'cents': c0['cents'], 'currency': c0['currency'], 'field': c0['field'], 'kind': c0['kind'], 'notice_id': c0['notice_id'],
                'notice_valued_lot_results': c0['notice_valued_lot_results']}
    row['stated_total'] = prim
    row['lotnull_amounts'] = [{'field': a['field'], 'cents': a['value']['cents'], 'currency': a['value']['currency']}
                              for a in x.get('amounts', []) if a.get('lot') is None]
    # ---- part 2 extension: the same facts over EVERY version notice (contract notices included), kept
    # beside part 0's fields (which read only the summed award notices + the newest result notice) so
    # the four parts stay comparable field for field.
    n_summed_w = len(A) if K else 0
    nf_all = dict(nfacts); ns_all = dict(nsrc); missing_v = []
    for nid in sorted(set(vnotices.get(t, [])) | set(nfacts)):
        if nid in nf_all:
            continue
        n, ns = load_notice(nid)
        if n is None:
            missing_v.append(nid); continue
        nf_all[nid] = notice_facts(n, x.get('source')); ns_all[nid] = ns
    row['version_notices_read'] = [{'notice_id': nid, 'src': ns_all[nid], 'scheme': nf_all[nid]['scheme'], 'form': nf_all[nid]['form'],
                                    'valued_lot_results': nvalued(nid), 'in_part0_set': nid in nfacts} for nid in sorted(nf_all)]
    row['version_notices_unread'] = missing_v
    row['version_notices_not_fetched'] = vskipped.get(t, [])
    tot_all = []
    for nid, nf in sorted(nf_all.items()):
        own = [lr['awarded']['cents'] for lr in x.get('lot_results', []) if lr['notice_id'] == nid and lr.get('lot')
               and (lr.get('awarded') or {}).get('cents') is not None and figure(lr['awarded']['cents'])]
        for tt in nf['totals']:
            e = dict(tt, notice_id=nid, notice_form=nf['form'], notice_valued_lot_results=len(own))
            # a TED contract notice / PIN root value is the II.1.5 estimate, not a result
            if e['kind'] == 'result_total' and nf['form'] in TED_CN_FORMS:
                e['kind'] = 'estimate_total'; e['kind_relabelled_from'] = 'result_total'
            # a total in a notice valuing exactly one lot result that equals (1 %) that award IS the lot's figure
            e['equals_its_single_lot_award'] = (len(own) == 1 and e['cents'] is not None
                                                and abs(e['cents'] - own[0]) * 100 <= max(own[0], 1))
            tot_all.append(e)
    row['stated_totals_all_versions'] = tot_all
    # a procedure total from any notice: a single-lot notice's total equal to its own award is left out
    # when the head sums >= 2 lots (it stays in the list above)
    cand_all = [tt for tt in tot_all if tt['cents'] is not None and figure(tt['cents']) and tt['kind'] in order
                and not (tt['equals_its_single_lot_award'] and n_summed_w >= 2)]
    cand_all.sort(key=lambda tt: (-tt['notice_valued_lot_results'], order.index(tt['kind']), -tt['notice_id'], tt['field'] == 'TED-VALUE'))
    row['stated_total_any_notice'] = ({k2: cand_all[0][k2] for k2 in ('cents', 'currency', 'field', 'kind', 'notice_id', 'notice_form',
                                                                       'notice_valued_lot_results')} if cand_all else None)
    row['single_lot_notice_totals_left_out'] = sum(1 for tt in tot_all if tt['cents'] is not None and figure(tt['cents']) and tt['kind'] in order
                                                   and tt['equals_its_single_lot_award'] and n_summed_w >= 2)
    fw_all = [dict(e, notice_id=nid) for nid, nf in sorted(nf_all.items()) for e in nf['framework']]
    if any(truthy(e) for e in fw_all) or dps_cls:
        row['is_framework_all_versions'] = True
    elif any(e['field'] == 'BT-765-Lot' for e in fw_all):
        row['is_framework_all_versions'] = False
    elif any(nf['scheme'] == 'ted-legacy' and nf['form'] in ('F02', 'F03', 'F05', 'F06') for nf in nf_all.values()):
        row['is_framework_all_versions'] = False
    else:
        row['is_framework_all_versions'] = None
    row['framework_evidence_all_versions'] = [e for e in fw_all if truthy(e)][:20] or fw_all[:10]
    if not row.get('procedure_type'):
        for nid in sorted(nf_all, reverse=True):
            if nf_all[nid].get('procedure'):
                row['procedure_type'] = nf_all[nid]['procedure']
                row['procedure_type_src'] = f'notice {nid}'
                break
    row['reader_notes'] = reader_notes.get(t)
    # lots
    amt_by_lot = collections.defaultdict(lambda: collections.defaultdict(list))
    for a in x.get('amounts', []):
        if a.get('lot'):
            amt_by_lot[a['lot']][a['field']].append([a['value']['cents'], a['value']['currency']])
    results_by_lot = collections.defaultdict(list)
    for lr in x.get('lot_results', []):
        results_by_lot[lr.get('lot')].append(lr)
    lot_keys = [l['lot_key'] for l in x.get('lot_details', [])]
    for k in results_by_lot:
        if k and k not in lot_keys:
            lot_keys.append(k)
    lot_meta = {l['lot_key']: l for l in x.get('lot_details', [])}
    bids_by_lot = collections.defaultdict(list)
    for bd in x.get('bids', []):
        v = bd.get('value') or {}
        bids_by_lot[bd.get('lot')].append({'notice_id': bd.get('notice_id'), 'key': bd.get('key'), 'cents': v.get('cents'),
                                           'currency': v.get('currency'),
                                           'tenderer_ids': [q.get('organization_id') for q in bd.get('parties', []) if q.get('role') == 'tenderer']})
    lots_out = []
    summed = []
    for key in lot_keys:
        lm = lot_meta.get(key, {})
        ests = amt_by_lot[key].get('estimated_value', [])
        est_k = [c for c, cu in ests if cu == K and figure(c)] if K else []
        est_any = [(c, cu) for c, cu in ests if figure(c)]
        per_notice = {}
        for nid, nf in sorted(nfacts.items()):
            L = nf['lots'].get(key)
            if L:
                d = {k2: L[k2] for k2 in ('kind', 'lot_no', 'item', 'internal_id', 'title', 'amounts') if k2 in L}
                if 'lot_no' not in d and nf['scheme'] == 'fts-ocds':
                    d['lot_no'] = key  # OCDS lot id is the section id
                    d['lot_no_is_section_id'] = True
                per_notice[str(nid)] = d
        awards = []
        for lr in sorted(results_by_lot.get(key, []), key=lambda r: (r['notice_id'], r.get('key') or '')):
            a = lr.get('awarded') or {}
            aw = {'notice_id': lr['notice_id'], 'result_key': lr.get('key'),
                  'contractor_names': [w.get('organization_name') for w in lr.get('winners', [])],
                  'contractor_ids': [w.get('organization_id') for w in lr.get('winners', [])],
                  'cents': a.get('cents'), 'currency': a.get('currency'), 'decision': lr.get('decision')}
            nf = nfacts.get(lr['notice_id'])
            if nf and lr.get('key') in nf['results']:
                R = nf['results'][lr['key']]
                aw['notice_result'] = {k2: R[k2] for k2 in ('lot_no', 'item', 'title', 'contract_no', 'lot_ref', 'decision', 'amounts') if k2 in R}
            awards.append(aw)
        # published lot number: the summed award's notice (its lot section, then its result block, then titles),
        # else the newest read notice whose lot section carries one, else the lot title in the detail
        pub = None; pub_src = None
        s_lr = A.get(key) if K else None
        ref = s_lr
        if ref is None:
            valued = [lr for lr in results_by_lot.get(key, []) if lr['notice_id'] in nfacts]
            ref = max(valued, key=lambda r: r['notice_id']) if valued else None
        if ref is not None and ref['notice_id'] in nfacts:
            nid = ref['notice_id']; nf = nfacts[nid]
            L = per_notice.get(str(nid))
            R = nf['results'].get(ref.get('key'), {})
            if L and L.get('lot_no') is not None:
                pub, pub_src = L['lot_no'], f'lot section {key} of notice {nid}'
            elif R.get('lot_no') is not None:
                pub, pub_src = R['lot_no'], f"result {ref.get('key')} (TED-LOT_NO) of notice {nid}"
            elif L and title_lot_no(L.get('title')):
                pub, pub_src = title_lot_no(L['title']), f'lot title in notice {nid}'
            elif title_lot_no(R.get('title')):
                pub, pub_src = title_lot_no(R['title']), f"result {ref.get('key')} title in notice {nid}"
        summed_notice_read = s_lr is not None and s_lr['notice_id'] in nfacts
        if pub is None and summed_notice_read:
            # a summed lot's number comes from its own award notice only (TED LOT-k is a per-notice ordinal)
            pub_src = f"none in summed notice {s_lr['notice_id']}"
        if pub is None and not summed_notice_read:
            for nid in sorted(per_notice, key=int, reverse=True):
                if per_notice[nid].get('lot_no') is not None:
                    pub, pub_src = per_notice[nid]['lot_no'], f'lot section {key} of notice {nid}'
                    break
        if pub is None and not summed_notice_read and title_lot_no(lm.get('title')):
            pub, pub_src = title_lot_no(lm.get('title')), 'lot title (tender detail)'
        # estimate: the API's keyed estimated_value; else the read notices' lot-section estimate
        # (TED-VAL_OBJECT / BT-27-Lot), else the summed result block's initial estimate (TED-VAL_ESTIMATED_TOTAL)
        est = None; est_cur = None; est_src = None
        if est_k:
            est, est_cur, est_src = max(est_k), K, 'api keyed estimated_value'
        elif est_any:
            est, est_cur = max(est_any)
            est_src = 'api keyed estimated_value (other currency)'
        else:
            for nid in sorted(per_notice, key=int, reverse=True):
                am = per_notice[nid].get('amounts', {})
                for f in ('BT-27-Lot', 'TED-VAL_OBJECT'):
                    vs = [(c, cu) for c, cu in am.get(f, []) if c is not None and figure(c)]
                    if vs and est is None:
                        est, est_cur = max(vs); est_src = f'notice {nid} lot section {f}'
                if est is not None:
                    break
            if est is None and ref is not None and ref['notice_id'] in nfacts:
                R = nfacts[ref['notice_id']]['results'].get(ref.get('key'), {})
                vs = [(c, cu) for c, cu in R.get('amounts', {}).get('TED-VAL_ESTIMATED_TOTAL', []) if c is not None and figure(c)]
                if vs:
                    est, est_cur = max(vs); est_src = f"notice {ref['notice_id']} result {ref.get('key')} TED-VAL_ESTIMATED_TOTAL"
        kn = lot_number(key)
        pn = norm_no(pub)
        lo = {'key': key, 'kind': lm.get('kind'), 'title': lm.get('title'), 'counted': key in counted,
              'key_number': kn,
              'published_lot_no': pub, 'published_lot_no_norm': pn, 'published_lot_no_src': pub_src,
              'key_matches_published': (kn == pn) if (kn is not None and pn is not None) else None,
              'lot_no_by_notice': per_notice,
              'estimate_cents': est, 'currency': est_cur, 'estimate_src': est_src,
              'lot_amounts': {f: v for f, v in amt_by_lot[key].items()},
              'awards': awards,
              'bids': bids_by_lot.get(key, [])[:60],
              'n_bids': len(bids_by_lot.get(key, [])),
              'summed': s_lr is not None}
        # part 2 extension: this key's lot section in every version notice (a TED key is a per-notice
        # ordinal, so a same-key section of another notice may be another lot: compare lot_no), and the
        # estimate a version notice gives to a lot section whose published number equals this lot's
        lv = {}
        for nid, nf in sorted(nf_all.items()):
            L = nf['lots'].get(key)
            if L:
                d = {k2: L[k2] for k2 in ('kind', 'lot_no', 'item', 'title') if k2 in L}
                am = L.get('amounts', {})
                ests = [(c, cu, f) for f in ('BT-27-Lot', 'TED-VAL_OBJECT', 'TED-VAL_ESTIMATED_TOTAL') for c, cu in am.get(f, []) if c is not None and figure(c)]
                if ests:
                    d['estimate'] = {'cents': max(ests)[0], 'currency': max(ests)[1], 'field': max(ests)[2]}
                d['form'] = nf['form']
                lv[str(nid)] = d
        lo['lot_section_by_version_notice'] = lv
        est_ln = None
        if pn is not None:
            for nid, nf in sorted(nf_all.items(), reverse=True):
                for sk, L in nf['lots'].items():
                    if norm_no(L.get('lot_no')) != pn or not re.fullmatch(r'\s*(?:lot\s*[-_ ]?)?0*\d+\s*', str(L.get('lot_no')), re.I):
                        continue
                    am = L.get('amounts', {})
                    ests = [(c, cu, f) for f in ('BT-27-Lot', 'TED-VAL_OBJECT') for c, cu in am.get(f, []) if c is not None and figure(c)]
                    if ests:
                        c, cu, f = max(ests)
                        est_ln = {'cents': c, 'currency': cu, 'field': f, 'notice_id': nid, 'section': sk, 'lot_no': L.get('lot_no')}
                        break
                if est_ln:
                    break
        lo['estimate_by_published_lot_no'] = est_ln
        lots_out.append(lo)
        if s_lr is not None:
            nfS = nfacts.get(s_lr['notice_id'])
            RS = nfS['results'].get(s_lr.get('key'), {}) if nfS else {}
            LS = nfS['lots'].get(key, {}) if nfS else {}
            r_no = RS.get('lot_no') if RS.get('lot_no') is not None else RS.get('lot_ref')
            sec_no = LS.get('lot_no')
            summed.append({'key': key, 'notice_id': s_lr['notice_id'], 'result_key': s_lr.get('key'),
                           'summed_notice_read': nfS is not None,
                           'lot_section_lot_no': sec_no, 'lot_section_item': LS.get('item'),
                           'result_lot_no': r_no, 'result_item': RS.get('item'),
                           'result_lot_no_matches_lot_section': (norm_no(r_no) == norm_no(sec_no)) if (r_no is not None and sec_no is not None) else None,
                           'cents': s_lr['awarded']['cents'], 'currency': K, 'published_lot_no': pub,
                           'key_matches_published': lo['key_matches_published'],
                           'notice_valued_lot_results': sum(1 for lr in x.get('lot_results', []) if lr['notice_id'] == s_lr['notice_id'] and lr.get('lot') and (lr.get('awarded') or {}).get('cents') is not None and figure(lr['awarded']['cents'])),
                           'contractor_ids': [w.get('organization_id') for w in s_lr.get('winners', [])],
                           'contractor_names': [w.get('organization_name') for w in s_lr.get('winners', [])]})
    row['lots'] = lots_out
    row['summed_currency'] = K
    row['summed_lots'] = summed
    row['n_summed'] = len(summed)
    row['sum_cents'] = sum(s['cents'] for s in summed) if summed else None
    row['max_lot_award_cents'] = max(s['cents'] for s in summed) if summed else None
    row['other_currency_award_lots'] = {c: len(v) for c, v in by_cur.items() if c != K}
    # whether the served value at fetch time is still path W's sum
    sv = x.get('value') or {}
    row['served_is_lot_sum_at_fetch'] = (x.get('value_derivation') or {}).get('method') == 'lot-sum-awards'
    row['rebuilt_sum_equals_served'] = (sv.get('cents') == row['sum_cents'] and sv.get('currency') == K) if summed else False
    rows.append(row)

json.dump(rows, open(W + '/features_part3.json', 'w'), ensure_ascii=False, indent=1)
print('rows', len(rows), 'unreadable', unread)
