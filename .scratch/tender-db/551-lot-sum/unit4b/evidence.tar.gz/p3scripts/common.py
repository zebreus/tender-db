import json, os, collections
S = '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad'
W = S + '/d551w'
P0 = W + '/p3'
FLOOR = 1000
_idx = json.load(open(W + '/shapes_work/cache_index.json'))


def sentinel(c):
    if c < 0:
        return True
    major = str(c // 100)
    return len(major) >= 7 and len(set(major)) == 1 and c % 100 == 0


def figure(c):
    return c is not None and c > FLOOR and not sentinel(c)


def load_detail(t):
    """Fresh fetch first (p0/tenders), then the earlier copies."""
    p = f'{P0}/tenders/{t}.json'
    if os.path.exists(p):
        return json.load(open(p)), 'fresh-2026-10-17'
    for q in _idx.get(t, []):
        try:
            return json.load(open(os.path.join(S, q))), 'postdrain-cache'
        except Exception:
            pass
    q = f'{W}/shapes_work/api/{t}.json'
    if os.path.exists(q):
        return json.load(open(q)), 'shapes-fetch-2026-10-17'
    return None, None


def path_w(x):
    """Path W's LotSums awards: per currency, each counted lot's LATEST award by notice id
    (tie to the later offer), figure > 10.00 and not a sentinel, excluded kinds skipped.
    Currency K: the served head's currency when it has award lots, else the most award
    lots (tie to the greater code)."""
    lots = {l['lot_key']: l for l in x.get('lot_details', [])}
    unit = 'Lot' if any(l['kind'] == 'Lot' for l in lots.values()) else 'Part'
    excluded = {k for k, l in lots.items() if l['kind'] != unit}
    counted = {k for k, l in lots.items() if l['kind'] == unit}
    by_cur = collections.defaultdict(dict)
    for lr in x.get('lot_results', []):
        a = lr.get('awarded') or {}
        lot = lr.get('lot')
        if not lot or a.get('cents') is None or not a.get('currency'):
            continue
        if lot in excluded or not figure(a['cents']):
            continue
        cur = by_cur[a['currency']]
        prev = cur.get(lot)
        if prev is None or lr['notice_id'] >= prev['notice_id']:
            cur[lot] = lr
    if not by_cur:
        return None, {}, by_cur, counted, excluded, unit
    served = x.get('value') or {}
    if served.get('currency') in by_cur:
        k = served['currency']
    else:
        k = max(by_cur, key=lambda c: (len(by_cur[c]), c))
    return k, by_cur[k], by_cur, counted, excluded, unit
