import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
src = open('j2.py').read()
exec(src.split("W13 = lambda")[0].split("lab, F, ids = S.load()")[1])
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
KINDS_ALL = None
def vouch_hits(r, tol=0.01, kinds=None):
    Sv = r['sum_cents']; cur = r['summed_currency']; singles = {s['cents'] for s in r['summed_lots']}
    out = []
    for t in r.get('stated_totals_all_versions') or []:
        if kinds and t['kind'] not in kinds: continue
        if t.get('currency') != cur or not S.figure(t.get('cents')): continue
        if t.get('equals_its_single_lot_award') or t['cents'] in singles: continue
        if abs(t['cents'] - Sv) <= tol * Sv: out.append((t['kind'], t.get('field')))
    return out
W13 = lambda f: any(f[c] for c in ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10'))
def W14(i): return W13(F[i]) or no_own_bid(rows[i])
for kinds_name, kinds in [('all kinds', None), ('no range/modif', {'result_total','estimate_total','framework_max_total','framework_reestimate_total'})]:
    v = {i for i in ids if vouch_hits(rows[i], kinds=kinds)}
    print('==', kinds_name)
    print(' vouched, wrongs:', [(i, lab[i]['class'], vouch_hits(rows[i], kinds=kinds)[:2]) for i in sorted(v) if lab[i]['verdict']=='wrong'])
    print(' vouched, neutrals:', [i for i in sorted(v) if lab[i]['verdict']=='neutral'])
    for name, ship in [('V0 alone', lambda i: i in v), ('V0 and not W14', lambda i: i in v and not W14(i)), ('V0 and not W13', lambda i: i in v and not W13(F[i]))]:
        d = collections.Counter()
        for i in ids:
            g = lab[i]['group'].split('-')[0]; g = 'band' if g in ('top','mid') else g
            if ship(i): d[(g, lab[i]['verdict'])] += 1
        print(' ', name, dict(d), 'wrong shipped:', [i for i in ids if ship(i) and lab[i]['verdict']=='wrong'])
    print(' sample vouched kinds:', collections.Counter(k for i in v if lab[i]['group'].startswith('sample') for k,_ in set(vouch_hits(rows[i], kinds=kinds))))
    print(' sample vouched ids:', [i for i in sorted(v) if lab[i]['group'].startswith('sample')])
