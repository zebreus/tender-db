import sys; sys.path.insert(0, "/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge")
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
def W14(i): return W13(F[i]) or no_own_bid(rows[i])
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
def v2(i): return W14(i) or (band(i) and not vouch_hits(rows[i]))
def vv(i): return W14(i) or not vouch_hits(rows[i])
for name, ref in [('W14', W14), ('v2', v2), ('vouched-everywhere', vv)]:
    d = collections.Counter()
    for i in ids:
        g = 'band' if band(i) else 'sample'
        d[('ref' if ref(i) else 'ship', g, lab[i]['verdict'])] += 1
    print(name, sorted(d.items()))
    print('  band ships', [(i, lab[i]['verdict']) for i in ids if band(i) and not ref(i)] if name != 'W14' else '')
    print('  sample ships', len([i for i in ids if not band(i) and not ref(i)]))
print('cp 0/32', S.cp_bounds(0, 32), '32/50', S.cp_bounds(32, 50), '8/50', S.cp_bounds(8, 50))
for p in (0.01, 0.02, 0.03, 0.05, 0.08, 0.10): print(p, round(S.binom_cdf(1, 30, p), 2))
