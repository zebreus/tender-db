import sys, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
lab, F, ids = S.load()
C = dict(S.candidates())
names = ['W9 = W2 with Bm_g for Bm_t','W10 = W9 without A','W12 = W9+DOM10','W13 = W12 without A','A+B+C+D+E','shapes SH6 (T0 + 5 tiers)','Z (task: no fw flag, distinct contractors on distinct LOT_NOs, total stated and S <= total)']
for n in names:
    p = C[n]
    out = collections.defaultdict(list)
    for i in ids:
        if not p(F[i]):
            L = lab[i]
            out[(L['group'].split('-')[0], L['verdict'], L['class'])].append(i)
    print('==', n)
    for k in sorted(out):
        if k[1] != 'right' or True:
            print('  ', k, len(out[k]), out[k] if k[1] != 'right' else '')
