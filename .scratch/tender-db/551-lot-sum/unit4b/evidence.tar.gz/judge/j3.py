import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
exec(open('j2.py').read().split("W13 = lambda")[0].split("lab, F, ids = S.load()")[1])
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
def vouched(r, tol=0.01):
    Sv = r['sum_cents']; cur = r['summed_currency']
    singles = {s['cents'] for s in r['summed_lots']}
    for t in r.get('stated_totals_all_versions') or []:
        if t.get('currency') != cur or not S.figure(t.get('cents')): continue
        if t.get('equals_its_single_lot_award') or t['cents'] in singles: continue
        if abs(t['cents'] - Sv) <= tol * Sv: return True
    return False
print('kinds', collections.Counter(t['kind'] for r in rows.values() for t in (r.get('stated_totals_all_versions') or [])))
W13 = lambda f: any(f[c] for c in ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10'))
c = collections.Counter((lab[i]['group'].split('-')[0] in ('top','mid'), lab[i]['verdict']) for i in ids if vouched(rows[i]))
print('vouched (band?, verdict):', dict(c))
def W14(i): return W13(F[i]) or no_own_bid(rows[i])
for name, q in [('W14', W14), ('W14+bandvouch', lambda i: W14(i) or (eur(rows[i]) >= 100e6 and not vouched(rows[i])))]:
    d = collections.Counter(); sw = []; br = []
    for i in ids:
        g = lab[i]['group'].split('-')[0]; g = 'band' if g in ('top','mid') else g
        if not q(i):
            d[(g, lab[i]['verdict'])] += 1
            if lab[i]['verdict'] != 'right': sw.append((i, lab[i]['verdict'], lab[i]['class'], g))
            elif g == 'band': br.append(i)
        else: d[('ref', lab[i]['verdict'])] += 1
    print(name, dict(d), 'non-right shipped:', sw)
    print('  band rights shipped:', len(br), br[:40])
