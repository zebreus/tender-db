import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
# no_own_bid: a summed lot whose summed notice publishes bids (any lot) but none for this lot
def no_own_bid(r):
    lots = {l['key']: l for l in r['lots']}
    nb = collections.defaultdict(set)
    for l in r['lots']:
        for b in l.get('bids', []):
            nb[b['notice_id']].add(l['key'])
    for s in r['summed_lots']:
        n = s['notice_id']
        if nb.get(n) and s['key'] not in nb[n]:
            return True
    return False
RATE = {'EUR':1,'GBP':1.17,'PLN':0.23,'CHF':1.05,'SEK':0.088,'NOK':0.086,'DKK':0.134,'CZK':0.04,'HUF':0.0025,'RON':0.2,'BGN':0.51,'USD':0.92,'ISK':0.0066,'HRK':0.13}
def eur(r):
    v = r['served_value_at_fetch'] or {}
    c = r['sum_cents']; cur = r['summed_currency']
    return c/100*RATE.get(cur, 1)
W13 = lambda f: any(f[c] for c in ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10'))
W12 = lambda f: W13(f) or f['A']
c = collections.Counter(lab[i]['verdict'] for i in ids if no_own_bid(rows[i]))
print('no_own_bid W/N/R', c['wrong'], c['neutral'], c['right'], [i for i in ids if no_own_bid(rows[i]) and lab[i]['verdict']=='wrong'])
for name, p in [('W13', W13), ('W12', W12)]:
    for extra in ['none', 'nob', 'cap100m', 'nob+cap100m']:
        def q(i):
            f = F[i]
            ref = p(f)
            if 'nob' in extra: ref = ref or no_own_bid(rows[i])
            if 'cap100m' in extra: ref = ref or eur(rows[i]) >= 100e6
            return ref
        d = collections.Counter()
        shipw = []
        for i in ids:
            g = lab[i]['group'].split('-')[0]; g = 'band' if g in ('top','mid') else g
            if not q(i):
                d[(g, lab[i]['verdict'])] += 1
                if lab[i]['verdict'] == 'wrong': shipw.append((i, lab[i]['class'], g))
            else:
                d[(g, 'ref_'+lab[i]['verdict'])] += 1
        s_ship = d[('sample','right')]+d[('sample','wrong')]+d[('sample','neutral')]
        b_ship = d[('band','right')]+d[('band','wrong')]+d[('band','neutral')]
        print(f"{name}+{extra}: band ships {b_ship} (w {d[('band','wrong')]}), sample ships {s_ship} (w {d[('sample','wrong')]}), rights refused {d[('band','ref_right')]+d[('sample','ref_right')]}/160, shipped wrongs {shipw}")
# sample heads >= 100m
print('sample >=100m:', [(i, round(eur(rows[i])/1e6,1), lab[i]['verdict']) for i in ids if lab[i]['group'].startswith('sample') and eur(rows[i]) >= 100e6])
print('sample S_eur quantiles:', sorted(round(eur(rows[i])) for i in ids if lab[i]['group'].startswith('sample'))[::5])
