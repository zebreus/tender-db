import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
for i in [683951, 707424, 726354, 1062828, 1102571, 1147190, 1148297, 5842187, 6017838, 6057925, 6195903, 6370901, 7001924, 7011414, 7388206, 8426318, 5278856, 6450467, 8831876]:
    r = rows[i]; Sv = r['sum_cents']; cur = r['summed_currency']; singles = {s['cents'] for s in r['summed_lots']}
    hits = [(t['kind'], t.get('field'), t['notice_id'], t['cents']) for t in (r.get('stated_totals_all_versions') or [])
            if t.get('currency') == cur and S.figure(t.get('cents')) and not t.get('equals_its_single_lot_award') and t['cents'] not in singles and abs(t['cents']-Sv) <= 0.01*Sv]
    print(i, lab[i]['verdict'], cur, Sv, hits[:3])
print(json.dumps((rows[8426318].get('stated_totals_all_versions') or [])[:3], default=str)[:800])
