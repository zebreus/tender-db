import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w')
import score as S
def no_own_bid(r):
    nb = collections.defaultdict(set)
    for l in r['lots']:
        for b in l.get('bids', []):
            nb[b['notice_id']].add(l['key'])
    return any(nb.get(s['notice_id']) and s['key'] not in nb[s['notice_id']] for s in r['summed_lots'])
def vouch_hits(r, tol=0.01, kinds=None):
    Sv = r['sum_cents']; cur = r['summed_currency']; singles = {s['cents'] for s in r['summed_lots']}
    out = []
    for t in r.get('stated_totals_all_versions') or []:
        if kinds and t['kind'] not in kinds: continue
        if t.get('currency') != cur or not S.figure(t.get('cents')): continue
        if t.get('equals_its_single_lot_award') or t['cents'] in singles: continue
        if abs(t['cents'] - Sv) <= tol * Sv: out.append((t['kind'], t.get('field')))
    return out
W13 = lambda f: any(f[c] for c in ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10'))
