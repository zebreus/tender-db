import sys; sys.path.insert(0, "/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge")
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
def W14(i): return W13(F[i]) or no_own_bid(rows[i])
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
v2 = lambda i: W14(i) or (band(i) and not vouch_hits(rows[i], kinds=K))
vv = lambda i: W14(i) or not vouch_hits(rows[i], kinds=K)
for name, ref in [('v2', v2), ('vv', vv)]:
    d = collections.Counter(('ref' if ref(i) else 'ship', 'band' if band(i) else 'sample', lab[i]['verdict']) for i in ids)
    print(name, sorted(d.items()))
# fields of the vouching totals in the sample (for vv)
print(collections.Counter(f for i in ids if not band(i) and not vv(i) for k, f in set(vouch_hits(rows[i], kinds=K))))
# which W14 checks fire alone on the sample's wrongs (principled vs post hoc)
for i in ids:
    if not band(i) and lab[i]['verdict']=='wrong':
        f = F[i]; on = [c for c in ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10') if f[c]] + (['nob'] if no_own_bid(rows[i]) else [])
        print(i, lab[i]['class'], on)
