"""Strict-to-rule-text port vs the judge's v2: which in-sample outcomes depend on facts the rule text / B1 does not carry."""
import sys, json, collections, copy
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
sh = json.load(open(S.SHAPES))
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
CHECKS = ('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10')
def v2(f, r, b, kinds=K):
    if any(f[c] for c in CHECKS) or no_own_bid(r): return True
    return b and not vouch_hits(r, kinds=kinds)

AWARD_FIELDS = {'BT-161-NoticeResult','TED-VAL_TOTAL','BT-118-NoticeResult','BT-1118-NoticeResult'}
VOUCH_FIELDS = AWARD_FIELDS | {'BT-27-Procedure','TED-VAL_ESTIMATED_TOTAL','TED-LOW','TED-HIGH'}
def strict_row(r, mode):
    r = copy.deepcopy(r)
    if 'totals' in mode:
        out = []
        for t in r.get('stated_totals_all_versions') or []:
            fld = t['field']
            if fld in AWARD_FIELDS and t['kind'] in ('result_total','framework_max_total','framework_reestimate_total'):
                out.append(t)
            elif fld in VOUCH_FIELDS:
                # keep as an estimate / range (not an award total)
                t = dict(t); 
                if t['kind'] in ('result_total','framework_max_total','framework_reestimate_total'):
                    t['kind'] = 'estimate_total'
                out.append(t)
        r['stated_totals_all_versions'] = out
    if 'lotno' in mode:
        for s in r['summed_lots']:
            if s.get('published_lot_no') is not None:
                L = next(l for l in r['lots'] if l['key'] == s['key'])
                if 'title' in (L.get('published_lot_no_src') or ''):
                    s['published_lot_no'] = None
    if 'est' in mode:
        for L in r['lots']:
            if L.get('estimate_src') and not L['estimate_src'].startswith('api keyed'):
                L['estimate_cents'] = None
            L['estimate_by_published_lot_no'] = None
    return r
base = {i: v2(F[i], rows[i], band(i)) for i in ids}
for mode in (('totals',), ('lotno',), ('est',), ('totals','lotno','est')):
    diff = []
    for i in ids:
        r2 = strict_row(rows[i], mode)
        f2 = S.facts(r2, sh.get(str(i)))
        d = v2(f2, r2, band(i))
        if d != base[i]:
            diff.append((i, lab[i]['verdict'], lab[i]['class'], 'band' if band(i) else 'samp', 'ref->SHIP' if base[i] else 'ship->REF',
                         [c for c in CHECKS if F[i][c]] + (['R9'] if no_own_bid(rows[i]) else [])))
    print(mode, len(diff))
    for d in diff: print('  ', d)
