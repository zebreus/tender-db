"""B1 as written: TED ITEM is a published lot number fallback. Re-score v2."""
import sys, json, collections, copy
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
sh = json.load(open(S.SHAPES))
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
def v2(f, r, b):
    if W13(f) or no_own_bid(r): return True
    return b and not vouch_hits(r, kinds=K)
def item_row(r):
    r = copy.deepcopy(r)
    for s in r['summed_lots']:
        if s.get('published_lot_no') is None:
            it = s.get('result_item') or s.get('lot_section_item')
            if it: s['published_lot_no'] = it
    # the per-notice C_vary path: lot sections / results with item but no lot_no
    for L in r['lots']:
        for nid, d in (L.get('lot_section_by_version_notice') or {}).items():
            if d.get('lot_no') is None and d.get('item'): d['lot_no'] = d['item']
        for nid, d in (L.get('lot_no_by_notice') or {}).items():
            if d.get('lot_no') is None and d.get('item'): d['lot_no'] = d['item']
        for a in L.get('awards', []):
            nr = a.get('notice_result')
            if nr and nr.get('lot_no') is None and nr.get('item'): nr['lot_no'] = nr['item']
    return r
d = collections.Counter(); flips = []
for i in ids:
    b0 = v2(F[i], rows[i], band(i))
    r2 = item_row(rows[i]); f2 = S.facts(r2, sh.get(str(i)))
    b1 = v2(f2, r2, band(i))
    d[('ref' if b1 else 'ship', 'band' if band(i) else 'samp', lab[i]['verdict'])] += 1
    if b0 != b1: flips.append((i, lab[i]['verdict'], lab[i]['class'], 'band' if band(i) else 'samp', 'ref->SHIP' if b0 else 'ship->REF'))
print(sorted(d.items())); print(flips)
