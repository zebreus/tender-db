import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
c = collections.Counter(); ex=[]
for i in ids:
    byn = collections.defaultdict(list)
    for t in rows[i].get('stated_totals_all_versions') or []:
        byn[t['notice_id']].append(t)
    for nid, ts in byn.items():
        flds = {t['field'] for t in ts if t['kind']=='result_total'}
        if flds & {'TED-VALUE','TED-VALUE_COST'} and 'TED-VAL_TOTAL' not in flds:
            c['notice with TED-VALUE(_COST) result total, no VAL_TOTAL'] += 1; ex.append((i, nid, sorted(flds), [ (t['field'], t['cents'], t.get('notice_form')) for t in ts if t['kind']=='result_total'][:3]))
            break
print(c); print(ex[:12])
# does TED-VALUE ever differ from VAL_TOTAL in the same notice?
d=collections.Counter()
for i in ids:
    byn = collections.defaultdict(dict)
    for t in rows[i].get('stated_totals_all_versions') or []:
        byn[t['notice_id']].setdefault(t['field'], set()).add(t['cents'])
    for nid, m in byn.items():
        if 'TED-VALUE' in m and 'TED-VAL_TOTAL' in m:
            d['same' if m['TED-VALUE'] & m['TED-VAL_TOTAL'] else 'differ'] += 1
print(d)
