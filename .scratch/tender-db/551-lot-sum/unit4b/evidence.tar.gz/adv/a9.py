import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
sh = json.load(open(S.SHAPES))
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
T0 = ('clos_nw', 'later_closed', 'award_eq_est_total', 'award_eq_whole', 'award_gt_bid_sum', 'gt2_bt709', 'bt709_sum_lt_S',
          'ge15_est_min', 'equal_bids_eq_ceiling', 'award_n_times_ref', 'tiny', 'proc_est_eq_each_lot_est', 'lot_est_all_equal',
          'est_sum_lt_S3', 'ge3_est')
CH=('Bm_g','C_plus','D_keys','E','C_title','P10','DOM10')
vw = [i for i in ids if lab[i]['verdict']=='wrong' and vouch_hits(rows[i], kinds=K)]
print('vouched wrongs:', len(vw))
for i in vw:
    f=F[i]
    on=[c for c in CH if f[c]] + ['T0:'+k for k in T0 if sh[str(i)]['f'].get(k)] + (['R9'] if no_own_bid(rows[i]) else [])
    print(i, lab[i]['class'], lab[i]['group'], f['cur'], f['S']/100, sorted(set(vouch_hits(rows[i], kinds=K))), on, {k:f[k] for k in ('C','C_list','C_vary','C_absent') if f[k]})
