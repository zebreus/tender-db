import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
sh = json.load(open(S.SHAPES))
T0 = ('clos_nw', 'later_closed', 'award_eq_est_total', 'award_eq_whole', 'award_gt_bid_sum', 'gt2_bt709', 'bt709_sum_lt_S',
          'ge15_est_min', 'equal_bids_eq_ceiling', 'award_n_times_ref', 'tiny', 'proc_est_eq_each_lot_est', 'lot_est_all_equal',
          'est_sum_lt_S3', 'ge3_est')
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
CH=('Bm_g','C_plus','D_keys','E','C_title','P10','DOM10')
print('sample rights refused:')
for i in ids:
    if band(i) or lab[i]['verdict']!='right': continue
    f=F[i]; on=[c for c in CH if f[c]] + ['T0:'+k for k in T0 if sh[str(i)]['f'].get(k)] + (['R9'] if no_own_bid(rows[i]) else [])
    if on: print(' ', i, f['cur'], f['S']/100, f['n'], on, {k:f[k] for k in ('C','C_list','C_vary','C_absent') if f[k]})
# per-check hit counts on the 279 (wrong/neutral/right), and 'sole refuser' counts
print()
allc = list(CH)+['T0:'+k for k in T0]+['R9']
def hits(i):
    f=F[i]; return set([c for c in CH if f[c]] + ['T0:'+k for k in T0 if sh[str(i)]['f'].get(k)] + (['R9'] if no_own_bid(rows[i]) else []))
H={i:hits(i) for i in ids}
for c in allc:
    cnt=collections.Counter(lab[i]['verdict'] for i in ids if c in H[i])
    sole=collections.Counter(lab[i]['verdict'] for i in ids if H[i]=={c})
    print(f'{c:28s} hits W{cnt["wrong"]:3d} N{cnt["neutral"]:2d} R{cnt["right"]:3d} | sole W{sole["wrong"]:2d} N{sole["neutral"]} R{sole["right"]}')
print('wrongs with no check (band, caught only by R10):', [i for i in ids if lab[i]['verdict']=='wrong' and not H[i]][:40], len([i for i in ids if lab[i]['verdict']=='wrong' and not H[i]]))
