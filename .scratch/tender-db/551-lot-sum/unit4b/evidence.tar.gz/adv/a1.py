import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
def W14(i): return W13(F[i]) or no_own_bid(rows[i])
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
# fields of all stated totals in the 279
fc = collections.Counter((t['kind'], t['field']) for i in ids for t in rows[i].get('stated_totals_all_versions') or [])
for k,v in sorted(fc.items(), key=lambda x:-x[1]): print(v, k)
print()
for i in ids:
    if W14(i): continue
    vh = vouch_hits(rows[i], kinds=K)
    print(i, 'band' if band(i) else 'samp', lab[i]['verdict'], lab[i]['class'], F[i]['cur'], F[i]['S']/100, sorted(set(vh)))
