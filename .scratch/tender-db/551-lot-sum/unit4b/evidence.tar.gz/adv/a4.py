import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
K = {'result_total','estimate_total','framework_max_total','framework_reestimate_total','result_range_high','result_range_low'}
def v2(i):
    if W13(F[i]) or no_own_bid(rows[i]): return True
    return band(i) and not vouch_hits(rows[i], kinds=K)
mm = collections.Counter(); ex = []
for i in ids:
    r = rows[i]
    bad = [s['key'] for s in r['summed_lots'] if s.get('result_lot_no_matches_lot_section') is False]
    if bad:
        mm[(lab[i]['verdict'], 'ship' if not v2(i) else 'ref')] += 1; ex.append((i, lab[i]['verdict'], lab[i]['class'], bad[:3]))
print('result LOT_NO != lot section LOT_NO:', mm); print(ex[:20])
# ITEM-as-lot-number: summed lots whose published lot no is None (so R2(d) can fire) but the result/lot has an ITEM
c = collections.Counter(); ex2=[]
for i in ids:
    r = rows[i]
    for s in r['summed_lots']:
        if s.get('published_lot_no') is None and (s.get('result_item') or s.get('lot_section_item')):
            c[(lab[i]['verdict'], F[i]['multi_notice'])] += 1; ex2.append((i, lab[i]['verdict'], lab[i]['class'], s['key'], s.get('result_item'), s.get('lot_section_item'))); break
print('summed lot w/o published lot no but with TED ITEM:', c); print(ex2[:30])
# which of these depend on C_absent for refusal (only refusing check)
CH=('Bm_g','C_plus','D_keys','E','T0','C_title','P10','DOM10')
for (i, v, cl, *_ ) in ex2:
    f = F[i]
    on = [c for c in CH if f[c]] + (['R9'] if no_own_bid(rows[i]) else [])
    cplus_wo_absent = f['C'] or f['C_list'] or f['C_vary']
    print(i, v, cl, 'band' if band(i) else 'samp', on, 'C_plus only via absent' if f['C_plus'] and not cplus_wo_absent else '')
