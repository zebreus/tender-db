import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
R = {'EUR':1,'HUF':380,'PLN':4.4,'CHF':1.0,'GBP':0.86,'BGN':1.96,'DKK':7.45,'CZK':25,'SEK':11,'NOK':11,'RON':4.9,'HRK':7.5,'USD':1.1}
band = lambda i: lab[i]['group'].split('-')[0] in ('top','mid')
def eur(i): return F[i]['S']/100 / R.get(F[i]['cur'], 1)
b = collections.defaultdict(collections.Counter)
for i in ids:
    if band(i): continue
    e = eur(i)
    k = '<1k' if e < 1e3 else '<100k' if e < 1e5 else '<1m' if e < 1e6 else '<10m' if e < 1e7 else '<100m'
    b[k][lab[i]['verdict']] += 1
    ship = not (W13(F[i]) or no_own_bid(rows[i]))
    b[k]['v2ship_'+lab[i]['verdict']] += ship
for k in ('<1k','<100k','<1m','<10m','<100m'): print(k, dict(b[k]))
