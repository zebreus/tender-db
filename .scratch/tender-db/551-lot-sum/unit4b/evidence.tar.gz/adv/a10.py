import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
AW = {'BT-161-NoticeResult','TED-VAL_TOTAL','BT-118-NoticeResult','BT-1118-NoticeResult'}
ES = {'BT-27-Procedure','TED-VAL_ESTIMATED_TOTAL'}
RG = {'TED-LOW','TED-HIGH'}
c = collections.Counter(); W = collections.defaultdict(list)
for i in ids:
    vh = {f for k, f in vouch_hits(rows[i])}
    if not vh: continue
    cat = 'award' if vh & AW else 'estimate' if vh & ES else 'range' if vh & RG else 'other:' + ','.join(sorted(vh))
    c[(cat, lab[i]['verdict'])] += 1
    if lab[i]['verdict'] != 'right': W[cat].append((i, lab[i]['verdict'], lab[i]['class'], sorted(vh)))
for k in sorted(c): print(k, c[k])
for k, v in W.items(): print(k, v)
