import sys, json, collections
sys.path.insert(0, '/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/d551w/judge')
from common import *
lab, F, ids = S.load()
rows = {r['id']: r for r in json.load(open(S.FEAT))}
sh = json.load(open(S.SHAPES))
T0 = ('clos_nw', 'later_closed', 'award_eq_est_total', 'award_eq_whole', 'award_gt_bid_sum', 'gt2_bt709', 'bt709_sum_lt_S',
          'ge15_est_min', 'equal_bids_eq_ceiling', 'award_n_times_ref', 'tiny', 'proc_est_eq_each_lot_est', 'lot_est_all_equal',
          'est_sum_lt_S3', 'ge3_est')
for i in (324582, 831972, 5779166, 6330626, 6421819, 7056700, 5976305, 6545090, 249185):
    f = F[i]; g = sh[str(i)]['f']
    print(i, lab[i]['class'], 'T0:', [k for k in T0 if g.get(k)], 'C:', {k: f[k] for k in ('C','C_list','C_vary','C_absent','multi_notice')})
    for s in rows[i]['summed_lots']:
        L = next(l for l in rows[i]['lots'] if l['key']==s['key'])
        print('    ', s['key'], s['notice_id'], s['cents'], 'pub', repr(s.get('published_lot_no')), L.get('published_lot_no_src'))
