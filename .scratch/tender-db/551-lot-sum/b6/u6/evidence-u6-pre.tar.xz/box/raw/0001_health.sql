SELECT 1
-- plan: (health: no plan)
