SELECT n.id, n.ingested_at FROM notices n WHERE n.id > 47423724 AND n.id <= 47424725 ORDER BY n.id
-- plan: SEARCH n USING INTEGER PRIMARY KEY (rowid=?)
