import json, os, re, difflib
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k6_skeptic/live'
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k6'
def ld(name):
    p=f'{L}/{name}'
    if not os.path.exists(p): p=f'{C}/{name}'
    return json.load(open(p))
def nt(s):
    s=s.lower(); s=re.sub(r'^(część|zadanie|lote|lot|los)\s*[\divxl]+\s*[:.\-–]?\s*','',s); s=re.sub(r'[^\w ]+',' ',s); return ' '.join(s.split())
for tid in [5937259,6174432,6684838,6853217,7005973,7098097,6994978,7495648,7596364,7721489,5787834]:
    t=ld(f'tender_{tid}.json')
    maps={}
    for n in [v['caused_by_notice_id'] for v in t['versions']]:
        m={}
        for s in ld(f'notice_{n}.json')['sections']:
            if s['kind']=='Lot':
                tt=[v['value'] for v in s['values'] if v['field_id']=='TED-TITLE']
                m[s['section_id']]=tt[0] if tt else ''
        if m: maps[n]=m
    ns=list(maps)
    for i in range(len(ns)):
        for j in range(i+1,len(ns)):
            for k in sorted(set(maps[ns[i]])&set(maps[ns[j]])):
                a,b=nt(maps[ns[i]][k]),nt(maps[ns[j]][k])
                r=difflib.SequenceMatcher(None,a,b).ratio()
                if r<0.8: print(tid,k,ns[i],repr(maps[ns[i]][k][:70]),ns[j],repr(maps[ns[j]][k][:70]),round(r,2))
    # results not from versions
    vids={v['caused_by_notice_id'] for v in t['versions']}
    odd=[r['notice_id'] for r in t['lot_results'] if r['notice_id'] not in vids]
    if odd: print(tid,'results from non-version notices',odd)
