import json, sys, os
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k6_skeptic/live'
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k6'
def ld(name):
    p=f'{L}/{name}'
    if not os.path.exists(p): p=f'{C}/{name}'
    return json.load(open(p)), p
for tid in sys.argv[1:]:
    t,tp=ld(f'tender_{tid}.json')
    print('='*90); print('TENDER',tid,'from',tp.split('/')[-2],'v',t['version'],'lots',t['lots'])
    print(' versions',[(v['caused_by_notice_id'],v['published_at']) for v in t['versions']])
    nids=[v['caused_by_notice_id'] for v in t['versions']]
    for r in t['lot_results']:
        if r['notice_id'] not in nids: nids.append(r['notice_id'])
    for n in nids:
        try: c,cp=ld(f'notice_{n}.json')
        except FileNotFoundError: print(' NOTICE',n,'missing'); continue
        hdr={}
        for s in c['sections']:
            if s['kind']=='Notice':
                for v in s['values']:
                    if v['field_id'] in ('TED-FORM','TED-TD_DOCUMENT_TYPE','TED-DATE_PUB','TED-NO_DOC_OJS','TED-REF_NOTICE.NO_DOC_OJS','TED-NOTICE_NUMBER_OJ','TED-SCHEMA_VERSION','TED-VERSION'): hdr.setdefault(v['field_id'].replace('TED-',''),[]).append(v.get('value', v.get('code')))
        print(' NOTICE',n,cp.split('/')[-2],hdr)
        for s in c['sections']:
            if s['kind'] in ('Lot','LotResult'):
                d={}
                for v in s['values']: d.setdefault(v['field_id'],[]).append(str(v.get('value',v.get('code'))))
                extra=''
                if s['kind']=='LotResult': extra=' flags='+','.join(k.replace('TED-','') for k in d if k in ('TED-AWARDED_CONTRACT','TED-NO_AWARDED_CONTRACT','TED-PROCUREMENT_UNSUCCESSFUL','TED-PROCUREMENT_DISCONTINUED'))
                print('   ',s['kind'][:6],s['section_id'],'ITEM',d.get('TED-ITEM'),'NO',d.get('TED-LOT_NO',d.get('TED-LOT_NUMBER')),'T',[x[:90] for x in d.get('TED-TITLE',d.get('TED-LOT_TITLE',d.get('TED-CONTRACT_TITLE',[])))],extra)
    print(' SERVED lots',[(l['lot_key'],(l['title'] or '')[:70],l['version']) for l in t['lot_details']])
    for r in t['lot_results']: print('   res',r['notice_id'],r['key'],'->',r['lot'],r['decision'],[w['organization_name'][:40] for w in r['winners']])
