import json, os, re
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k6_skeptic/live'
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k6'
def ld(name):
    p=f'{L}/{name}'
    if not os.path.exists(p): p=f'{C}/{name}'
    return json.load(open(p))
def norm(x):
    if x is None: return None
    m=re.fullmatch(r'\s*(?:lot|lote|los|part|część|zadanie|no\.?|n°|nr\.?)?\s*0*(\d+)\s*', x, re.I)
    return m.group(1) if m else x.strip().lower()
tids=[5529451,5740924,5787834,6016695,5937259,6174432,6430411,6581378,8449282,6684838,6853217,7005973,7098097,6994978,7495648,7596364,7721489]
for tid in tids:
    t=ld(f'tender_{tid}.json')
    nids=[v['caused_by_notice_id'] for v in t['versions']]
    maps={}
    for n in nids:
        c=ld(f'notice_{n}.json')
        m={}
        for s in c['sections']:
            if s['kind']=='Lot':
                d={}
                for v in s['values']: d.setdefault(v['field_id'],[]).append(str(v.get('value',v.get('code'))))
                no=(d.get('TED-LOT_NO') or d.get('TED-LOT_NUMBER') or [None])[0]
                m[s['section_id']]=(norm(no),(d.get('TED-TITLE') or [''])[0][:40])
        if m: maps[n]=m
    dis=[]
    ns=list(maps)
    for i in range(len(ns)):
        for j in range(i+1,len(ns)):
            a,b=maps[ns[i]],maps[ns[j]]
            for k in set(a)&set(b):
                if a[k][0]!=b[k][0]: dis.append((k,ns[i],a[k][0],ns[j],b[k][0]))
            ra={v[0]:k for k,v in a.items()}; rb={v[0]:k for k,v in b.items()}
            for no in set(ra)&set(rb):
                if ra[no]!=rb[no]: dis.append(('no',no,ns[i],ra[no],ns[j],rb[no]))
    unn=[n for n,m in maps.items() if any(v[0] is None for v in m.values())]
    print(tid,'versions',len(nids),'lot-notices',len(maps),'disagree',dis[:6],'unnumbered',unn)
