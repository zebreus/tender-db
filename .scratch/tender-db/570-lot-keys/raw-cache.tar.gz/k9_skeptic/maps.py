# k9 skeptic: per tender, every version notice's Lot sections (key -> printed LOT_NO/LOT_NUMBER, ITEM, title, short descr)
# and LotResult sections; cross-notice disagreement; each served result's block number vs the served lot's number in every notice.
import json, sys, re, os
R='/home/user/tender-db/.scratch/tender-db/570-lot-keys'
C=R+'/cache_k9'; L=R+'/k9_skeptic/live'
NOF=('TED-LOT_NO','TED-LOT_NUMBER')
def vals(s,f): return [x.get('value',x.get('code')) for x in s['values'] if x['field_id'] in f]
def nn(x):
    x=str(x).strip().lower(); x=re.sub(r'^(lot|lote|los|lotto|part|część|pakiet|zadanie|nr\.?|no\.?|n\.)\s*','',x); x=x.lstrip('0') or '0'; return x
def first(s,f): v=vals(s,f); return str(v[0]) if v else ''
for tid in sys.argv[1:]:
    p=f'{L}/tender_{tid}.json'
    t=json.load(open(p if os.path.exists(p) else f'{C}/tender_{tid}.json'))
    nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
    maps={}; res={}
    print('='*100); print('TENDER',tid,'live' if os.path.exists(p) else 'cache')
    for n in nids:
        c=json.load(open(f'{C}/notice_{n}.json'))
        kinds={}
        for s in c['sections']: kinds[s['kind']]=kinds.get(s['kind'],0)+1
        m={}
        for s in c['sections']:
            if s['kind']=='Lot':
                m[s['section_id']]=dict(num=tuple(nn(x) for x in vals(s,NOF)), raw=vals(s,NOF), item=vals(s,('TED-ITEM',)),
                    title=first(s,('TED-TITLE','TED-LOT_TITLE')), sd=first(s,('TED-SHORT_DESCR',))[:70])
            if s['kind']=='LotResult':
                res[(n,s['section_id'])]=dict(num=tuple(nn(x) for x in vals(s,NOF)), raw=vals(s,NOF), title=first(s,('TED-TITLE','TED-CONTRACT_TITLE')))
        print(' notice',n,'kinds',kinds)
        for k,v in sorted(m.items(), key=lambda kv:int(re.sub(r'\D','',kv[0]) or 0)):
            print('   ',k,'no',v['raw'],'item',v['item'],'|',v['title'][:70],'| sd:',v['sd'])
        if m: maps[n]=m
    print(' notices with lot sections:',len(maps),list(maps))
    keys=sorted({k for m in maps.values() for k in m}, key=lambda k:int(re.sub(r'\D','',k) or 0))
    dis=[]
    for k in keys:
        nums={n:m[k]['num'] for n,m in maps.items() if k in m}
        if len(set(v for v in nums.values() if v))>1: dis.append((k,'num',nums))
    for n1,m1 in maps.items():
        for n2,m2 in maps.items():
            if n1>=n2: continue
            r1={v['num']:k for k,v in m1.items() if v['num']}; r2={v['num']:k for k,v in m2.items() if v['num']}
            for num in set(r1)&set(r2):
                if r1[num]!=r2[num]: dis.append((num,'numkey',(n1,r1[num],n2,r2[num])))
    print(' number disagreements:',len(dis))
    for d in dis: print('   ',d)
    served={l['lot_key']:l['title'] for l in t['lot_details']}
    bad=0
    for r in sorted(t['lot_results'], key=lambda r:(r['notice_id'],int(re.sub(r'\D','',r['key']) or 0))):
        b=res.get((r['notice_id'],r['key']),dict(num=(),raw=[],title=''))
        lot=r['lot']
        across=[(n,maps[n][lot]['raw']) for n in maps if lot in maps[n]] if lot else []
        nums_across={maps[n][lot]['num'] for n in maps if lot in maps[n] and maps[n][lot]['num']} if lot else set()
        flag=''
        if lot and b['num'] and nums_across and b['num'] not in nums_across: flag='  <-- MISMATCH'; bad+=1
        elif lot and b['num'] and len(nums_across)>1: flag='  <-- AMBIG'
        print('   res',r['notice_id'],r['key'],'prints',b['raw'],repr(b['title'][:45]),'-> served',lot,repr((served.get(lot) or '')[:40]),'| lot across',across,flag)
    print(' results',len(t['lot_results']),'flagged',bad)
