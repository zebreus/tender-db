# print every served lot fact of one tender with the notices whose same-key section holds its value
import json, sys
sys.argv = sys.argv
exec(open('/home/user/tender-db/.scratch/tender-db/570-lot-keys/k10_tools/measure.py').read().split("g = json.load(open(ROOT")[0])
tid = int(sys.argv[1]); keys = sys.argv[2:]
t = json.load(open(f"{C}/tender_{tid}.json"))
vn = [v["caused_by_notice_id"] for v in t["versions"]]
N = {n: load_notice(n) for n in vn}
lotpub = [n for n in N if N[n]["lots"]]
for l in t["lot_details"]:
    if keys and l["lot_key"] not in keys: continue
    print("LOTDETAIL", l["lot_key"], l.get("title", "")[:60], l.get("value"), l.get("submission_deadline"))
for kind, lst in (("classification", "classifications"), ("text", "texts"), ("date", "dates"), ("amount", "amounts"), ("party", "parties")):
    for x in t.get(lst, []):
        K = x.get("lot")
        if not K or (keys and K not in keys): continue
        if kind == "classification": val = x["code"]; lab = f"cls:{x['scheme']}:{x['field']}"
        elif kind == "amount": v = x.get("value"); val = v["cents"] / 100 if isinstance(v, dict) else v; lab = "amount:" + x["field"]
        elif kind == "party": val = x.get("mention_name"); lab = "party:" + x["role"]; kind2 = "text"
        else: val = x["value"]; lab = kind + ":" + x["field"]
        kk = "text" if kind == "party" else kind
        home = [(n, N[n]["lots"][K]["no"]) for n in lotpub if K in N[n]["lots"] and fact_in(kk, val, N[n]["lots"][K])]
        print(K, lab, str(val)[:70].replace("\n", " "), "HOME", home)
