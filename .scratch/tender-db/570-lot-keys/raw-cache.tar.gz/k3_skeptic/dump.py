import json, sys, re
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k3_skeptic/live'
def sk(s):
    m=re.match(r'^([A-Z]+)-(\d+)$', s or ''); return (m.group(1), int(m.group(2))) if m else (s or '',0)
NUM=('TED-ITEM','TED-LOT_NO','TED-LOT_NUMBER','TED-CONTRACT_NO','TED-CONTRACT_NUMBER')
TIT=('TED-TITLE','TED-LOT_TITLE','TED-TITLE_CONTRACT','TED-CONTRACT_TITLE')
for tid in sys.argv[1:]:
    t=json.load(open(f'{L}/tender_{tid}.json'))
    print('='*90); print('TENDER',tid,t['title'][:80])
    for l in sorted(t['lot_details'], key=lambda l: sk(l['lot_key'])):
        print('  served', l['lot_key'], 'v', l['version'], '|', (l['title'] or '')[:90])
    for r in t['lot_results']:
        print('  result', r['notice_id'], r['key'], 'lot=', r['lot'], r['decision'], [w['organization_name'][:35] for w in r['winners']])
    for v in t['versions']:
        n=v['caused_by_notice_id']
        import os
        p=f'{L}/notice_{n}.json'
        c=json.load(open(p if os.path.exists(p) else f'{L}/../../cache_k3/notice_{n}.json'))
        doc=[x.get('code', x.get('value')) for s in c['sections'] for x in s['values'] if x['field_id'] in ('TED-TD_DOCUMENT_TYPE','TED-FORM')]
        print(' NOTICE', n, 'seq', v['seq'], v['published_at'], doc[:3], sorted({s['kind'] for s in c['sections']}))
        for s in sorted(c['sections'], key=lambda s: sk(s['section_id'])):
            if s['kind'] in ('Lot','LotsGroup','Part','LotResult'):
                nums=[(x['field_id'][4:], x.get('value')) for x in s['values'] if x['field_id'] in NUM]
                tits=[str(x.get('value'))[:80] for x in s['values'] if x['field_id'] in TIT]
                extra=''
                if s['kind']=='LotResult':
                    extra=[str(x.get('value'))[:30] for x in s['values'] if x['field_id'] in ('TED-OFFICIALNAME',)]
                print('   ', s['section_id'], s['kind'], 'par', s.get('parent_section_id'), nums, '|', tits, extra)
