import json,sys,os
C=sys.argv[1]
def num(s):
    for f in ('TED-LOT_NO','TED-LOT_NUMBER'):
        for v in s['values']:
            if v['field_id']==f: return v.get('value')
    return None
def fld(s,f):
    for v in s['values']:
        if v['field_id']==f: return v.get('value')
    return None
for fn in sorted(os.listdir(C)):
    if not fn.startswith('tender_') or 'reread' in fn: continue
    t=json.load(open(os.path.join(C,fn)))
    print('#### tender',t['id'],'versions',[(v['seq'],v['caused_by_notice_id']) for v in t['versions']])
    print('   lots:',t['lots'],[(l['lot_key'],(l.get('title') or '')[:50]) for l in t['lot_details']])
    print('   results:',[(r['key'],r.get('lot'),r.get('notice_id') or r.get('notice')) for r in t['lot_results']])
    for v in t['versions']:
        nid=v['caused_by_notice_id']
        p=os.path.join(C,f'notice_{nid}.json')
        if not os.path.exists(p): print('   MISSING notice',nid); continue
        n=json.load(open(p))
        kinds={}
        for s in n['sections']: kinds[s['kind']]=kinds.get(s['kind'],0)+1
        lots=[(s['section_id'],num(s),fld(s,'TED-ITEM'),(fld(s,'TED-TITLE') or '')[:45]) for s in n['sections'] if s['kind']=='Lot']
        res=[(s['section_id'],num(s),fld(s,'TED-ITEM'),(fld(s,'TED-TITLE') or '')[:35]) for s in n['sections'] if s['kind']=='LotResult']
        print('   notice',nid,kinds)
        for l in lots: print('      L',l)
        for r in res: print('      R',r)
