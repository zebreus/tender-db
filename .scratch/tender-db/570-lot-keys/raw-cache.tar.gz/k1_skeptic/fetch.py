import json, os, sys, time, subprocess
BASE='https://tenders.zebreus.click'
OUT='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k1_skeptic/live'
last=[0.0]
def get(path, out):
    for attempt in range(2):
        wait = 1.6 - (time.time()-last[0])
        if wait>0: time.sleep(wait)
        last[0]=time.time()
        tmp=out+'.tmp'
        r=subprocess.run(['curl','-sS','-o',tmp,'-w','%{http_code}','--max-time','120',BASE+path],capture_output=True,text=True)
        code=r.stdout.strip()
        print(time.strftime('%H:%M:%SZ',time.gmtime()), path, code, flush=True)
        if code=='200':
            os.rename(tmp,out); return True
        if code=='408' and attempt==0: continue
        with open(out+'.err','w') as f: f.write(code+'\n'+r.stderr)
        return False
for a in sys.argv[1:]:
    kind,i=a.split(':')
    if kind=='t': get(f'/v1/tenders/{i}', f'{OUT}/tender_{i}.json')
    else: get(f'/v1/notices/{i}/content', f'{OUT}/notice_{i}.json')
