import json,sys
def summ(path):
    d=json.load(open(path))
    out=[]
    for s in d['sections']:
        if s['kind'] in ('Lot','LotResult','Result','Change') or s['kind'] not in ('Procedure','Organization','Party'):
            vals={}
            for v in s['values']:
                f=v['field_id']
                if f in ('TED-LOT_NO','TED-LOT_NUMBER','TED-ITEM','TED-TITLE','TED-CONTRACT_NO','TED-VAL_TOTAL','TED-VAL_ESTIMATED_TOTAL','TED-VAL_OBJECT','TED-AWARDED_CONTRACT','TED-NO_AWARDED_CONTRACT'):
                    vals.setdefault(f,[]).append(v.get('value') if 'value' in v else v.get('code') or v.get('amount') or v)
            out.append((s['kind'],s['section_id'],s.get('parent_section_id'),vals))
    return out
for p in sys.argv[1:]:
    print('==',p)
    for r in summ(p):
        print(' ',r[0],r[1],'<',r[2],json.dumps(r[3],ensure_ascii=False)[:400])
