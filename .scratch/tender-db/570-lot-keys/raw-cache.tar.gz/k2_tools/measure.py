import json, re, sys
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k2"
LOTK = ("Lot", "LotsGroup", "Part")
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-LOT_TITLE", "TED-TITLE")
def norm(x):
    x = x.strip()
    d = re.findall(r"\d+", x)
    if len(d) == 1:
        return str(int(d[0]))
    return re.sub(r"[^0-9a-z]", "", x.lower())
def secmap(c, kinds):
    out = {}
    for s in c["sections"]:
        if s["kind"] in kinds:
            nos = [v["value"] for v in s["values"] if v["field_id"] in NOF and v["type"] == "id"]
            items = [v["value"] for v in s["values"] if v["field_id"] == "TED-ITEM"]
            tit = [v["value"] for v in s["values"] if v["field_id"] in TITF]
            out[s["section_id"]] = {"no": nos, "nno": [norm(x) for x in nos], "item": items, "title": tit[0] if tit else None}
    return out
g = [x for x in json.load(open("/home/user/tender-db/.scratch/tender-db/570-lot-keys/groups.json"))["groups"] if x["key"] == "k2"][0]["items"]
res = []
for it in g:
    tid = it["tender_id"]
    t = json.load(open(f"{C}/tender_{tid}.json"))
    notices = []
    for v in t["versions"]:
        n = v["caused_by_notice_id"]
        c = json.load(open(f"{C}/notice_{n}.json"))
        lots = secmap(c, LOTK)
        rs = secmap(c, ("LotResult",))
        notices.append((n, lots, rs))
    lotpub = [(n, l) for n, l, r in notices if l]
    # disagreement
    dis = []
    for i in range(len(lotpub)):
        for j in range(i + 1, len(lotpub)):
            a, b = lotpub[i][1], lotpub[j][1]
            for k in set(a) & set(b):
                if a[k]["nno"] and b[k]["nno"] and set(a[k]["nno"]) != set(b[k]["nno"]):
                    dis.append(("key", k, lotpub[i][0], a[k]["no"], lotpub[j][0], b[k]["no"]))
            na = {x: k for k, s in a.items() for x in s["nno"]}
            nb = {x: k for k, s in b.items() for x in s["nno"]}
            for x in set(na) & set(nb):
                if na[x] != nb[x]:
                    dis.append(("num", x, lotpub[i][0], na[x], lotpub[j][0], nb[x]))
    unnumbered = any(not s["nno"] for _, l in lotpub for s in l.values())
    # chain identity: the lot-publishing notice with the most lot sections (ties: earliest)
    ref = max(lotpub, key=lambda p: len(p[1])) if lotpub else None
    chain = {x: k for k, s in ref[1].items() for x in s["nno"]} if ref else {}
    served = {l["lot_key"]: l["title"] for l in t["lot_details"]}
    mis = []
    for r in t["lot_results"]:
        nn = [n for n in notices if n[0] == r["notice_id"]]
        if not nn:
            mis.append(("result-notice-not-in-versions", r["key"])); continue
        n, lots, rs = nn[0]
        sec = rs.get(r["key"])
        pno = sec["nno"][-1] if sec and sec["nno"] else None
        own = None
        if pno is not None:
            m = [k for k, s in lots.items() if pno in s["nno"]]
            own = m[0] if m else None
        want = chain.get(pno) if pno is not None else None
        if r["lot"] != own and r["lot"] is not None: mis.append(("SERVED!=OWN", r["notice_id"], r["key"], pno, own, r["lot"]))
        if r["lot"] is not None and want is not None and r["lot"] != want:
            mis.append((r["notice_id"], r["key"], "printed", pno, "own-sec", own, "served-lot", r["lot"], "chain-lot", want, "served-title", (served.get(r["lot"]) or "")[:40]))
    res.append({"tender": tid, "n_lotpub": len(lotpub), "lotpub": [p[0] for p in lotpub], "dis": dis, "unnumbered": unnumbered,
                "ref": ref[0] if ref else None, "n_results": len(t["lot_results"]), "null_results": sum(1 for r in t["lot_results"] if r["lot"] is None), "mis": mis})
for r in res:
    print(r["tender"], "lotpub", r["n_lotpub"], r["lotpub"], "unnum", r["unnumbered"], "ref", r["ref"], "results", r["n_results"], "null", r["null_results"])
    for d in r["dis"]: print("    DIS", d)
    for m in r["mis"]: print("    MIS", m)

def compact(lots):
    def sk(k):
        m = re.match(r"^([A-Z]+)-(\d+)$", k); return int(m.group(2)) if m else 0
    ks = sorted(lots, key=sk)
    pairs = [(sk(k), lots[k]["no"][-1] if lots[k]["no"] else "-") for k in ks]
    if all(str(a) == norm(b) for a, b in pairs):
        return f"LOT-1..{len(pairs)}=LOT_NO 1..{len(pairs)}" + (f" (printed {pairs[0][1]}..{pairs[-1][1]})" if pairs[0][1] != '1' else "")
    return ", ".join(f"LOT-{a}={b}" for a, b in pairs)
out = []
for it in g:
    tid = it["tender_id"]
    t = json.load(open(f"{C}/tender_{tid}.json"))
    parts = []
    for v in t["versions"]:
        n = v["caused_by_notice_id"]
        c = json.load(open(f"{C}/notice_{n}.json"))
        lots = secmap(c, LOTK)
        if lots:
            parts.append(f"{n}: {compact(lots)}")
    r = [x for x in res if x["tender"] == tid][0]
    out.append({"tender_id": tid, "maps": "; ".join(parts), **r})
json.dump(out, open("/home/user/tender-db/.scratch/tender-db/570-lot-keys/measure_k2.json", "w"), indent=1, ensure_ascii=False)
for o in out: print(o["tender_id"], "|", o["maps"])
