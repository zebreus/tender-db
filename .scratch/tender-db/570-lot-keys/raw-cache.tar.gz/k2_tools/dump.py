import json, sys, glob, re
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k2"
def sk(s):
    m = re.match(r"^([A-Z]+)-(\d+)$", s)
    return (m.group(1), int(m.group(2))) if m else (s, 0)
def vals(s, fids):
    out = []
    for v in s["values"]:
        if v["field_id"] in fids:
            out.append((v["field_id"].replace("TED-", ""), v.get("value", v.get("code"))))
    return out
NUMF = ("TED-ITEM", "TED-LOT_NO", "TED-LOT_NUMBER", "TED-CONTRACT_NO", "TED-CONTRACT_NUMBER")
TITF = ("TED-LOT_TITLE", "TED-TITLE", "TED-TITLE_CONTRACT")
def tdump(tid):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    print("=" * 100)
    print("TENDER", tid, "ver", t["version"], t["title"][:100])
    for l in sorted(t["lot_details"], key=lambda l: sk(l["lot_key"])):
        print("  servedlot", l["lot_key"], "v", l["version"], "|", (l["title"] or "")[:110])
    for r in sorted(t["lot_results"], key=lambda r: (r["notice_id"], sk(r["key"]))):
        print("  result", r["notice_id"], r["key"], "lot=", r["lot"], r["decision"], r["awarded"], [w["organization_name"][:30] for w in r["winners"]][:2])
    for v in t["versions"]:
        n = v["caused_by_notice_id"]
        c = json.load(open(f"{C}/notice_{n}.json"))
        td = None
        for s in c["sections"]:
            for x in s["values"]:
                if x["field_id"] == "TED-TD_DOCUMENT_TYPE":
                    td = x.get("code")
        fids = sorted({x["field_id"] for s in c["sections"] for x in s["values"]})
        print(" NOTICE", n, "seq", v["seq"], v["published_at"], "td", td, "kinds", sorted({s["kind"] for s in c["sections"]}))
        for s in sorted(c["sections"], key=lambda s: sk(s["section_id"])):
            if s["kind"] in ("Lot", "LotsGroup", "Part", "LotResult", "SettledContract", "LotTender"):
                print("   ", s["section_id"], s["kind"], "par", s["parent_section_id"], vals(s, NUMF), "|", [str(x[1])[:90] for x in vals(s, TITF)])
for tid in sys.argv[1:]:
    tdump(int(tid))
