import json, os, sys, time, urllib.request, urllib.error
BASE = "https://tenders.zebreus.click"
CACHE = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k2"
STAMP = "/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad/k2/.last"
def _wait():
    try:
        last = os.path.getmtime(STAMP)
    except OSError:
        last = 0
    w = 1.6 - (time.time() - last)
    if w > 0: time.sleep(w)
    open(STAMP, "w").close()
def get(path, cache):
    p = os.path.join(CACHE, cache)
    if os.path.exists(p):
        with open(p) as f: return json.load(f)
    tries = 0
    while True:
        _wait()
        req = urllib.request.Request(BASE + path, headers={"Accept": "application/json", "User-Agent": "tender-db-570-k2-measure"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.load(r)
            break
        except urllib.error.HTTPError as e:
            if e.code == 408 and tries == 0:
                tries += 1; continue
            raise
    with open(p, "w") as f: json.dump(data, f)
    return data
