# k9 dump: per tender, each notice's lot sections and award blocks (key, printed no, item, title) and served lots/results.
import json, sys
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k9"
def v(sec, f): return [x.get("value", x.get("code")) for x in sec["values"] if x["field_id"] in f]
for tid in sys.argv[1:]:
    t = json.load(open(f"{C}/tender_{tid}.json"))
    print("=== TENDER", tid, t["title"][:100], "| lots served:", [(l["lot_key"], (l.get("title") or "")[:60]) for l in t["lot_details"]])
    nids = [x["caused_by_notice_id"] for x in t["versions"]]
    for r in t["lot_results"]:
        if r["notice_id"] not in nids: nids.append(r["notice_id"])
    for n in nids:
        try: c = json.load(open(f"{C}/notice_{n}.json"))
        except FileNotFoundError: print("  notice", n, "MISSING"); continue
        nt = [s for s in c["sections"] if s["kind"] == "Notice"]
        form = v(nt[0], ("TED-FORM",)) if nt else None
        pub = v(nt[0], ("TED-DATE_PUB",)) if nt else None
        print("  notice", n, "form", form, "pub", pub)
        for s in c["sections"]:
            if s["kind"] in ("Lot", "LotsGroup", "Part"):
                print("    LOT", s["section_id"], "no", v(s, ("TED-LOT_NO", "TED-LOT_NUMBER")), "item", v(s, ("TED-ITEM",)), "|", (v(s, ("TED-TITLE", "TED-LOT_TITLE")) or [""])[0][:90])
            elif s["kind"] == "LotResult":
                print("    RES", s["section_id"], "no", v(s, ("TED-LOT_NO", "TED-LOT_NUMBER")), "item", v(s, ("TED-ITEM",)), "|", (v(s, ("TED-TITLE", "TED-CONTRACT_TITLE", "TED-LOT_TITLE")) or [""])[0][:90])
    for r in t["lot_results"]:
        print("  served", r["notice_id"], r["key"], "->", r["lot"], r.get("decision"), [w.get("organization_name", "")[:40] for w in r.get("winners", [])])
