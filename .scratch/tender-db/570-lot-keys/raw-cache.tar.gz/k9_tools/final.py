# k9 final: hand-checked classes over measure_k9.auto.json (auto run of k9_tools/measure.py); writes measure_k9.json.
# Hand changes: 7112657 auto "consistent" -> disagree_harmless (content-shown: F02 21853373's only, unnumbered section
# LOT-1 is lot 3). 5939039 stays "unnumbered" (the CAN's one unnumbered section is the whole procedure, not another lot).
import json
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
auto = {o["tender_id"]: o for o in json.load(open(ROOT + "/measure_k9.auto.json"))}
hand = {
    7112657: {"cls": "disagree_harmless", "results_misattributed": 0, "lot_facts_misattributed": 0,
              "harm": ["none served: F02 21853373 (2021-08-04, title '... LOTE 3: Servicios de implantación', SHORT_DESCR "
                       "'Error en el anexo Modelo 3 ... del lote 3') has ONE lot section, keyed LOT-1, no LOT_NO/no title, "
                       "SHORT_DESCR 'Servicios de implantación de un BPMS y desarrollo de aplicaciones' = CN 21736179 LOT-3 "
                       "(LOT_NO 3). Served LOT-1 keeps lot 1's title/description (from 21736179/22462819); its CPV 72200000 "
                       "and NUTS ES111 are the same in every lot, so indistinguishable; DURATION 24 is not served.",
                       "side note (not lot keying): 21853373's DATE_RECEIPT_TENDERS 2021-08-30 (lot 3's relaunch) is served as "
                       "the procedure-scope deadline of all 7 lots; the CN 21736179 said 2021-07-15."],
              "note": "classed on content, not printed number (the section prints none); number-only rule would call it unnumbered"},
    5939039: {"cls": "unnumbered", "results_misattributed": 0, "lot_facts_misattributed": 0,
              "harm": ["CAN 19505376's only lot section LOT-1 (ITEM 1, no LOT_NO, no title) is the whole-procedure section: "
                       "SHORT_DESCR 'Diverse Laborgeräte zur Lieferung an vier Endverwendungsorte in Kirgistan und Tajikistan.' "
                       "= both notices' procedure SHORT_DESCR, NUTS DE712. Served Tender LOT-1 carries that description and "
                       "NUTS DE712 instead of CN 19304106 LOT-1's 'Lieferung von Laborgeräten.' / DE259: 2 facts of procedure "
                       "scope on lot 1, not another lot's (not counted)."]},
}
out = []
for tid, o in auto.items():
    h = hand.get(tid, {})
    out.append({"tender_id": tid, "cls": h.get("cls", o["cls_auto"]), "cls_auto": o["cls_auto"],
                "n_notices_with_lot_sections": o["n_notices_with_lot_sections"],
                "lot_publishing_notices": o["lot_publishing_notices"], "versions": o["versions"],
                "results_total": o["results_total"], "results_null": o["results_null"],
                "results_misattributed": h.get("results_misattributed", o["results_misattributed"]),
                "lot_facts_total": o["lot_facts"]["total"],
                "lot_facts_misattributed": h.get("lot_facts_misattributed", o["lot_facts"]["misattributed"]),
                "harm": h.get("harm", []), "note": h.get("note"),
                "maps": o["maps"], "titles": o["titles"], "disagreements": o["disagreements"],
                "title_differences_same_key": o["title_differences_same_key"], "tender_lots": o["tender_lots"],
                "results": o["results"], "lot_facts": o["lot_facts"]})
json.dump(out, open(ROOT + "/measure_k9.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(Counter(x["cls"] for x in out), "results", sum(x["results_total"] for x in out),
      "null", sum(x["results_null"] for x in out),
      "mis", sum(x["results_misattributed"] for x in out), "facts", sum(x["lot_facts_total"] for x in out),
      "facts_mis", sum(x["lot_facts_misattributed"] for x in out))
