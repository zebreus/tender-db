# For each served lot fact (live tender detail), list which notices' Lot section at the SAME key carries the value,
# and which sections at ANY key do (with their printed numbers). Reads cache_k7 notices + k7_skeptic/live tender.
import json, sys, re, unicodedata
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k7'
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k7_skeptic/live'
def norm(s):
    s=unicodedata.normalize('NFKD',str(s or '')).lower()
    s=''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[\W_]+','',s)
tid=sys.argv[1]
t=json.load(open(f'{L}/tender_{tid}.json'))
nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
secs={}
for n in nids:
    try: c=json.load(open(f'{C}/notice_{n}.json'))
    except FileNotFoundError: print('MISSING notice',n); continue
    for s in c['sections']:
        if s['kind'] in ('Lot','LotResult'):
            secs[(n,s['kind'],s['section_id'])]=s
def has(s, kind, val):
    v=norm(val)
    for x in s['values']:
        if kind=='amount':
            if x.get('cents') is not None and x['cents']==val: return True
            continue
        for f in ('value','code'):
            if f in x and x[f] is not None:
                xv=norm(x[f])
                if xv==v or (len(v)>25 and (v[:80] in xv or xv[:80] in v) and min(len(v),len(xv))>25): return True
    return False
def no(s):
    return [x.get('value') for x in s['values'] if x['field_id'] in ('TED-LOT_NO','TED-LOT_NUMBER')]
bad=0; tot=0
rows=[]
for k in ('amounts','bids','contracts','dates','parties','classifications','texts'):
    for x in t[k]:
        if not isinstance(x,dict) or not x.get('lot'): continue
        rows.append((k,x))
for d in t['lot_details']:
    rows.append(('lot_details.title',{'lot':d['lot_key'],'value':d.get('title')}))
    if d.get('value'): rows.append(('lot_details.value',{'lot':d['lot_key'],'value':d['value']}))
for k,x in rows:
    tot+=1
    kind='text'
    if k=='texts' or k=='lot_details.title': val=x.get('value')
    elif k=='classifications': val=x.get('code')
    elif k=='parties': val=x.get('mention_name') or x.get('organization_name')
    elif k in ('amounts','lot_details.value'): val=(x.get('value') or {}).get('cents'); kind='amount'
    else: val=json.dumps(x)[:80]
    same=[f'{n}:{kd}:{sid}' for (n,kd,sid),s in secs.items() if sid==x['lot'] and kd=='Lot' and has(s,kind,val)]
    anyk=[f'{n}:{kd}:{sid}(NO={no(s)})' for (n,kd,sid),s in secs.items() if has(s,kind,val)]
    flag='' if same else '  <-- NOT AT SAME KEY'
    if not same: bad+=1
    print(k, x.get('field',''), x['lot'], str(val)[:45], '| same-key:', same, '| any:', anyk[:5], flag)
print('total',tot,'not-same-key',bad)
