# dump a notice content: each section with compact values
import json, sys
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k7'
full = '-f' in sys.argv
for nid in [a for a in sys.argv[1:] if a!='-f']:
    d=json.load(open(f'{C}/notice_{nid}.json'))
    print('=== NOTICE', nid)
    for s in d['sections']:
        vals=[]
        for v in s['values']:
            f=v['field_id']
            if v['type']=='text': x=v.get('value','')[:(400 if full else 90)]
            elif v['type']=='amount': x=f"{v.get('cents',0)/100:.0f} {v.get('currency')}"
            elif v['type']=='classification': x=v.get('code')
            else: x=v.get('value', v.get('code', {k:vv for k,vv in v.items() if k not in ('field_id','ordinal','type')}))
            vals.append(f"{f}={x}")
        if not full and s['kind'] not in ('Lot','LotResult'):
            vals=[x for x in vals if any(k in x for k in ('REFERENCE','NOTICE_NUMBER','PREVIOUS','TITLE','DATE','PUB'))]
        print(f"[{s['kind']}] {s['section_id']} (parent {s.get('parent_section_id')})")
        for x in vals: print('    ', x)
