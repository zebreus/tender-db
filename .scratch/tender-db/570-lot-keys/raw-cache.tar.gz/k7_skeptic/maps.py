# Per tender (live detail): each version notice's Lot map key -> printed number + title; each served lot_result's
# printed number (block) vs the printed number of the Tender lot it serves on (per every lot-publishing notice).
import json, sys, re, unicodedata
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k7'
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k7_skeptic/live'
NOF=('TED-LOT_NO','TED-LOT_NUMBER')
def nn(x):
    s=unicodedata.normalize('NFKD',str(x)).lower().strip()
    s=re.sub(r'^(lot[eo]?s?|perceel|czesc|część|zadanie)\s*','',s)
    s=re.sub(r'[^0-9a-z,]','',s)
    return str(int(s)) if s.isdigit() else s
def vals(s,f): return [v.get('value',v.get('code')) for v in s['values'] if v['field_id'] in f]
for tid in sys.argv[1:]:
    t=json.load(open(f'{L}/tender_{tid}.json'))
    print('##### TENDER',tid,t['title'][:80],'lots=',t['lots'])
    nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
    maps={}
    for n in nids:
        c=json.load(open(f'{C}/notice_{n}.json'))
        lots={s['section_id']:s for s in c['sections'] if s['kind']=='Lot'}
        res={s['section_id']:s for s in c['sections'] if s['kind']=='LotResult'}
        proc=[s for s in c['sections'] if s['kind']=='Notice']
        ref=[v.get('value') for s in proc for v in s['values'] if v['field_id'] in ('TED-REFERENCE_NUMBER','TED-FILE_REFERENCE_NUMBER','TED-NOTICE_NUMBER_OJ','TED-NOTICE_NUMBER_OJ.PREV_KIND')]
        print(f'  notice {n}: {len(lots)} lot sections, {len(res)} result blocks; ref={ref}')
        m={}
        for k,s in lots.items():
            no=vals(s,NOF); ti=(vals(s,('TED-TITLE','TED-LOT_TITLE')) or [''])[0]
            m[k]=([nn(x) for x in no], ti)
            print(f'     {k}: NO={no} ITEM={vals(s,("TED-ITEM",))} title={str(ti)[:70]!r}')
        if m: maps[n]=m
    # disagreement
    keys=sorted({k for m in maps.values() for k in m}, key=lambda k:int(re.sub(r"\D","",k) or 0))
    dis=[]
    for k in keys:
        nos={n:tuple(m[k][0]) for n,m in maps.items() if k in m}
        if len(set(nos.values()))>1: dis.append((k,nos))
    bynum={}
    for n,m in maps.items():
        for k,(no,ti) in m.items():
            for x in no: bynum.setdefault(x,set()).add(k)
    dup=[(x,ks) for x,ks in bynum.items() if len(ks)>1]
    print('  DISAGREE same-key:',dis,' same-number-diff-key:',dup)
    print('  served lots:', [(d['lot_key'], (d.get('title') or '')[:50]) for d in t['lot_details']])
    bad=0
    for r in t['lot_results']:
        c=json.load(open(f'{C}/notice_{r["notice_id"]}.json'))
        blk=[s for s in c['sections'] if s['kind']=='LotResult' and s['section_id']==r['key']]
        bno=vals(blk[0],NOF) if blk else None
        bti=(vals(blk[0],('TED-TITLE','TED-CONTRACT_TITLE')) or [''])[0] if blk else ''
        lot=r.get('lot')
        tnos={n:m[lot][0] for n,m in maps.items() if lot in m} if lot else {}
        ok = (lot is None) or all(set(nn(x) for x in (bno or []))<=set(v) or not bno for v in tnos.values())
        if not ok: bad+=1
        print(f'   result {r["notice_id"]}:{r["key"]} block NO={bno} title={str(bti)[:45]!r} -> lot {lot} (that key prints {tnos}) {"" if ok else "<-- MISMATCH"}')
    print('  results',len(t['lot_results']),'mismatch',bad)
