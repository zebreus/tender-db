# Per tender: each notice's Lot section key -> (printed number, title); disagreements across notices;
# each served result: block's printed number/title vs the served lot's number(s) across notices and the served lot title.
import json, sys, re
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k11'
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k11_skeptic/live'
NOF=('TED-LOT_NO','TED-LOT_NUMBER')
def vals(s,f): return [x.get('value',x.get('code')) for x in s['values'] if x['field_id'] in f]
def nn(x):
    x=str(x).strip().lower(); x=re.sub(r'^(lot|lote|los|lotto|part|część|pakiet|zadanie|nr\.?|no\.?)\s*','',x); x=x.lstrip('0') or '0'; return x
def nt(s): return re.sub(r'[\W_]+',' ',str(s or '')).strip().lower()
for tid in sys.argv[1:]:
    import os
    p=f'{L}/tender_{tid}.json'
    t=json.load(open(p if os.path.exists(p) else f'{C}/tender_{tid}.json'))
    nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
    maps={}; res={}
    for n in nids:
        try: c=json.load(open(f'{C}/notice_{n}.json'))
        except FileNotFoundError: print(' missing',n); continue
        m={}
        for s in c['sections']:
            if s['kind']=='Lot':
                m[s['section_id']]=(tuple(nn(x) for x in vals(s,NOF)), (vals(s,('TED-TITLE','TED-LOT_TITLE')) or [''])[0])
            if s['kind']=='LotResult':
                res[(n,s['section_id'])]=(tuple(nn(x) for x in vals(s,NOF)), (vals(s,('TED-TITLE','TED-CONTRACT_TITLE')) or [''])[0])
        if m: maps[n]=m
    print('='*90); print('TENDER',tid,'notices with lot sections:',len(maps),list(maps))
    keys=sorted({k for m in maps.values() for k in m}, key=lambda k:int(re.sub(r'\D','',k) or 0))
    dis=[]
    for k in keys:
        nums={n:m[k][0] for n,m in maps.items() if k in m}
        tits={n:nt(m[k][1])[:40] for n,m in maps.items() if k in m}
        if len(set(v for v in nums.values() if v))>1: dis.append((k,'num',nums))
        if len(set(v for v in tits.values() if v))>1: dis.append((k,'title',tits))
    # same number at different keys
    for n1,m1 in maps.items():
        for n2,m2 in maps.items():
            if n1>=n2: continue
            r1={v[0]:k for k,v in m1.items() if v[0]}; r2={v[0]:k for k,v in m2.items() if v[0]}
            for num in set(r1)&set(r2):
                if r1[num]!=r2[num]: dis.append((num,'numkey',(n1,r1[num],n2,r2[num])))
    print(' disagreements:',len(dis))
    for d in dis[:30]: print('   ',d)
    served={l['lot_key']:l['title'] for l in t['lot_details']}
    bad=0
    for r in t['lot_results']:
        b=res.get((r['notice_id'],r['key']),((),''))
        lot=r['lot']
        if lot is None: print('   result',r['notice_id'],r['key'],'prints',b[0],'-> None'); continue
        own=maps.get(r['notice_id'],{}).get(lot)
        latest=[(n,maps[n][lot][0]) for n in maps if lot in maps[n]]
        st=served.get(lot)
        ok_num = (not b[0]) or any(b[0]==x[1] for x in latest[-1:])
        flag='' if ok_num else '  <-- MISMATCH'
        if not ok_num: bad+=1
        print('   result',r['notice_id'],r['key'],'prints',b[0],repr(b[1][:40]),'-> served',lot,repr((st or '')[:40]),'own sec',own and own[0],'| key across notices',latest, flag)
    print(' results',len(t['lot_results']),'flagged',bad)
