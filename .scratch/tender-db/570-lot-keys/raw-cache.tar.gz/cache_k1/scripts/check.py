import json, os, sys, re, difflib
sys.path.insert(0,'/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad')
from analyze_lib import *
g=json.load(open(GROUPS))
items=[it for gg in g['groups'] if gg['key']=='k1' for it in gg['items']]
out=[]
for it in items:
    tid=it['tender_id']; t=json.load(open(f'{CACHE}/tender_{tid}.json'))
    vers=sorted(t['versions'],key=lambda v:v['seq'])
    maps={}
    for v in vers:
        n=notice(v['caused_by_notice_id'])
        if n['lots']: maps[v['caused_by_notice_id']]=n
    dis=[]; tdiff=[]
    keys=set(k for n in maps.values() for k in n['lots'])
    nids=list(maps)
    for k in sorted(keys):
        pubs=[(nid,maps[nid]['lots'][k]) for nid in nids if k in maps[nid]['lots']]
        nums=set(norm(l['printed']) for _,l in pubs)
        if len(nums)>1: dis.append((k,[(nid,l['printed']) for nid,l in pubs]))
        for i in range(len(pubs)):
            for j in range(i+1,len(pubs)):
                a=(pubs[i][1]['title'] or '').lower(); b=(pubs[j][1]['title'] or '').lower()
                r=difflib.SequenceMatcher(None,a,b).ratio()
                if r<0.8: tdiff.append((k,pubs[i][0],a[:60],pubs[j][0],b[:60],round(r,2)))
    # same printed number at different keys
    bynum={}
    for nid in nids:
        for k,l in maps[nid]['lots'].items():
            bynum.setdefault(norm(l['printed']),set()).add(k)
    multi={n:ks for n,ks in bynum.items() if len(ks)>1}
    # results check: block printed number vs the served lot's number in the latest publishing notice
    latest={}
    for nid in nids:
        for k,l in maps[nid]['lots'].items(): latest[k]=(nid,l['printed'],l['title'])
    mis=[]
    for r in t['lot_results']:
        n=notice(r['notice_id']); blk=n['res'].get(r['key'])
        p=blk['printed'] if blk else None
        if r['lot'] is None: continue
        ident=latest.get(r['lot'])
        # every notice's number at that key
        allnums=set(norm(maps[nid]['lots'][r['lot']]['printed']) for nid in nids if r['lot'] in maps[nid]['lots'])
        if norm(p) not in allnums or len(allnums)>1:
            mis.append((r['notice_id'],r['key'],p,r['lot'],sorted(x for x in allnums if x)))
    print(tid, 'lot-notices', nids, 'disagree', dis, 'num@multikeys', multi, 'title<0.8', tdiff[:5], 'results_on_disputed_or_wrong', mis, 'n_results', len(t['lot_results']), 'null', sum(1 for r in t['lot_results'] if r['lot'] is None))
