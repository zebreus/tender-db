import json,sys
sys.path.insert(0,'/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad')
from analyze_lib import *
g=json.load(open(GROUPS))
items=[it for gg in g['groups'] if gg['key']=='k1' for it in gg['items']]
for it in items:
    tid=it['tender_id']; t=json.load(open(f'{CACHE}/tender_{tid}.json'))
    vers=sorted(t['versions'],key=lambda v:v['seq'])
    ns={v['caused_by_notice_id']:notice(v['caused_by_notice_id']) for v in vers}
    prov={}
    for l in t['lot_details']:
        src=[nid for nid,n in ns.items() if l['lot_key'] in n['lots'] and n['lots'][l['lot_key']]['title']==l.get('title')]
        prov.setdefault(tuple(src),[]).append(l['lot_key'])
    res=[(r['notice_id'],r['key'],(ns.get(r['notice_id']) or notice(r['notice_id']))['res'][r['key']]['printed'],r['lot']) for r in t['lot_results']]
    print(tid, {k:len(v) for k,v in prov.items()}, 'results', len(res), 'placed', sum(1 for x in res if x[3]))
