import json, os, sys, re
CACHE='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k1'
GROUPS='/home/user/tender-db/.scratch/tender-db/570-lot-keys/groups.json'
LOT_KINDS=('Lot','LotsGroup','Part')
RESULT_KINDS=('LotResult','LotTender','TenderingParty','SettledContract')
def norm(p):
    if p is None: return None
    s=p.strip().lower()
    rest=s
    for w in ['lotto','lote','lot','los']:
        if rest.startswith(w) and not (len(rest)>len(w) and rest[len(w)].isalpha()):
            rest=rest[len(w):].lstrip(' .:-#°º')
            for m in ['nr','no','n']:
                if rest.startswith(m) and not (len(rest)>len(m) and rest[len(m)].isalpha()):
                    rest=rest[len(m):].lstrip(' .:-#°º'); break
            break
    rest=rest.strip()
    while len(rest)>1 and rest[0]=='0' and rest[1].isdigit(): rest=rest[1:]
    return rest or None
def val(v):
    return v.get('value', v.get('code'))
def sect_info(s):
    d={'kind':s['kind'],'id':s['section_id'],'lot_no':None,'lot_number':None,'item':None,'title':None,'fields':{}}
    for v in s['values']:
        f=v['field_id']; x=val(v)
        d['fields'].setdefault(f,[]).append(x if not isinstance(x,dict) else x)
        if f=='TED-LOT_NO' and d['lot_no'] is None: d['lot_no']=x
        if f=='TED-LOT_NUMBER' and d['lot_number'] is None: d['lot_number']=x
        if f=='TED-ITEM' and d['item'] is None: d['item']=x
        if f in ('TED-TITLE','TED-LOT_TITLE','TED-CONTRACT_TITLE') and d['title'] is None: d['title']=x
    d['printed']=d['lot_no'] if d['lot_no'] is not None else d['lot_number']
    return d
def notice(nid):
    p=f'{CACHE}/notice_{nid}.json'
    if not os.path.exists(p): return None
    c=json.load(open(p))
    lots={};res={}
    for s in c['sections']:
        if s['kind'] in LOT_KINDS: lots[s['section_id']]=sect_info(s)
        if s['kind'] in RESULT_KINDS and s['kind']=='LotResult': res[s['section_id']]=sect_info(s)
    form=None
    for s in c['sections']:
        if s['kind']=='Notice':
            for v in s['values']:
                if v['field_id'] in ('TED-FORM','TED-CNT_NOTICE_INFORMATION_S','TED-NOTICE_TYPE','TED-DOCUMENT_TYPE'):
                    form=(form or '')+f"{v['field_id']}={val(v)};"
    return {'lots':lots,'res':res,'form':form}
def short(t,n=50):
    if t is None: return None
    return t if len(t)<=n else t[:n]+'…'
g=json.load(open(GROUPS))
grp=sys.argv[1] if len(sys.argv)>1 else 'k1'
items=[it for gg in g['groups'] if gg['key']==grp for it in gg['items']]
only=set(int(a) for a in sys.argv[2:])
for it in items:
    tid=it['tender_id']
    if only and tid not in only: continue
    tp=f'{CACHE}/tender_{tid}.json'
    if not os.path.exists(tp): print(tid,'MISSING'); continue
    t=json.load(open(tp))
    print('='*100); print('TENDER',tid,it['profile'],it['year'],'can',it['can_notice_id'],'version',t.get('version'))
    vers=sorted(t['versions'],key=lambda v:v['seq'])
    for v in vers:
        n=notice(v['caused_by_notice_id'])
        if n is None: print('  v',v['seq'],v['caused_by_notice_id'],'NO CONTENT'); continue
        print(f"  v{v['seq']} notice {v['caused_by_notice_id']} pub {v['publication_id']} {v['published_at']} form={n['form']} lots={len(n['lots'])} res={len(n['res'])}")
        for k,l in sorted(n['lots'].items(),key=lambda kv:int(re.sub(r'\D','',kv[0]) or 0)):
            print(f"     {l['kind']} {k}: LOT_NO={l['lot_no']!r} LOT_NUMBER={l['lot_number']!r} ITEM={l['item']!r} title={short(l['title'])!r}")
        for k,r in sorted(n['res'].items(),key=lambda kv:int(re.sub(r'\D','',kv[0]) or 0)):
            print(f"     {k}: LOT_NO={r['lot_no']!r} LOT_NUMBER={r['lot_number']!r} ITEM={r['item']!r} title={short(r['title'])!r}")
    print('  served lot_details:')
    for l in t.get('lot_details',[]):
        print(f"     {l['lot_key']} kind={l['kind']} title={short(l.get('title'),70)!r} value={l.get('value')}")
    print('  served lot_results:')
    for r in t.get('lot_results',[]):
        w=[x['organization_name'] for x in r.get('winners',[])]
        print(f"     {r['key']} notice={r.get('notice_id')} lot={r.get('lot')} decision={r.get('decision')} awarded={r.get('awarded')} winners={[short(x,25) for x in w]}")
