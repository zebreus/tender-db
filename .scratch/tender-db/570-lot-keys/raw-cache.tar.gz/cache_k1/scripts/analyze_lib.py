import json, os, sys, re
CACHE='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k1'
GROUPS='/home/user/tender-db/.scratch/tender-db/570-lot-keys/groups.json'
LOT_KINDS=('Lot','LotsGroup','Part')
RESULT_KINDS=('LotResult','LotTender','TenderingParty','SettledContract')
def norm(p):
    if p is None: return None
    s=p.strip().lower()
    rest=s
    for w in ['lotto','lote','lot','los']:
        if rest.startswith(w) and not (len(rest)>len(w) and rest[len(w)].isalpha()):
            rest=rest[len(w):].lstrip(' .:-#°º')
            for m in ['nr','no','n']:
                if rest.startswith(m) and not (len(rest)>len(m) and rest[len(m)].isalpha()):
                    rest=rest[len(m):].lstrip(' .:-#°º'); break
            break
    rest=rest.strip()
    while len(rest)>1 and rest[0]=='0' and rest[1].isdigit(): rest=rest[1:]
    return rest or None
def val(v):
    return v.get('value', v.get('code'))
def sect_info(s):
    d={'kind':s['kind'],'id':s['section_id'],'lot_no':None,'lot_number':None,'item':None,'title':None,'fields':{}}
    for v in s['values']:
        f=v['field_id']; x=val(v)
        d['fields'].setdefault(f,[]).append(x if not isinstance(x,dict) else x)
        if f=='TED-LOT_NO' and d['lot_no'] is None: d['lot_no']=x
        if f=='TED-LOT_NUMBER' and d['lot_number'] is None: d['lot_number']=x
        if f=='TED-ITEM' and d['item'] is None: d['item']=x
        if f in ('TED-TITLE','TED-LOT_TITLE','TED-CONTRACT_TITLE') and d['title'] is None: d['title']=x
    d['printed']=d['lot_no'] if d['lot_no'] is not None else d['lot_number']
    return d
def notice(nid):
    p=f'{CACHE}/notice_{nid}.json'
    if not os.path.exists(p): return None
    c=json.load(open(p))
    lots={};res={}
    for s in c['sections']:
        if s['kind'] in LOT_KINDS: lots[s['section_id']]=sect_info(s)
        if s['kind'] in RESULT_KINDS and s['kind']=='LotResult': res[s['section_id']]=sect_info(s)
    form=None
    for s in c['sections']:
        if s['kind']=='Notice':
            for v in s['values']:
                if v['field_id'] in ('TED-FORM','TED-CNT_NOTICE_INFORMATION_S','TED-NOTICE_TYPE','TED-DOCUMENT_TYPE'):
                    form=(form or '')+f"{v['field_id']}={val(v)};"
    return {'lots':lots,'res':res,'form':form}
def short(t,n=50):
    if t is None: return None
    return t if len(t)<=n else t[:n]+'…'
