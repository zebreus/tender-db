import json,sys,re
sys.path.insert(0,'/tmp/claude-0/-home-user-tender-db/3050fd14-5ca6-5dd7-8b63-f827e13fd8ce/scratchpad')
from analyze_lib import *
g=json.load(open(GROUPS))
items=[it for gg in g['groups'] if gg['key']=='k1' for it in gg['items']]
out=[]
for it in items:
    tid=it['tender_id']; t=json.load(open(f'{CACHE}/tender_{tid}.json'))
    vers=sorted(t['versions'],key=lambda v:v['seq'])
    rec={'tender_id':tid,'profile':it['profile'],'versions':[],'served_lots':[(l['lot_key'],l.get('title')) for l in t['lot_details']],
         'served_lot_results':[(r['notice_id'],r['key'],r['lot']) for r in t['lot_results']]}
    parts=[]
    for v in vers:
        n=notice(v['caused_by_notice_id'])
        ks=sorted(n['lots'],key=lambda k:int(re.sub(r'\D','',k) or 0))
        rec['versions'].append({'seq':v['seq'],'notice':v['caused_by_notice_id'],'form':n['form'],
            'lots':{k:{'printed':n['lots'][k]['printed'],'item':n['lots'][k]['item'],'title':n['lots'][k]['title']} for k in ks},
            'blocks':{k:{'printed':b['printed'],'item':b['item'],'title':b['title']} for k,b in n['res'].items()}})
        if ks: parts.append(f"{v['caused_by_notice_id']}: "+",".join(f"{k}={n['lots'][k]['printed']}" for k in ks))
    rec['maps']=" | ".join(parts)
    out.append(rec)
    print(tid, rec['maps'])
json.dump(out,open(f'{CACHE}/k1_maps.json','w'),ensure_ascii=False,indent=1)
