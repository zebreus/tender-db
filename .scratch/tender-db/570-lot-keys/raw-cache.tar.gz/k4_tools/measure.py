# k4 measurer for issue 570: per tender, each notice's lot-section key -> printed number map, cross-notice
# disagreement, Tender lot identity (which notice's titles lots[] carry), and served results / lot facts that
# sit on a Tender lot that is another lot. Reads only cache_k4 (raw API reads); writes measure_k4.json.
import json, re, unicodedata, sys
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
C = ROOT + "/cache_k4"
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-TITLE", "TED-LOT_TITLE")
RTITF = ("TED-TITLE", "TED-CONTRACT_TITLE")
LOTKINDS = ("Lot", "LotsGroup", "Part")

def norm_no(x):
    s = unicodedata.normalize("NFKD", str(x)).lower().strip()
    s = re.sub(r"^(lot|los|lote|lotto|lotu|loti|lots|part|partie|cast|část|zadanie|pakiet|delkontrakt)\b", "", s).strip()
    s = re.sub(r"^(n[o°º]|nr|no\.)\s*", "", s)
    s = re.sub(r"[^0-9a-z]", "", s)
    return str(int(s)) if s.isdigit() else s

def norm_txt(x):
    s = unicodedata.normalize("NFKD", str(x)).lower()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"[\W_]", "", s)

def vals(sec, fids):
    return [v.get("value", v.get("code")) for v in sec["values"] if v["field_id"] in fids]

def secinfo(sec, titf):
    nos = vals(sec, NOF)
    return {"no": nos, "nno": sorted(set(norm_no(n) for n in nos)), "item": vals(sec, ("TED-ITEM",)),
            "titles": vals(sec, titf), "values": sec["values"]}

def load_notice(n):
    c = json.load(open(f"{C}/notice_{n}.json"))
    lots = {s["section_id"]: secinfo(s, TITF) for s in c["sections"] if s["kind"] in LOTKINDS}
    res = {s["section_id"]: secinfo(s, RTITF) for s in c["sections"] if s["kind"] == "LotResult"}
    return lots, res

def kn(k):
    m = re.search(r"(\d+)$", k); return int(m.group(1)) if m else 0

def one(nno):
    return nno[0] if len(nno) == 1 else None

def fact_in_section(fact_kind, fact, sec):
    for v in sec["values"]:
        val = v.get("value", v.get("code"))
        if val is None: continue
        if fact_kind == "classification":
            if v["type"] == "classification" and str(val) == str(fact): return True
        elif fact_kind == "date":
            if str(val)[:10] == str(fact)[:10]: return True
        else:
            if isinstance(val, str) and norm_txt(val) and norm_txt(val) == norm_txt(fact): return True
    return False

def measure(tid, can):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    vnids = [v["caused_by_notice_id"] for v in t["versions"]]
    rnids = [r["notice_id"] for r in t["lot_results"] if r["notice_id"] not in vnids]
    notices = {n: load_notice(n) for n in dict.fromkeys(vnids + rnids)}
    lotpub = [n for n in notices if notices[n][0]]
    maps = {n: {k: notices[n][0][k]["no"] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    titles = {n: {k: (notices[n][0][k]["titles"] or [None])[0] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    unnumbered = [n for n in lotpub if any(not s["nno"] for s in notices[n][0].values())]
    # disagreement
    dis = []
    for i, a in enumerate(lotpub):
        for b in lotpub[i + 1:]:
            A, B = notices[a][0], notices[b][0]
            for k in sorted(set(A) & set(B), key=kn):
                if A[k]["nno"] and B[k]["nno"] and A[k]["nno"] != B[k]["nno"]:
                    dis.append({"type": "same-key-different-number", "key": k, a: A[k]["no"], b: B[k]["no"]})
                elif not (A[k]["nno"] and B[k]["nno"]):
                    ta = {norm_txt(x) for x in A[k]["titles"]}; tb = {norm_txt(x) for x in B[k]["titles"]}
                    if ta and tb and not (ta & tb):
                        dis.append({"type": "unnumbered-title-differs", "key": k, a: A[k]["titles"][:1], b: B[k]["titles"][:1]})
            na = {x: k for k, s in A.items() for x in s["nno"]}; nb = {x: k for k, s in B.items() for x in s["nno"]}
            for x in sorted(set(na) & set(nb)):
                if na[x] != nb[x]:
                    dis.append({"type": "same-number-different-key", "number": x, a: na[x], b: nb[x]})
    # Tender lot identity: which notice's section at the served key carries the served title
    served = {l["lot_key"]: l for l in t["lot_details"]}
    ident = {}
    for k, l in served.items():
        src = [n for n in lotpub if k in notices[n][0] and l["title"] and norm_txt(l["title"]) in {norm_txt(x) for x in notices[n][0][k]["titles"]}]
        nos = sorted({one(notices[n][0][k]["nno"]) for n in src} - {None})
        if not src:  # fall back to every notice that has the key
            nos = sorted({one(notices[n][0][k]["nno"]) for n in lotpub if k in notices[n][0]} - {None})
        ident[k] = {"title": l["title"], "title_from": src, "number": nos[0] if len(nos) == 1 else (nos or None)}
    # results
    rows, mis = [], []
    for r in t["lot_results"]:
        n = r["notice_id"]; lots, res = notices[n]
        blk = res.get(r["key"], {"no": [], "nno": [], "item": [], "titles": []})
        p = one(blk["nno"])
        own = [k for k, s in lots.items() if p is not None and p in s["nno"]]
        L = r["lot"]
        tl = ident.get(L, {}).get("number") if L else None
        row = {"notice": n, "key": r["key"], "printed": blk["no"], "item": blk["item"], "served_lot": L,
               "own_section": own, "tender_lot_number": tl, "tender_lot_title": (ident.get(L, {}).get("title") or "")[:60] if L else None,
               "block_title": (blk["titles"] or [None])[0][:60] if blk["titles"] else None}
        verdict = "null" if L is None else "ok"
        if L is not None:
            if p is not None and tl is not None and p != tl:
                verdict = "MISATTRIBUTED"
            elif p is None:
                # no printed number: what does the block's own notice say section L is?
                on = one(lots[L]["nno"]) if L in lots else None
                if on is not None and tl is not None and on != tl: verdict = "MISATTRIBUTED(no-number, own L=%s)" % on
                else: verdict = "ok(no-number; own L=%s)" % on
            if p is not None and own and L not in own: row["same_notice_mismatch"] = True
        row["verdict"] = verdict
        rows.append(row)
        if verdict.startswith("MIS"): mis.append(row)
    # lot facts
    facts = []
    for c in t["classifications"]:
        if c.get("lot"): facts.append(("classification", c["lot"], c["code"], f"{c['scheme']}:{c['field']}"))
    for x in t["texts"]:
        if x.get("lot"): facts.append(("text", x["lot"], x["value"], "text:" + x["field"]))
    for x in t["dates"]:
        if x.get("lot"): facts.append(("date", x["lot"], x["value"], "date:" + x["field"]))
    for k, l in served.items():
        if l.get("title"): facts.append(("text", k, l["title"], "lot_details:title"))
    fact_out = {"total": 0, "ok": 0, "misattributed": 0, "unsourced": 0, "examples": []}
    for kind, K, val, label in facts:
        fact_out["total"] += 1
        tl = ident.get(K, {}).get("number")
        home = [n for n in lotpub if K in notices[n][0] and fact_in_section(kind, val, notices[n][0][K])]
        if not home:
            fact_out["unsourced"] += 1
            if len(fact_out["examples"]) < 5: fact_out["examples"].append({"unsourced": label, "lot": K, "value": str(val)[:60]})
            continue
        good = [n for n in home if one(notices[n][0][K]["nno"]) in (tl, None) or tl is None]
        if good: fact_out["ok"] += 1
        else:
            fact_out["misattributed"] += 1
            fact_out["examples"].append({"MIS": label, "lot": K, "value": str(val)[:60], "from": home})
    # winners follow results
    nwin_mis = sum(len([w for w in r.get("winners", [])]) for r in t["lot_results"] if any(m["notice"] == r["notice_id"] and m["key"] == r["key"] for m in mis))
    # class
    if len(lotpub) <= 1: cls = "single_lot_notice"
    elif unnumbered and not any(d["type"].startswith("same") for d in dis): cls = "unnumbered"
    elif not dis: cls = "consistent"
    elif mis or fact_out["misattributed"]: cls = "disagree_harmful"
    else: cls = "disagree_harmless"
    return {"tender_id": tid, "can_notice_id": can, "versions": vnids, "lot_publishing_notices": lotpub,
            "n_notices_with_lot_sections": len(lotpub), "maps": maps, "titles": titles, "unnumbered_notices": unnumbered,
            "disagreements": dis, "tender_lots": ident, "results": rows, "results_total": len(rows),
            "results_null": sum(1 for r in rows if r["served_lot"] is None), "results_misattributed": len(mis),
            "winner_mentions_on_misattributed_results": nwin_mis, "lot_facts": fact_out, "cls": cls}

g = json.load(open(ROOT + "/groups.json"))
items = [it for grp in g["groups"] if grp["key"] == "k4" for it in grp["items"]]
out = [measure(it["tender_id"], it["can_notice_id"]) for it in items]
json.dump(out, open(ROOT + "/measure_k4.json", "w"), indent=1, ensure_ascii=False)
for o in out:
    print(o["tender_id"], o["cls"], "lotpub", o["lot_publishing_notices"], "dis", len(o["disagreements"]), "res", o["results_total"],
          "null", o["results_null"], "mis", o["results_misattributed"], "facts", {k: v for k, v in o["lot_facts"].items() if k != "examples"})
    for d in o["disagreements"]: print("    DIS", d)
    for r in o["results"]:
        if r["verdict"] != "ok" or r.get("same_notice_mismatch"): print("    RES", r)
    for e in o["lot_facts"]["examples"]: print("    FACT", e)
