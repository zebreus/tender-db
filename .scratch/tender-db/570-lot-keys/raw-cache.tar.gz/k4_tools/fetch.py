import json, os, sys, time, subprocess
BASE='https://tenders.zebreus.click'
CACHE='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k4'
GROUPS='/home/user/tender-db/.scratch/tender-db/570-lot-keys/groups.json'
last=[0.0]
def get(path, out):
    if os.path.exists(out):
        return json.load(open(out))
    for attempt in range(2):
        wait = 1.6 - (time.time()-last[0])
        if wait>0: time.sleep(wait)
        last[0]=time.time()
        tmp=out+'.tmp'
        r=subprocess.run(['curl','-sS','-o',tmp,'-w','%{http_code}','--max-time','120',BASE+path],capture_output=True,text=True)
        code=r.stdout.strip()
        print(path, code, flush=True)
        if code=='200':
            os.rename(tmp,out); return json.load(open(out))
        if code=='408' and attempt==0:
            continue
        with open(out+'.err','w') as f: f.write(code+'\n'+r.stderr)
        return None
g=json.load(open(GROUPS))
items=[it for grp in g['groups'] if grp['key']=='k4' for it in grp['items']]
only = sys.argv[1:] 
for it in items:
    tid=it['tender_id']
    if only and str(tid) not in only: continue
    t=get(f'/v1/tenders/{tid}', f'{CACHE}/tender_{tid}.json')
    if not t: continue
    nids=[v.get('caused_by_notice_id') for v in t.get('versions',[])]
    for r in t.get('lot_results',[]):
        n=r.get('notice') or r.get('notice_id')
        if isinstance(n,dict): n=n.get('id')
        nids.append(n)
    nids.append(it['can_notice_id'])
    for nid in dict.fromkeys(nids):
        if nid is None: continue
        get(f'/v1/notices/{nid}/content', f'{CACHE}/notice_{nid}.json')
print('DONE')
