# Dump per-tender: notices, their lot sections (key, ITEM, printed no, title), result sections, served lots/results
import json, sys, re
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k4'
NOF=('TED-LOT_NO','TED-LOT_NUMBER')
def vals(s, fids):
    out=[]
    for v in s['values']:
        if v['field_id'] in fids:
            out.append(v.get('value', v.get('code')))
    return out
def load(n):
    try: return json.load(open(f'{C}/notice_{n}.json'))
    except FileNotFoundError: return None
for tid in sys.argv[1:]:
    t=json.load(open(f'{C}/tender_{tid}.json'))
    print('='*100); print('TENDER', tid, t.get('title','')[:100])
    nids=[v['caused_by_notice_id'] for v in t['versions']]
    rn=[r['notice_id'] for r in t['lot_results'] if r.get('notice_id') not in nids]
    for n in list(dict.fromkeys(nids+rn)):
        c=load(n)
        if c is None: print(' notice', n, 'NOT CACHED'); continue
        nt=[s for s in c['sections'] if s['kind']=='Notice']
        form = vals(nt[0], ('TED-FORM','TED-TD_DOCUMENT_TYPE','TED-CNT_NOTICE_INFORMATION_S')) if nt else []
        dp = vals(nt[0], ('TED-DATE_PUB',)) if nt else []
        print(f' NOTICE {n} {"(in versions)" if n in nids else "(result only)"} form={form} pub={dp}')
        for s in c['sections']:
            if s['kind'] in ('Organization','Notice'): continue
            if s['kind']=='Lot' or s['kind'] not in ('LotResult',):
                print(f"   {s['kind']:9} {s['section_id']:7} ITEM={vals(s,('TED-ITEM',))} NO={vals(s,NOF)} title={[x[:70] for x in vals(s,('TED-TITLE','TED-LOT_TITLE'))]} cpv={vals(s,('TED-CPV_CODE',))}")
            else:
                print(f"   {s['kind']:9} {s['section_id']:7} ITEM={vals(s,('TED-ITEM',))} NO={vals(s,NOF)} title={[x[:70] for x in vals(s,('TED-TITLE','TED-CONTRACT_TITLE'))]}")
    print(' SERVED lots:', [(l['lot_key'], (l['title'] or '')[:60]) for l in sorted(t['lot_details'], key=lambda l:int(re.sub(r'\D','',l['lot_key']) or 0))])
    for r in t['lot_results']:
        print('   result', r['notice_id'], r['key'], '->', r['lot'], r.get('decision'), [w['organization_name'][:40] for w in r.get('winners',[])])
