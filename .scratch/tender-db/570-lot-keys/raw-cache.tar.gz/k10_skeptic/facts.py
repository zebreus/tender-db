# For each served lot fact: which notices' Lot/LotResult sections at the SAME key carry the value, and which (notice,section,printed no) anywhere carry it.
import json, sys, re
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k10'
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k10_skeptic/live'
def norm(s): return re.sub(r'[\s\W_]+',' ',str(s or '')).strip().lower()
tid=sys.argv[1]; verbose=len(sys.argv)>2
t=json.load(open(f'{L}/tender_{tid}.json'))
nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
secs={}
orgs={}
for n in nids:
    c=json.load(open(f'{C}/notice_{n}.json'))
    for s in c['sections']:
        if s['kind'] in ('Lot','LotResult'): secs[(n,s['kind'],s['section_id'])]=s
        if s['kind']=='Organization': orgs[(n,s['section_id'])]=s
def no(s): return [x.get('value') for x in s['values'] if x['field_id'] in ('TED-LOT_NO','TED-LOT_NUMBER')]
def svals(s):
    out=[]
    for x in s['values']:
        for f in ('value','code'):
            if x.get(f) is not None: out.append(norm(x[f]))
    return out
def has(s,val):
    v=norm(val)
    if not v: return False
    for sv in svals(s):
        if sv==v or (len(v)>25 and (v in sv or sv in v) and min(len(sv),len(v))>25): return True
    return False
def has_winner(n,s,name):
    v=norm(name)
    for x in s['values']:
        if x['field_id']=='TED-ADDRESS_CONTRACTOR':
            o=orgs.get((n,x['value']))
            if o and any(norm(y.get('value'))==v for y in o['values']): return True
    return False
tot=0; bad=[]
for k in ('amounts','bids','contracts','dates','parties','classifications','texts'):
    for x in t[k]:
        if not isinstance(x,dict) or not x.get('lot'): continue
        tot+=1
        if k=='texts': val=x['value']
        elif k=='classifications': val=x['code']
        elif k=='parties': val=x.get('mention_name')
        elif k=='dates': val=str(x['value'])[:10]
        elif k=='amounts': val=x['value']['cents']/100
        else: val=json.dumps(x)
        if k=='parties':
            same=[f'{n}:{kd}:{sid}' for (n,kd,sid),s in secs.items() if kd=='LotResult' and has_winner(n,s,val)]
            print(k,x['lot'],val,'| winner in',same,[no(secs[tuple([int(a.split(':')[0])]+a.split(':')[1:])]) for a in same])
            continue
        if k=='amounts':
            cands=[str(val), str(int(val)) if val==int(val) else str(val)]
            same=[f'{n}:{sid}' for (n,kd,sid),s in secs.items() if sid==x['lot'] and kd=='Lot' and any(has(s,c) for c in cands)]
            anyk=[f'{n}:{kd}:{sid}{no(s)}' for (n,kd,sid),s in secs.items() if any(has(s,c) for c in cands)]
        else:
            same=[f'{n}:{sid}' for (n,kd,sid),s in secs.items() if sid==x['lot'] and kd=='Lot' and has(s,val)]
            anyk=[f'{n}:{kd}:{sid}{no(s)}' for (n,kd,sid),s in secs.items() if has(s,val)]
        line=(k,x.get('field'),x['lot'],str(val)[:60],'same-key:',same,'any:',anyk[:8])
        if verbose or not same or len(same)<len([1 for (n,kd,sid) in secs if kd=='Lot' and sid==x['lot']]): print(*line)
        if not same: bad.append(line)
print('TOTAL lot facts',tot,'not found at same key',len(bad))
