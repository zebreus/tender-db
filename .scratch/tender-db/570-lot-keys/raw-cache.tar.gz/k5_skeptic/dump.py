# k5 dump: human-readable per-tender view of cache_k5 (lots[], lot_results, each notice's lot sections and award blocks)
import json, sys, os
C = '/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k5'
L = '/home/user/tender-db/.scratch/tender-db/570-lot-keys/k5_skeptic/live'
NOF = ('TED-LOT_NO', 'TED-LOT_NUMBER')
def v(sec, fids):
    return [x.get('value', x.get('code')) for x in sec['values'] if x['field_id'] in fids]
def dump(tid):
    t = json.load(open(f'{L}/tender_{tid}.json'))
    vn = [x['caused_by_notice_id'] for x in t['versions']]
    print(f'=== tender {tid} versions {vn} title {t["title"][:80]!r}')
    for l in t['lot_details']:
        print(f'  LOT {l["lot_key"]} v{l["version"]} {str(l["title"])[:90]!r}')
    for r in t['lot_results']:
        w = ','.join((x.get('organization_name') or '')[:25] for x in r.get('winners', []))
        print(f'  RES {r["key"]} lot={r["lot"]} notice={r["notice_id"]} dec={r["decision"]} {w[:50]!r}')
    from collections import Counter
    lf = Counter()
    for k in ('classifications', 'texts', 'dates', 'parties', 'amounts', 'bids', 'contracts'):
        for x in t.get(k, []):
            if isinstance(x, dict) and x.get('lot'): lf[(k, x['lot'])] += 1
    print('  lot facts:', dict(lf))
    nids = list(dict.fromkeys(vn + [r['notice_id'] for r in t['lot_results']]))
    for n in nids:
        p = f'{L}/notice_{n}.json' if os.path.exists(f'{L}/notice_{n}.json') else f'{C}/notice_{n}.json'
        if not os.path.exists(p): print('  notice', n, 'MISSING'); continue
        c = json.load(open(p))
        secs = [s for s in c['sections'] if s['kind'] in ('Lot', 'LotResult', 'Notice', 'Change')]
        print(f'  -- notice {n}')
        for s in secs:
            if s['kind'] == 'Notice':
                print(f'     Notice title={(v(s, ("TED-TITLE",)) or [""])[0][:70]!r}'); continue
            if s['kind'] == 'Change':
                print(f'     Change {s["section_id"]} {[ (x["field_id"], str(x.get("value", x.get("code")))[:40]) for x in s["values"]][:6]}'); continue
            print(f'     {s["kind"]} {s["section_id"]} no={v(s, NOF)} item={v(s, ("TED-ITEM",))} cno={v(s, ("TED-CONTRACT_NO",))} '
                  f'title={[str(x)[:70] for x in v(s, ("TED-TITLE", "TED-LOT_TITLE", "TED-CONTRACT_TITLE"))][:2]}')
for a in sys.argv[1:]:
    dump(int(a))
