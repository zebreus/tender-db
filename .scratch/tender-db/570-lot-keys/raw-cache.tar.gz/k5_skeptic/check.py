# k5 skeptic: independent re-check. Fresh tender detail (k5_skeptic/live), notices from live if present else cache_k5.
import json, os, re, sys, unicodedata, difflib
R = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
L = R + '/k5_skeptic/live'; C = R + '/cache_k5'
def sa(s): return ''.join(ch for ch in unicodedata.normalize('NFKD', str(s)) if not unicodedata.combining(ch))
def nno(x):
    s = sa(x).lower().strip()
    s = re.sub(r'^(lot|lots|los|lote|lotto|part|partie|zadanie|pakiet|cast|tranche)\b\.?\s*', '', s)
    s = re.sub(r'^(n[o°º]\.?|nr\.?)\s*', '', s)
    toks = [str(int(t)) if t.isdigit() else t for t in re.findall(r'[0-9]+|[a-z]+', s)]
    return '.'.join(toks)
def nt(x): return re.sub(r'[\W_]', '', sa(x).lower())
def sim(a, b):
    a, b = nt(a), nt(b)
    if not a or not b: return 0.0
    if a == b: return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()
def val(sec, f): return [str(x.get('value', x.get('code'))) for x in sec['values'] if x['field_id'] in f]
def notice(n):
    p = f'{L}/notice_{n}.json'
    if not os.path.exists(p): p = f'{C}/notice_{n}.json'
    c = json.load(open(p))
    orgs = {x['section_id']: [str(y.get('value')) for y in x['values'] if y['field_id'] in ('TED-OFFICIALNAME','TED-NAME','TED-ORGANISATION')] for x in c['sections'] if x['kind'] == 'Organization'}
    lots, res = {}, {}
    for s in c['sections']:
        if s['kind'] not in ('Lot', 'LotResult'): continue
        no = val(s, ('TED-LOT_NO', 'TED-LOT_NUMBER'))
        ti = val(s, ('TED-TITLE', 'TED-LOT_TITLE', 'TED-CONTRACT_TITLE'))
        d = {'no': no, 'n': '|'.join(sorted({nno(x) for x in no})) or None, 'title': ti[0] if ti else '', 'sec': s,
             'orgs': [nm for y in s['values'] if y['field_id'] == 'TED-ADDRESS_CONTRACTOR' for nm in orgs.get(y.get('value'), [])]}
        (lots if s['kind'] == 'Lot' else res)[s['section_id']] = d
    return lots, res
def kn(k): return int(re.search(r'(\d+)$', k).group(1))
def run(tid):
    t = json.load(open(f'{L}/tender_{tid}.json'))
    vn = [v['caused_by_notice_id'] for v in t['versions']]
    nids = list(dict.fromkeys(vn + [r['notice_id'] for r in t['lot_results']]))
    N = {n: notice(n) for n in nids}
    pub = [n for n in nids if N[n][0]]
    print(f'== {tid} versions={vn} lotpub={pub}')
    for n in pub:
        print(f'   map {n}: ' + ', '.join(f"{k}->{N[n][0][k]['n']}" for k in sorted(N[n][0], key=kn)))
    dis = []
    for i, a in enumerate(pub):
        for b in pub[i+1:]:
            A, B = N[a][0], N[b][0]
            for k in sorted(set(A) & set(B), key=kn):
                if A[k]['n'] and B[k]['n'] and A[k]['n'] != B[k]['n']:
                    dis.append(('key', k, a, A[k]['n'], A[k]['title'][:30], b, B[k]['n'], B[k]['title'][:30]))
                if not (A[k]['n'] and B[k]['n']) and sim(A[k]['title'], B[k]['title']) < 0.6:
                    dis.append(('untitled', k, a, A[k]['title'][:40], b, B[k]['title'][:40]))
            na = {d['n']: k for k, d in A.items() if d['n']}; nb = {d['n']: k for k, d in B.items() if d['n']}
            for x in set(na) & set(nb):
                if na[x] != nb[x]: dis.append(('num', x, a, na[x], b, nb[x]))
    print(f'   disagreements: {len(dis)}', dis[:6])
    # served lot identity
    ident = {}
    for l in t['lot_details']:
        k = l['lot_key']; T = l['title'] or ''
        c = [(sim(T, N[n][0][k]['title']), n, N[n][0][k]['n']) for n in pub if k in N[n][0]]
        good = [x for x in c if x[0] >= 0.9]
        nums = sorted({x[2] for x in good if x[2]})
        ident[k] = (T, nums, [x[1] for x in good])
    nores = 0; mis = []
    for r in t['lot_results']:
        n = r['notice_id']; lots, res = N[n]
        b = res.get(r['key'])
        bn = b['n'] if b else None; bt = b['title'] if b else ''
        Lk = r['lot']
        if Lk is None: nores += 1; print(f'   RES {n} {r["key"]} printed={bn} lot=None title={bt[:40]!r}'); continue
        T, nums, src = ident.get(Lk, ('', [], []))
        ok = (bn in nums) if (bn and len(nums) == 1) else None
        ts = sim(bt, T)
        flag = 'OK' if ok else ('MIS' if ok is False else 'AMB')
        if flag != 'OK' or ts < 0.6:
            mis.append((n, r['key'], bn, Lk, nums, T[:40], bt[:40], round(ts, 2)))
        print(f'   RES {n} {r["key"]} printed={bn} -> {Lk} (tender lot no={nums} title={T[:35]!r}) block title={bt[:35]!r} sim={ts:.2f} {flag}')
    # lot facts
    facts = []
    for k in ('classifications', 'texts', 'dates', 'amounts', 'parties', 'bids', 'contracts'):
        for x in t.get(k, []):
            if isinstance(x, dict) and x.get('lot'): facts.append((k, x))
    fm = 0; fu = 0
    for k, x in facts:
        K = x['lot']; T, nums, src = ident.get(K, ('', [], []))
        v = x.get('code') or x.get('value') or x.get('organization_name') or x.get('mention_name')
        home = []
        for n in pub:
            s = N[n][0].get(K)
            if not s: continue
            vs = [str(y.get('value', y.get('code'))) for y in s['sec']['values']]
            if any(str(v) == y or (isinstance(v, str) and len(v) > 3 and sim(v, y) > 0.9) for y in vs): home.append(n)
        if k == 'parties':
            # winner facts come from award blocks
            for n in nids:
                for rk, rb in N[n][1].items():
                    vs = rb['orgs']
                    if any(isinstance(v, str) and sim(v, y) > 0.85 for y in vs):
                        home.append((n, rk, rb['n']))
        if not home: fu += 1; print(f'   FACT-UNSOURCED {k} {K} {str(v)[:50]}'); continue
        nos = set()
        for h in home:
            if isinstance(h, tuple): nos.add(h[2])
            else: nos.add(N[h][0][K]['n'])
        if nums and not (nos & set(nums)):
            fm += 1; print(f'   FACT-MIS {k} {K} {str(v)[:40]} from {home} numbers {nos} tender lot {nums}')
    print(f'   results={len(t["lot_results"])} unplaced={nores} flagged={len(mis)} facts={len(facts)} facts_mis={fm} facts_unsourced={fu}')
    for m in mis: print('   FLAG', m)
for a in sys.argv[1:]: run(int(a))
