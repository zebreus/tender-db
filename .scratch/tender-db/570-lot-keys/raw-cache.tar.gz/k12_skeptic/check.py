# k12 skeptic (issue 570): independent re-read. Live tender detail (k12_skeptic/live) + notice content
# (live where re-fetched, else cache_k12). Per tender: per-notice Lot map (key -> printed no, ITEM, title),
# cross-notice disagreement, served lots, served lot_results vs the block's own section (by printed number),
# and per lot fact: which notice section(s) at that key / which placed block hold the value.
import json, os, re, sys, unicodedata

R = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
LIVE = R + '/k12_skeptic/live'
C = R + '/cache_k12'
NOF = ('TED-LOT_NO', 'TED-LOT_NUMBER')


def ld(name):
    p = f'{LIVE}/{name}'
    return json.load(open(p if os.path.exists(p) else f'{C}/{name}')), os.path.exists(p)


def sa(x):
    s = unicodedata.normalize('NFKD', str(x)).lower()
    return ''.join(ch for ch in s if not unicodedata.combining(ch))


def nno(x):
    s = sa(x).strip()
    s = re.sub(r'^(lot[eoa]?s?|los|lotto|czesc|zadanie|pakiet|part|nr)\b\.?\s*', '', s)
    s = re.sub(r'^(n[o°º]\.?|nr\.?)\s*', '', s)
    s = s.rstrip('. ')
    return str(int(s)) if s.isdigit() else s


def nt(x):
    return re.sub(r'[\W_]+', ' ', sa(x or '')).strip()


def vals(s, f):
    return [v.get('value', v.get('code')) for v in s['values'] if v['field_id'] in f]


def kn(k):
    m = re.search(r'(\d+)$', k or '')
    return int(m.group(1)) if m else 0


def notice(n):
    c, live = ld(f'notice_{n}.json')
    kinds = {}
    lots, res = {}, {}
    for s in c['sections']:
        kinds[s['kind']] = kinds.get(s['kind'], 0) + 1
        if s['kind'] in ('Lot', 'LotResult'):
            d = {'no': vals(s, NOF), 'item': vals(s, ('TED-ITEM',)),
                 'title': (vals(s, ('TED-TITLE', 'TED-LOT_TITLE', 'TED-CONTRACT_TITLE')) or [''])[0],
                 'values': s['values']}
            d['n'] = tuple(sorted(set(nno(x) for x in d['no'] if x is not None)))
            (lots if s['kind'] == 'Lot' else res)[s['section_id']] = d
    return {'kinds': kinds, 'lots': lots, 'res': res, 'live': live}


def holds(sec, val):
    for v in sec['values']:
        x = v.get('value', v.get('code'))
        if isinstance(val, dict) and 'cents' in val:
            c = v.get('cents')
            if c is None and isinstance(x, dict):
                c = x.get('cents')
            if c == val['cents']:
                return True
            continue
        if x is not None and nt(x) and nt(x) == nt(val):
            return True
    return False


for tid in sys.argv[1:]:
    t, tl = ld(f'tender_{tid}.json')
    vn = [v['caused_by_notice_id'] for v in t['versions']]
    rn = [r['notice_id'] for r in t['lot_results']]
    nids = list(dict.fromkeys(vn + rn))
    N = {n: notice(n) for n in nids}
    print('=' * 100)
    print('TENDER', tid, 'live detail' if tl else 'CACHED detail', 'versions', vn, 'result notices', sorted(set(rn)))
    for n in nids:
        x = N[n]
        print('  notice', n, 'live' if x['live'] else 'cache', x['kinds'])
        for k in sorted(x['lots'], key=kn):
            s = x['lots'][k]
            print('     ', k, 'NO', s['no'], 'ITEM', s['item'], repr(s['title'][:70]))
        for k in sorted(x['res'], key=kn):
            s = x['res'][k]
            print('      ', k, 'NO', s['no'], 'ITEM', s['item'], repr(s['title'][:60]))
    pub = [n for n in nids if N[n]['lots']]
    print('  lot-publishing notices:', len(pub), pub)
    dis = []
    keys = sorted({k for n in pub for k in N[n]['lots']}, key=kn)
    for k in keys:
        nums = {n: N[n]['lots'][k]['n'] for n in pub if k in N[n]['lots']}
        if len(set(v for v in nums.values() if v)) > 1:
            dis.append(('same key diff no', k, nums))
        tits = {n: nt(N[n]['lots'][k]['title'])[:50] for n in pub if k in N[n]['lots']}
        if len(set(v for v in tits.values() if v)) > 1:
            dis.append(('title differs', k, tits))
    for i, a in enumerate(pub):
        for b in pub[i + 1:]:
            ra = {v['n']: k for k, v in N[a]['lots'].items() if v['n']}
            rb = {v['n']: k for k, v in N[b]['lots'].items() if v['n']}
            for num in set(ra) & set(rb):
                if ra[num] != rb[num]:
                    dis.append(('same no diff key', num, (a, ra[num], b, rb[num])))
    print('  cross-notice findings:', len(dis))
    for d in dis:
        print('    ', d)
    served = {l['lot_key']: l.get('title') for l in t['lot_details']}
    print('  served lots:')
    for k in sorted(served, key=kn):
        src = [n for n in pub if k in N[n]['lots'] and nt(N[n]['lots'][k]['title']) == nt(served[k])]
        print('    ', k, repr((served[k] or '')[:60]), 'title from', src)
    # Tender-lot identity: printed numbers at that key across lot-publishing notices
    ident = {k: set(N[n]['lots'][k]['n'] for n in pub if k in N[n]['lots'] and N[n]['lots'][k]['n']) for k in served}
    bad = 0
    for r in t['lot_results']:
        b = N[r['notice_id']]['res'].get(r['key'])
        bn = b['n'] if b else ()
        lot = r['lot']
        own = N[r['notice_id']]['lots']
        ownk = [k for k, s in own.items() if bn and s['n'] == bn]
        idk = [k for k, v in ident.items() if bn and v == {bn}]
        flag = ''
        if lot is not None and bn and ident.get(lot) and ident[lot] != {bn}:
            flag = ' <-- served lot identity %s != block %s' % (ident[lot], bn)
            bad += 1
        print('    result', r['notice_id'], r['key'], 'block no', b and b['no'], 'item', b and b['item'], repr((b and b['title'] or '')[:40]),
              '-> lot', lot, repr((served.get(lot) or '')[:40]), '| own-notice sec by no', ownk, '| tender lot(s) with that no', idk, flag)
    print('  results', len(t['lot_results']), 'placed', sum(r['lot'] is not None for r in t['lot_results']), 'misattributed', bad)
    # lot facts
    nf = 0; badf = 0; unk = 0
    placed = {}
    for r in t['lot_results']:
        if r['lot']:
            placed.setdefault(r['lot'], []).append((r['notice_id'], r['key']))
    for lst in ('classifications', 'texts', 'dates', 'amounts', 'parties'):
        for x in t.get(lst, []):
            K = x.get('lot')
            if not K:
                continue
            nf += 1
            val = x.get('code') if lst == 'classifications' else x.get('mention_name') if lst == 'parties' else x.get('value')
            home = [(n, 'Lot', N[n]['lots'][K]['n']) for n in pub if K in N[n]['lots'] and holds(N[n]['lots'][K], val)]
            home += [(n, rk, N[n]['res'][rk]['n']) for (n, rk) in placed.get(K, []) if rk in N[n]['res'] and holds(N[n]['res'][rk], val)]
            idn = ident.get(K, set())
            wrong = [h for h in home if h[2] and idn and {h[2]} != idn]
            if not home:
                unk += 1
                print('    fact no-home', K, lst, x.get('field') or x.get('role'), str(val)[:60])
            if wrong:
                badf += 1
                print('    FACT WRONG', K, lst, x.get('field'), str(val)[:60], home)
    print('  lot facts', nf, 'wrong', badf, 'no-home', unk)
