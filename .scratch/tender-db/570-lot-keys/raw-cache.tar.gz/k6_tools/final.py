# k6 final: hand-checked classes over measure_k6.auto.json (auto run of measure.py); writes measure_k6.json
import json
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
auto = {o["tender_id"]: o for o in json.load(open(ROOT + "/measure_k6.auto.json"))}
hand = {
 5787834: {"cls": "disagree_harmful", "results_misattributed": 1, "lot_facts_misattributed": 2,
           "harm": ["result 19154619 RES-1 (LOT_NO 18, clos-nw) served on Tender LOT-1 = lot 1",
                    "texts[title,LOT-18] and lot_details[LOT-18].title = 19167246 LOT-18 (LOT_NO 19) title; CN 19020649 LOT-18 = lot 18"]},
}
out = []
for tid, o in auto.items():
    h = hand.get(tid, {})
    cls = h.get("cls", o["cls_auto"])
    out.append({"tender_id": tid, "cls": cls, "n_notices_with_lot_sections": o["n_notices_with_lot_sections"],
                "results_total": o["results_total"], "results_misattributed": h.get("results_misattributed", o["results_misattributed"]),
                "lot_facts_misattributed": h.get("lot_facts_misattributed", 0), "harm": h.get("harm", []),
                "maps": o["maps"], "titles": o["titles"], "disagreements": o["disagreements"],
                "title_differences_same_key": o["title_differences_same_key"], "tender_lots": o["tender_lots"], "results": o["results"]})
json.dump(out, open(ROOT + "/measure_k6.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(Counter(x["cls"] for x in out), sum(x["results_total"] for x in out), sum(x["results_misattributed"] for x in out))
