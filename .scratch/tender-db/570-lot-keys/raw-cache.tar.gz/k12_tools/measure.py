# k12 measurer (copied from k10_tools/measure.py) for issue 570. Reads only cache_k12; writes cache_k12/measure_k12.auto.json and prints a dump.
# Per tender: each lot-publishing notice's section key -> printed number (TED-LOT_NO / TED-LOT_NUMBER), ITEM, title;
# cross-notice disagreement (same key, different normalised number; same number at different keys; same key,
# clearly different title); the Tender's served lots (which notice(s) their titles come from, and the printed
# number of the section at that key in those notices = the Tender lot's identity); served lot_results whose
# Tender lot identity differs from the number the block's own notice prints; served lot facts whose source
# section(s) at that key print another lot's number than the Tender lot's identity.
import json, re, sys, unicodedata

ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
C = ROOT + "/cache_k12"
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-TITLE", "TED-LOT_TITLE")
RTITF = ("TED-TITLE", "TED-CONTRACT_TITLE", "TED-TITLE_CONTRACT", "TED-LOT_TITLE")


def strip_acc(x):
    s = unicodedata.normalize("NFKD", str(x)).lower()
    return "".join(ch for ch in s if not unicodedata.combining(ch))


def norm_no(x):
    s = strip_acc(x).strip()
    s = re.sub(r"^(lot[eoa]?s?|los|lotto|cast|czesc|zadanie|pakiet|partie|part|deel|perceel|loti|osa|del|delomrade|teil|tranche)\b\.?", "", s).strip()
    s = re.sub(r"^(n[o°º]\.?|nr\.?|n\.)\s*", "", s)
    s = re.sub(r"[^0-9a-z]", "", s)
    return str(int(s)) if s.isdigit() else s


def single(x):
    s = strip_acc(x)
    return bool(re.fullmatch(r"\s*(lot[eoa]?\s*|los\s*|lotto\s*|cast\s*|czesc\s*|zadanie\s*|pakiet\s*|partie\s*|teil\s*|n[o°º]\.?\s*|nr\.?\s*)*0*\d+[a-z]?\s*\.?\s*", s))


def norm_txt(x):
    return re.sub(r"[\W_]", "", strip_acc(x))


def vals(sec, fids):
    return [v.get("value", v.get("code")) for v in sec["values"] if v["field_id"] in fids]


def info(sec, titf):
    nos = vals(sec, NOF)
    nn = sorted(set(norm_no(n) for n in nos if n is not None and single(n)))
    return {"no": nos, "nno": nn, "multi": [n for n in nos if n is not None and not single(n)],
            "item": vals(sec, ("TED-ITEM",)), "titles": [t for t in vals(sec, titf) if t], "values": sec["values"]}


def kn(k):
    m = re.search(r"(\d+)$", k or "")
    return int(m.group(1)) if m else 0


def one(nn):
    return nn[0] if len(nn) == 1 else None


def load_notice(n):
    c = json.load(open(f"{C}/notice_{n}.json"))
    lots = {s["section_id"]: info(s, TITF) for s in c["sections"] if s["kind"] == "Lot"}
    res = {s["section_id"]: info(s, RTITF) for s in c["sections"] if s["kind"] == "LotResult"}
    kinds = {}
    for s in c["sections"]:
        kinds[s["kind"]] = kinds.get(s["kind"], 0) + 1
    return {"lots": lots, "res": res, "kinds": kinds}


def fact_in(kind, fact, sec):
    for v in sec["values"]:
        val = v.get("value", v.get("code"))
        if kind == "amount":
            c = v.get("cents")
            if c is None and isinstance(val, dict):
                c = val.get("cents")
            try:
                if c is not None and fact is not None and abs(c / 100 - float(fact)) < 0.01:
                    return True
            except Exception:
                pass
            continue
        if val is None:
            continue
        if kind == "classification":
            if str(val) == str(fact):
                return True
        elif kind == "date":
            if str(val)[:10] == str(fact)[:10]:
                return True
        else:
            if isinstance(val, str) and norm_txt(val) and norm_txt(val) == norm_txt(fact):
                return True
    return False


def measure(tid, can):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    vn = [v["caused_by_notice_id"] for v in t["versions"]]
    rn = [r["notice_id"] for r in t["lot_results"] if r["notice_id"] not in vn]
    N = {n: load_notice(n) for n in dict.fromkeys(vn + rn)}
    lotpub = [n for n in N if N[n]["lots"]]
    maps = {str(n): {k: {"no": N[n]["lots"][k]["no"], "item": N[n]["lots"][k]["item"],
                         "title": (N[n]["lots"][k]["titles"] or [None])[0]}
                     for k in sorted(N[n]["lots"], key=kn)} for n in lotpub}
    unnum = [n for n in lotpub if any(not s["nno"] for s in N[n]["lots"].values())]
    dis, tdiff = [], []
    for i, a in enumerate(lotpub):
        for b in lotpub[i + 1:]:
            A, B = N[a]["lots"], N[b]["lots"]
            for k in sorted(set(A) & set(B), key=kn):
                if A[k]["nno"] and B[k]["nno"] and A[k]["nno"] != B[k]["nno"]:
                    dis.append({"type": "same-key-different-number", "key": k, "a": a, "a_no": A[k]["no"],
                                "a_title": A[k]["titles"][:1], "b": b, "b_no": B[k]["no"], "b_title": B[k]["titles"][:1]})
                ta = {norm_txt(x) for x in A[k]["titles"]}
                tb = {norm_txt(x) for x in B[k]["titles"]}
                if ta and tb and not (ta & tb):
                    tdiff.append({"key": k, "a": a, "a_no": A[k]["no"], "a_title": A[k]["titles"][:1],
                                  "b": b, "b_no": B[k]["no"], "b_title": B[k]["titles"][:1]})
            na, nb = {}, {}
            for k, s in A.items():
                for x in s["nno"]:
                    na.setdefault(x, []).append(k)
            for k, s in B.items():
                for x in s["nno"]:
                    nb.setdefault(x, []).append(k)
            for x in sorted(set(na) & set(nb)):
                if sorted(na[x]) != sorted(nb[x]):
                    dis.append({"type": "same-number-different-key", "number": x, "a": a, "a_keys": na[x], "b": b, "b_keys": nb[x]})
    served = {l["lot_key"]: l for l in t["lot_details"]}
    ident = {}
    for k, l in served.items():
        st = norm_txt(l.get("title") or "")
        src = [n for n in lotpub if k in N[n]["lots"] and st and st in {norm_txt(x) for x in N[n]["lots"][k]["titles"]}]
        nos = sorted({one(N[n]["lots"][k]["nno"]) for n in src} - {None})
        basis = "title"
        if not src:
            basis = "key-only"
            nos = sorted({one(N[n]["lots"][k]["nno"]) for n in lotpub if k in N[n]["lots"]} - {None})
        allnos = sorted({one(N[n]["lots"][k]["nno"]) for n in lotpub if k in N[n]["lots"]} - {None})
        ident[k] = {"title": l.get("title"), "title_from": src, "basis": basis,
                    "number": nos[0] if len(nos) == 1 else (nos or None),
                    "merged_numbers": allnos if len(allnos) > 1 else None,
                    "key_numbers_by_notice": {str(n): N[n]["lots"][k]["no"] for n in lotpub if k in N[n]["lots"]}}
    num2lots = {}
    for k, d in ident.items():
        if isinstance(d["number"], str):
            num2lots.setdefault(d["number"], []).append(k)
    rows, mis = [], []
    for r in t["lot_results"]:
        n = r["notice_id"]
        lots, res = N[n]["lots"], N[n]["res"]
        blk = res.get(r["key"], {"no": [], "nno": [], "multi": [], "item": [], "titles": []})
        p = one(blk["nno"])
        own = [k for k, s in lots.items() if p is not None and p in s["nno"]]
        L = r["lot"]
        tl = ident.get(L, {}).get("number") if L else None
        verdict = "null" if L is None else "ok"
        if L is not None:
            if p is not None and isinstance(tl, str) and p != tl:
                verdict = "MISATTRIBUTED"
            elif p is not None and isinstance(tl, list):
                verdict = "AMBIGUOUS-tender-lot(%s)" % tl
            elif p is not None and tl is None:
                verdict = "ok?(tender lot unnumbered)"
            elif p is None:
                on = one(lots[L]["nno"]) if L in lots else None
                if on is not None and isinstance(tl, str) and on != tl:
                    verdict = "MISATTRIBUTED(no-number, own %s=%s)" % (L, on)
                else:
                    verdict = "ok(no-number; own %s=%s)" % (L, on)
        row = {"notice": n, "key": r["key"], "printed": blk["no"], "item": blk["item"], "served_lot": L,
               "decision": r.get("decision"), "own_section": own, "tender_lot_number": tl,
               "right_tender_lot": num2lots.get(p) if p is not None else None,
               "tender_lot_title": (ident.get(L, {}).get("title") or "")[:70] if L else None,
               "block_title": (blk["titles"][0] or "")[:70] if blk["titles"] else None,
               "winners": [w.get("organization_name") for w in r.get("winners", [])][:2], "verdict": verdict}
        rows.append(row)
        if verdict.startswith("MIS"):
            mis.append(row)
    facts = []
    for c in t.get("classifications", []):
        if c.get("lot"):
            facts.append(("classification", c["lot"], c["code"], f"cls:{c['scheme']}:{c['field']}"))
    for x in t.get("texts", []):
        if x.get("lot"):
            facts.append(("text", x["lot"], x["value"], "text:" + x["field"]))
    for x in t.get("dates", []):
        if x.get("lot"):
            facts.append(("date", x["lot"], x["value"], "date:" + x["field"]))
    for x in t.get("amounts", []):
        if x.get("lot"):
            v = x.get("value")
            facts.append(("amount", x["lot"], (v["cents"] / 100) if isinstance(v, dict) else v, "amount:" + str(x.get("field"))))
    for x in t.get("parties", []):
        if x.get("lot") and x.get("role") != "winner":
            facts.append(("text", x["lot"], x.get("mention_name"), "party:" + str(x.get("role"))))
    fo = {"total": len(facts), "ok": 0, "misattributed": 0, "unsourced": 0, "ambiguous": 0,
          "mis_list": [], "unsourced_list": [], "amb_list": [], "by_lot": {}}
    for kind, K, val, label in facts:
        home = [n for n in lotpub if K in N[n]["lots"] and fact_in(kind, val, N[n]["lots"][K])]
        idn = ident.get(K, {}).get("number")
        fo["by_lot"].setdefault(K, {"total": 0, "mis": 0})
        fo["by_lot"][K]["total"] += 1
        if not home:
            fo["unsourced"] += 1
            fo["unsourced_list"].append({"label": label, "lot": K, "value": str(val)[:60]})
            continue
        homenos = sorted({one(N[n]["lots"][K]["nno"]) for n in home} - {None})
        if isinstance(idn, str) and homenos and idn not in homenos:
            fo["misattributed"] += 1
            fo["by_lot"][K]["mis"] += 1
            fo["mis_list"].append({"label": label, "lot": K, "value": str(val)[:70], "from": home,
                                   "from_numbers": homenos, "tender_lot_number": idn})
        elif not isinstance(idn, str) and len({one(N[n]["lots"][K]["nno"]) for n in lotpub if K in N[n]["lots"]} - {None}) > 1:
            fo["ambiguous"] += 1
            fo["amb_list"].append({"label": label, "lot": K, "value": str(val)[:60], "from": home, "from_numbers": homenos})
        else:
            fo["ok"] += 1
    if len(lotpub) <= 1:
        cls = "single_lot_notice"
    elif dis and (mis or fo["misattributed"]):
        cls = "disagree_harmful"
    elif dis:
        cls = "disagree_harmless"
    elif unnum and len([n for n in lotpub if n not in unnum]) < 2:
        cls = "unnumbered"
    else:
        cls = "consistent"
    return {"tender_id": tid, "can_notice_id": can, "versions": vn, "extra_result_notices": rn,
            "notice_forms": {str(n): {"kinds": N[n]["kinds"], "n_lots": len(N[n]["lots"]), "n_res": len(N[n]["res"])} for n in N},
            "lot_publishing_notices": lotpub, "n_notices_with_lot_sections": len(lotpub), "maps": maps,
            "unnumbered_notices": unnum, "disagreements": dis, "title_differences_same_key": tdiff,
            "tender_lots": ident, "results": rows, "results_total": len(rows),
            "results_null": sum(1 for r in rows if r["served_lot"] is None),
            "results_misattributed": len(mis), "lot_facts": fo, "cls_auto": cls}


g = json.load(open(ROOT + "/groups.json"))
items = [it for grp in g["groups"] if grp["key"] == "k12" for it in grp["items"]]
only = sys.argv[1:]
out = []
for it in items:
    if only and str(it["tender_id"]) not in only:
        continue
    try:
        out.append(measure(it["tender_id"], it["can_notice_id"]))
    except FileNotFoundError as e:
        print("MISSING", it["tender_id"], e)
        continue
if not only:
    json.dump(out, open(C + "/measure_k12.auto.json", "w"), indent=1, ensure_ascii=False)
for o in out:
    print("=" * 100)
    print(o["tender_id"], o["cls_auto"], "lotpub", o["lot_publishing_notices"], "unnum", o["unnumbered_notices"],
          "dis", len(o["disagreements"]), "res", o["results_total"], "null", o["results_null"], "mis", o["results_misattributed"],
          "facts", {k: v for k, v in o["lot_facts"].items() if not k.endswith("_list") and k != "by_lot"})
    for n, f in o["notice_forms"].items():
        print("   NOTICE", n, f)
    for n, m in o["maps"].items():
        print("   MAP", n, "; ".join(f"{k}={v['no']}/i{v['item']}:{(v['title'] or '')[:35]}" for k, v in m.items())[:2500])
    for k, v in sorted(o["tender_lots"].items(), key=lambda kv: kn(kv[0])):
        print("   TLOT", k, json.dumps(v, ensure_ascii=False)[:350])
    for d in o["disagreements"]:
        print("   DIS", json.dumps(d, ensure_ascii=False)[:400])
    for d in o["title_differences_same_key"]:
        print("   TITLE", json.dumps(d, ensure_ascii=False)[:400])
    for r in o["results"]:
        print("   RES", json.dumps(r, ensure_ascii=False)[:450])
    for e in o["lot_facts"]["mis_list"]:
        print("   FACT-MIS", json.dumps(e, ensure_ascii=False)[:300])
    for e in o["lot_facts"]["amb_list"][:10]:
        print("   FACT-AMB", json.dumps(e, ensure_ascii=False)[:300])
    for e in o["lot_facts"]["unsourced_list"][:10]:
        print("   FACT-UNSRC", json.dumps(e, ensure_ascii=False)[:300])
