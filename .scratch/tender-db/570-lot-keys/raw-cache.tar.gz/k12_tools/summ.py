# condensed per-tender summary from cache_k12/measure_k12.auto.json
import json, sys
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k12"
A = json.load(open(C + "/measure_k12.auto.json"))
only = [int(x) for x in sys.argv[1:]]
for o in A:
    if only and o["tender_id"] not in only: continue
    print("=" * 30, o["tender_id"], o["cls_auto"], "lotpub", o["lot_publishing_notices"], "res", o["results_total"], "null", o["results_null"], "mis", o["results_misattributed"],
          "facts", {k: v for k, v in o["lot_facts"].items() if not k.endswith("_list") and k != "by_lot"})
    for n, f in o["notice_forms"].items(): print("  NOTICE", n, f["kinds"])
    for n, m in o["maps"].items():
        print("  MAP", n, "; ".join(f"{k}={v['no']}/i{v['item']}:{(v['title'] or '')[:30]}" for k, v in m.items())[:1500])
    for d in o["disagreements"]: print("  DIS", json.dumps(d, ensure_ascii=False)[:400])
    for d in o["title_differences_same_key"]: print("  TITLE", json.dumps(d, ensure_ascii=False)[:400])
    for k, d in o["tender_lots"].items():
        print("  TLOT", k, (d["title"] or "")[:50], d["title_from"], d["basis"], d["number"], d["key_numbers_by_notice"])
    for r in o["results"]:
        print("   RES", r["notice"], r["key"], "pr", r["printed"], "it", r["item"], "->", r["served_lot"], r["decision"], "own", r["own_section"],
              "tl#", r["tender_lot_number"], "right", r["right_tender_lot"], r["verdict"], "|", (r["block_title"] or "")[:40], "|", (r["tender_lot_title"] or "")[:40])
    for e in o["lot_facts"]["unsourced_list"][:5]: print("  UNSRC", e)
