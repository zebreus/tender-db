# k8 final: hand-checked classes over measure_k8.auto.json (auto run of measure8.py); writes measure_k8.json.
# Hand changes: 7465548 auto "unnumbered" -> disagree_harmful (title-shown: two served results on LOT-1 are other lots).
import json
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
auto = {o["tender_id"]: o for o in json.load(open(ROOT + "/measure_k8.auto.json"))}
hand = {
    6980424: {"cls": "disagree_harmless", "results_misattributed": 0, "lot_facts_misattributed": 0,
              "harm": ["none served: CN 21462872 and CAN 21769762 order lots differently (CN LOT-1..10 print 6,1,3,10,8,7,4,2,5,9; "
                       "CAN 6,1,3,8,7,4,10,5,9,2) so LOT-4..LOT-10 name different lots; served lots[], both results and all 50 "
                       "lot facts follow the CAN (latest version); the CN's meaning of LOT-4..10 survives only in version 1"]},
    7465548: {"cls": "disagree_harmful", "results_misattributed": 2, "lot_facts_misattributed": 0,
              "harm": ["result 22917962 RES-1 (no LOT_NO; the framework award 'Útfelújítási munkák - kivitelezések', 5 winners, "
                       "2,500,000,000 HUF) served on Tender LOT-1 = 23461598 lot 1 'Bazilika lépcső felújítása'",
                       "result 23122442 RES-1 (LOT_NO 1, 'Simor János utca felújítása', C-Sped 84, 30,499,542 HUF) served on "
                       "Tender LOT-1 = 23461598 lot 1 'Bazilika lépcső felújítása' (same printed number, different call-off)"],
              "note": "3 of 4 lot-publishing notices (22589691, 22917962, 23122442) print no LOT_NO and no lot title; the "
                      "disagreement is shown by the result-block titles. Keying by printed number would NOT separate it: "
                      "each call-off award notice restarts at lot 1."},
}
out = []
for tid, o in auto.items():
    h = hand.get(tid, {})
    out.append({"tender_id": tid, "cls": h.get("cls", o["cls_auto"]), "cls_auto": o["cls_auto"],
                "n_notices_with_lot_sections": o["n_notices_with_lot_sections"],
                "lot_publishing_notices": o["lot_publishing_notices"], "versions": o["versions"],
                "results_total": o["results_total"], "results_null": o["results_null"],
                "results_misattributed": h.get("results_misattributed", o["results_misattributed"]),
                "lot_facts_total": o["lot_facts"]["total"],
                "lot_facts_misattributed": h.get("lot_facts_misattributed", o["lot_facts"]["misattributed"]),
                "harm": h.get("harm", []), "note": h.get("note"),
                "maps": o["maps"], "titles": o["titles"], "disagreements": o["disagreements"],
                "title_differences_same_key": o["title_differences_same_key"], "tender_lots": o["tender_lots"],
                "results": o["results"], "lot_facts": o["lot_facts"]})
json.dump(out, open(ROOT + "/measure_k8.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(Counter(x["cls"] for x in out), "results", sum(x["results_total"] for x in out),
      "mis", sum(x["results_misattributed"] for x in out), "facts", sum(x["lot_facts_total"] for x in out),
      "facts_mis", sum(x["lot_facts_misattributed"] for x in out))
