# k8 measurer (adapted from k6) for issue 570: per tender, each notice's lot-section key -> printed number map, cross-notice
# disagreement (same key/different number; same number/different key; unnumbered -> title compare), the Tender
# lot identity (which notice's section at the served key carries the served title, and its printed number), and
# served results / lot facts that sit on a Tender lot that is another lot. Reads only cache_k8; writes measure_k8.auto.json.
import json, re, unicodedata
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
C = ROOT + "/cache_k8"
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-TITLE", "TED-LOT_TITLE")
RTITF = ("TED-TITLE", "TED-CONTRACT_TITLE")
LOTKINDS = ("Lot", "LotsGroup", "Part")

def norm_no(x):
    s = unicodedata.normalize("NFKD", str(x)).lower().strip()
    s = re.sub(r"^(lot[eo]?|los|lotto|cast|część|czesc|zadanie|pakiet|partie|part)\b\.?", "", s).strip()
    s = re.sub(r"^(n[o°º]\.?|nr\.?)\s*", "", s)
    s = re.sub(r"[^0-9a-z]", "", s)
    return str(int(s)) if s.isdigit() else s

def is_single_number(x):
    # a printed number naming exactly one lot (not "1, 2 и 3", "15 и 19", "1,3,9")
    return bool(re.fullmatch(r"\s*(lot[eo]?\s*|n[o°º]\.?\s*|nr\.?\s*)?0*\d+[a-z]?\s*", unicodedata.normalize("NFKD", str(x)).lower()))

def norm_txt(x):
    s = unicodedata.normalize("NFKD", str(x)).lower()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"[\W_]", "", s)

def vals(sec, fids):
    return [v.get("value", v.get("code")) for v in sec["values"] if v["field_id"] in fids]

def secinfo(sec, titf):
    nos = vals(sec, NOF)
    single = [n for n in nos if is_single_number(n)]
    return {"no": nos, "nno": sorted(set(norm_no(n) for n in single)), "multi": [n for n in nos if not is_single_number(n)],
            "item": vals(sec, ("TED-ITEM",)), "titles": vals(sec, titf), "values": sec["values"]}

def load_notice(n):
    c = json.load(open(f"{C}/notice_{n}.json"))
    lots = {s["section_id"]: secinfo(s, TITF) for s in c["sections"] if s["kind"] in LOTKINDS}
    res = {s["section_id"]: secinfo(s, RTITF) for s in c["sections"] if s["kind"] == "LotResult"}
    return lots, res

def kn(k):
    m = re.search(r"(\d+)$", k or ""); return int(m.group(1)) if m else 0

def one(nno):
    return nno[0] if len(nno) == 1 else None

def fact_in_section(kind, fact, sec):
    for v in sec["values"]:
        val = v.get("value", v.get("code"))
        if val is None: continue
        if kind == "classification":
            if str(val) == str(fact): return True
        elif kind == "date":
            if str(val)[:10] == str(fact)[:10]: return True
        else:
            if isinstance(val, str) and norm_txt(val) and norm_txt(val) == norm_txt(fact): return True
    return False

def measure(tid, can):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    vnids = [v["caused_by_notice_id"] for v in t["versions"]]
    rnids = [r["notice_id"] for r in t["lot_results"] if r["notice_id"] not in vnids]
    notices = {n: load_notice(n) for n in dict.fromkeys(vnids + rnids)}
    lotpub = [n for n in notices if notices[n][0]]
    maps = {n: {k: notices[n][0][k]["no"] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    titles = {n: {k: (notices[n][0][k]["titles"] or [None])[0] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    unnumbered = [n for n in lotpub if any(not s["nno"] for s in notices[n][0].values())]
    dis, title_diff = [], []
    for i, a in enumerate(lotpub):
        for b in lotpub[i + 1:]:
            A, B = notices[a][0], notices[b][0]
            for k in sorted(set(A) & set(B), key=kn):
                if A[k]["nno"] and B[k]["nno"] and A[k]["nno"] != B[k]["nno"]:
                    dis.append({"type": "same-key-different-number", "key": k, str(a): A[k]["no"], str(b): B[k]["no"],
                                "titles": {str(a): A[k]["titles"][:1], str(b): B[k]["titles"][:1]}})
                ta = {norm_txt(x) for x in A[k]["titles"]}; tb = {norm_txt(x) for x in B[k]["titles"]}
                if ta and tb and not (ta & tb):
                    title_diff.append({"key": k, str(a): (A[k]["no"], A[k]["titles"][:1]), str(b): (B[k]["no"], B[k]["titles"][:1])})
            na = {x: k for k, s in A.items() for x in s["nno"]}; nb = {x: k for k, s in B.items() for x in s["nno"]}
            for x in sorted(set(na) & set(nb)):
                if na[x] != nb[x]:
                    dis.append({"type": "same-number-different-key", "number": x, str(a): na[x], str(b): nb[x]})
    served = {l["lot_key"]: l for l in t["lot_details"]}
    ident = {}
    for k, l in served.items():
        src = [n for n in lotpub if k in notices[n][0] and l["title"] and norm_txt(l["title"]) in {norm_txt(x) for x in notices[n][0][k]["titles"]}]
        nos = sorted({one(notices[n][0][k]["nno"]) for n in src} - {None})
        allnos = {str(n): notices[n][0][k]["no"] for n in lotpub if k in notices[n][0]}
        if not src:
            nos = sorted({one(notices[n][0][k]["nno"]) for n in lotpub if k in notices[n][0]} - {None})
        ident[k] = {"title": l["title"], "title_from": src, "number": nos[0] if len(nos) == 1 else (nos or None), "key_numbers_by_notice": allnos}
    rows, mis = [], []
    for r in t["lot_results"]:
        n = r["notice_id"]; lots, res = notices[n]
        blk = res.get(r["key"], {"no": [], "nno": [], "multi": [], "item": [], "titles": []})
        p = one(blk["nno"])
        own = [k for k, s in lots.items() if p is not None and p in s["nno"]]
        L = r["lot"]
        tl = ident.get(L, {}).get("number") if L else None
        row = {"notice": n, "key": r["key"], "printed": blk["no"], "item": blk["item"], "served_lot": L, "decision": r.get("decision"),
               "own_section": own, "tender_lot_number": tl, "tender_lot_title": (ident.get(L, {}).get("title") or "")[:70] if L else None,
               "block_title": blk["titles"][0][:70] if blk["titles"] else None}
        verdict = "null" if L is None else "ok"
        if L is not None:
            if p is not None and tl is not None and p != tl:
                verdict = "MISATTRIBUTED"
            elif p is None:
                on = one(lots[L]["nno"]) if L in lots else None
                if on is not None and tl is not None and on != tl: verdict = "MISATTRIBUTED(no-number, own %s=%s)" % (L, on)
                else: verdict = "ok(no-number; own %s=%s)" % (L, on)
        row["verdict"] = verdict
        rows.append(row)
        if verdict.startswith("MIS"): mis.append(row)
    facts = []
    for c in t["classifications"]:
        if c.get("lot"): facts.append(("classification", c["lot"], c["code"], f"{c['scheme']}:{c['field']}"))
    for x in t["texts"]:
        if x.get("lot"): facts.append(("text", x["lot"], x["value"], "text:" + x["field"]))
    for x in t["dates"]:
        if x.get("lot"): facts.append(("date", x["lot"], x["value"], "date:" + x["field"]))
    for k, l in served.items():
        if l.get("title"): facts.append(("text", k, l["title"], "lot_details:title"))
    fo = {"total": 0, "ok": 0, "misattributed": 0, "unsourced": 0, "examples": []}
    for kind, K, val, label in facts:
        fo["total"] += 1
        home = [n for n in lotpub if K in notices[n][0] and fact_in_section(kind, val, notices[n][0][K])]
        if not home:
            fo["unsourced"] += 1
            if len(fo["examples"]) < 6: fo["examples"].append({"unsourced": label, "lot": K, "value": str(val)[:60]})
            continue
        homenos = {one(notices[n][0][K]["nno"]) for n in home}
        keynos = {one(notices[n][0][K]["nno"]) for n in lotpub if K in notices[n][0]} - {None}
        # a fact is suspect when the notices that carry it at key K name a lot number another lot-publishing
        # notice does not give key K (the key means two lots and the fact comes from only one of them)
        if len(keynos) > 1:
            fo["examples"].append({"KEY-SPLIT": label, "lot": K, "value": str(val)[:70], "from": home, "from_numbers": sorted(x for x in homenos if x), "key_numbers": sorted(keynos)})
        fo["ok"] += 1
    winner_parties_on_mis = [p for p in t["parties"] if p.get("lot") and p.get("role") == "winner" and any(
        m["served_lot"] == p["lot"] for m in mis)]
    if len(lotpub) <= 1: cls = "single_lot_notice"
    elif unnumbered and not dis: cls = "unnumbered"
    elif not dis: cls = "consistent"
    elif mis: cls = "disagree_harmful"
    else: cls = "disagree_harmless?"  # fact-level harm judged by hand from KEY-SPLIT examples
    return {"tender_id": tid, "can_notice_id": can, "versions": vnids, "lot_publishing_notices": lotpub,
            "n_notices_with_lot_sections": len(lotpub), "maps": maps, "titles": titles, "unnumbered_notices": unnumbered,
            "disagreements": dis, "title_differences_same_key": title_diff, "tender_lots": ident, "results": rows,
            "results_total": len(rows), "results_null": sum(1 for r in rows if r["served_lot"] is None),
            "results_misattributed": len(mis), "winner_parties_on_misattributed_lots": winner_parties_on_mis,
            "lot_facts": fo, "cls_auto": cls}

g = json.load(open(ROOT + "/groups.json"))
items = [it for grp in g["groups"] if grp["key"] == "k8" for it in grp["items"]]
out = [measure(it["tender_id"], it["can_notice_id"]) for it in items]
json.dump(out, open(ROOT + "/measure_k8.auto.json", "w"), indent=1, ensure_ascii=False)
for o in out:
    print(o["tender_id"], o["cls_auto"], "lotpub", o["lot_publishing_notices"], "unnum", o["unnumbered_notices"], "dis", len(o["disagreements"]),
          "res", o["results_total"], "null", o["results_null"], "mis", o["results_misattributed"],
          "facts", {k: v for k, v in o["lot_facts"].items() if k != "examples"})
    for d in o["disagreements"]: print("    DIS", json.dumps(d, ensure_ascii=False)[:300])
    for d in o["title_differences_same_key"]: print("    TITLE", json.dumps(d, ensure_ascii=False)[:300])
    for r in o["results"]:
        if r["verdict"] != "ok": print("    RES", json.dumps(r, ensure_ascii=False)[:300])
    for e in o["lot_facts"]["examples"]: print("    FACT", json.dumps(e, ensure_ascii=False)[:300])
