# k8 measurer for issue 570 (own logic; reads only cache_k8, writes measure_k8.auto.json).
# Per tender: each lot-publishing notice's section key -> printed number (+ title) map; cross-notice disagreement
# (same key / different normalised number; same number / different key; same key / clearly different title);
# the identity of each served Tender lot (the notice(s) whose section at that key carries the served title, and the
# number that section prints); served lot_results whose block prints a number other than the Tender lot's identity
# number (misattributed); lot facts (classifications/texts/dates/amounts with a lot, lot_details title) whose value is
# found only in sections that print a number other than the Tender lot's identity number (misattributed).
import json, re, sys, unicodedata, difflib
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
C = ROOT + "/cache_k8"
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-TITLE", "TED-LOT_TITLE")
RTITF = ("TED-TITLE", "TED-CONTRACT_TITLE", "TED-LOT_TITLE")
LOTKINDS = ("Lot", "LotsGroup", "Part")


def norm_no(x):
    s = unicodedata.normalize("NFKD", str(x)).lower().strip()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"^(lot[eo]?s?|los|lotto|cast|czesc|zadanie|zad|pakiet|partie|part|teil|deel|perceel|osa|delomrade)\b\.?", "", s).strip()
    s = re.sub(r"^(n[o°º]\.?|nr\.?)\s*", "", s)
    s = re.sub(r"[^0-9a-z]", "", s)
    return str(int(s)) if s.isdigit() else s


def single(x):
    s = unicodedata.normalize("NFKD", str(x)).lower()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return bool(re.fullmatch(r"\s*((lot[eo]?|los|lotto|cast|czesc|zadanie|zad|pakiet|partie|part|teil|deel|perceel)\.?\s*)?(n[o°º]\.?\s*|nr\.?\s*)?0*\d+[a-z]?\s*\.?\s*", s))


def norm_txt(x):
    s = unicodedata.normalize("NFKD", str(x)).lower()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"[\W_]", "", s)


def sim(a, b):
    a, b = norm_txt(a), norm_txt(b)
    if not a or not b: return None
    if a in b or b in a: return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def vals(sec, fids):
    return [v.get("value", v.get("code")) for v in sec["values"] if v["field_id"] in fids]


def secinfo(sec, titf):
    nos = vals(sec, NOF)
    sn = sorted(set(norm_no(n) for n in nos if single(n)))
    return {"no": nos, "n": sn[0] if len(sn) == 1 else None, "item": vals(sec, ("TED-ITEM",)),
            "titles": [t for t in vals(sec, titf) if t], "values": sec["values"]}


def kn(k):
    m = re.search(r"(\d+)$", k or ""); return int(m.group(1)) if m else 0


NOTICES = {}


def load_notice(n):
    if n in NOTICES: return NOTICES[n]
    try:
        c = json.load(open(f"{C}/notice_{n}.json"))
    except FileNotFoundError:
        NOTICES[n] = None; return None
    lots = {s["section_id"]: secinfo(s, TITF) for s in c["sections"] if s["kind"] in LOTKINDS}
    res = {s["section_id"]: secinfo(s, RTITF) for s in c["sections"] if s["kind"] == "LotResult"}
    nt = [s for s in c["sections"] if s["kind"] == "Notice"]
    meta = {"form": vals(nt[0], ("TED-FORM",)) if nt else [], "pub": (vals(nt[0], ("TED-DATE_PUB",)) or [None])[0] if nt else None}
    NOTICES[n] = (lots, res, meta, c)
    return NOTICES[n]


def value_matches(kind, fact, v):
    val = v.get("value", v.get("code"))
    if val is None: return False
    if kind == "classification": return str(val) == str(fact)
    if kind == "date": return str(val)[:10] == str(fact)[:10]
    if kind == "amount":
        return False  # amounts are not field-addressable here; judged by hand
    return isinstance(val, str) and norm_txt(val) != "" and norm_txt(val) == norm_txt(fact)


def measure(tid, can):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    vnids = [v["caused_by_notice_id"] for v in t["versions"]]
    rnids = [r["notice_id"] for r in t["lot_results"] if r["notice_id"] not in vnids]
    nids = list(dict.fromkeys(vnids + rnids + [can]))
    notices = {n: load_notice(n) for n in nids}
    missing = [n for n in nids if notices[n] is None]
    notices = {n: x for n, x in notices.items() if x is not None}
    lotpub = [n for n in nids if n in notices and notices[n][0]]
    maps = {str(n): {k: notices[n][0][k]["no"] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    titles = {str(n): {k: (notices[n][0][k]["titles"] or [None])[0] for k in sorted(notices[n][0], key=kn)} for n in lotpub}
    unnum = {str(n): [k for k, s in notices[n][0].items() if s["n"] is None] for n in lotpub}
    unnum = {n: ks for n, ks in unnum.items() if ks}
    dis, tdiff = [], []
    for i, a in enumerate(lotpub):
        for b in lotpub[i + 1:]:
            A, B = notices[a][0], notices[b][0]
            for k in sorted(set(A) & set(B), key=kn):
                if A[k]["n"] and B[k]["n"] and A[k]["n"] != B[k]["n"]:
                    dis.append({"type": "same-key-different-number", "key": k, str(a): A[k]["no"], str(b): B[k]["no"],
                                "titles": {str(a): A[k]["titles"][:1], str(b): B[k]["titles"][:1]}})
                if A[k]["titles"] and B[k]["titles"]:
                    s = max(sim(x, y) or 0 for x in A[k]["titles"] for y in B[k]["titles"])
                    if s < 0.75:
                        tdiff.append({"key": k, "sim": round(s, 2), str(a): [A[k]["no"], A[k]["titles"][0][:90]], str(b): [B[k]["no"], B[k]["titles"][0][:90]]})
            na = {}; nb = {}
            for k, s in A.items():
                if s["n"]: na.setdefault(s["n"], []).append(k)
            for k, s in B.items():
                if s["n"]: nb.setdefault(s["n"], []).append(k)
            for x in sorted(set(na) & set(nb)):
                if set(na[x]) != set(nb[x]):
                    dis.append({"type": "same-number-different-key", "number": x, str(a): na[x], str(b): nb[x]})
    # duplicate numbers inside one notice
    dups = {}
    for n in lotpub:
        seen = {}
        for k, s in notices[n][0].items():
            if s["n"]: seen.setdefault(s["n"], []).append(k)
        d = {x: ks for x, ks in seen.items() if len(ks) > 1}
        if d: dups[str(n)] = d
    served = {l["lot_key"]: l for l in t["lot_details"]}
    ident = {}
    for k, l in served.items():
        at = {n: notices[n][0][k] for n in lotpub if k in notices[n][0]}
        src = [n for n, s in at.items() if l.get("title") and norm_txt(l["title"]) in {norm_txt(x) for x in s["titles"]}]
        nos = sorted({at[n]["n"] for n in src} - {None})
        how = "title"
        if not src:
            nos = sorted({s["n"] for s in at.values()} - {None})
            how = "all-notices-at-key" if len(nos) <= 1 else "AMBIGUOUS(no title source; notices disagree)"
        ident[k] = {"title": l.get("title"), "title_from": src, "number": nos[0] if len(nos) == 1 else None,
                    "numbers_if_ambiguous": nos if len(nos) > 1 else None, "how": how,
                    "key_numbers_by_notice": {str(n): s["no"] for n, s in at.items()},
                    "key_titles_by_notice": {str(n): (s["titles"] or [None])[0] for n, s in at.items()}}
    rows, mis = [], []
    for r in t["lot_results"]:
        n = r["notice_id"]
        lots, res = (notices[n][0], notices[n][1]) if n in notices else ({}, {})
        blk = res.get(r["key"], {"no": [], "n": None, "item": [], "titles": []})
        p = blk["n"]
        L = r["lot"]
        idn = ident.get(L, {}).get("number") if L else None
        own = sorted([k for k, s in lots.items() if p is not None and s["n"] == p], key=kn)
        row = {"notice": n, "key": r["key"], "printed": blk["no"], "item": blk["item"], "served_lot": L,
               "decision": r.get("decision"), "own_notice_section_for_printed": own,
               "tender_lot_identity_number": idn, "tender_lot_title": (ident.get(L, {}).get("title") or "")[:80] if L else None,
               "block_title": blk["titles"][0][:80] if blk["titles"] else None,
               "winners": [w.get("organization_name", "")[:50] for w in r.get("winners", [])]}
        if L is None:
            v = "null"
        elif p is not None and idn is not None:
            v = "ok" if p == idn else "MISATTRIBUTED"
        elif p is not None and idn is None:
            v = "UNJUDGED(identity ambiguous)" if ident.get(L, {}).get("numbers_if_ambiguous") else "ok(identity unnumbered)"
        else:
            on = lots[L]["n"] if L in lots else None
            if on is not None and idn is not None and on != idn:
                v = f"MISATTRIBUTED(no-number block; own {L} prints {on})"
            else:
                v = f"ok(no-number block; own {L} prints {on})"
        row["verdict"] = v
        rows.append(row)
        if v.startswith("MIS"): mis.append(row)
    # lot facts
    facts = []
    for c in t.get("classifications", []):
        if c.get("lot"): facts.append(("classification", c["lot"], c["code"], f"cls:{c.get('scheme')}:{c.get('field')}"))
    for x in t.get("texts", []):
        if x.get("lot"): facts.append(("text", x["lot"], x["value"], "text:" + x["field"]))
    for x in t.get("dates", []):
        if x.get("lot"): facts.append(("date", x["lot"], x["value"], "date:" + x["field"]))
    for k, l in served.items():
        if l.get("title"): facts.append(("text", k, l["title"], "lot_details:title"))
    other_lot_facts = []
    for key in ("amounts", "bids", "contracts", "parties"):
        for x in t.get(key, []):
            if isinstance(x, dict) and x.get("lot"): other_lot_facts.append((key, x))
    fo = {"total": 0, "ok": 0, "misattributed": 0, "unsourced": 0, "unjudged": 0, "mis": [], "unsourced_ex": []}
    # all sections (any notice, lot sections) with their printed number
    allsecs = [(n, k, s) for n in lotpub for k, s in notices[n][0].items()]
    for kind, K, val, label in facts:
        fo["total"] += 1
        idn = ident.get(K, {}).get("number")
        home = [(n, k, s) for n, k, s in allsecs if any(value_matches(kind, val, v) for v in s["values"])]
        home_at_k = [(n, k, s) for n, k, s in home if k == K]
        if not home_at_k:
            fo["unsourced"] += 1
            if len(fo["unsourced_ex"]) < 5: fo["unsourced_ex"].append({"label": label, "lot": K, "value": str(val)[:60]})
            continue
        if idn is None:
            keynos = {s["n"] for n, k, s in home_at_k}
            if len({s["n"] for n2, k2, s in allsecs if k2 == K} - {None}) > 1:
                fo["unjudged"] += 1
            else:
                fo["ok"] += 1
            continue
        right = [(n, k) for n, k, s in home if s["n"] == idn]
        if right:
            fo["ok"] += 1
        else:
            fo["misattributed"] += 1
            fo["mis"].append({"label": label, "lot": K, "value": str(val)[:70], "identity_number": idn,
                              "from": [(n, k, s["no"]) for n, k, s in home_at_k]})
    if len(lotpub) <= 1:
        cls = "single_lot_notice"
    elif dis:
        cls = "disagree_harmful" if (mis or fo["misattributed"]) else "disagree_harmless"
    elif unnum and len([n for n in lotpub if str(n) not in unnum]) <= 1:
        cls = "unnumbered"
    else:
        cls = "consistent"
    return {"tender_id": tid, "can_notice_id": can, "versions": vnids, "missing_notices": missing,
            "notice_meta": {str(n): notices[n][2] for n in notices},
            "lot_publishing_notices": lotpub, "n_notices_with_lot_sections": len(lotpub), "maps": maps,
            "titles": titles, "unnumbered_sections": unnum, "duplicate_numbers": dups,
            "disagreements": dis, "title_differences_same_key": tdiff, "tender_lots": ident,
            "results": rows, "results_total": len(rows), "results_null": sum(1 for r in rows if r["served_lot"] is None),
            "results_misattributed": len(mis), "lot_facts": fo,
            "result_derived_lot_facts": len(other_lot_facts), "cls_auto": cls}


if __name__ == "__main__":
    g = json.load(open(ROOT + "/groups.json"))
    items = [it for grp in g["groups"] if grp["key"] == "k8" for it in grp["items"]]
    only = sys.argv[1:]
    out = [measure(it["tender_id"], it["can_notice_id"]) for it in items if not only or str(it["tender_id"]) in only]
    if not only:
        json.dump(out, open(ROOT + "/measure_k8.auto.json", "w"), indent=1, ensure_ascii=False)
    for o in out:
        print(o["tender_id"], o["cls_auto"], "lotpub", o["lot_publishing_notices"], "missing", o["missing_notices"],
              "unnum", {k: len(v) for k, v in o["unnumbered_sections"].items()}, "dups", o["duplicate_numbers"],
              "dis", len(o["disagreements"]), "res", o["results_total"], "null", o["results_null"],
              "mis", o["results_misattributed"],
              "facts", {k: v for k, v in o["lot_facts"].items() if k not in ("mis", "unsourced_ex")})
        for d in o["disagreements"][:12]: print("    DIS", json.dumps(d, ensure_ascii=False)[:260])
        for d in o["title_differences_same_key"][:12]: print("    TITLE", json.dumps(d, ensure_ascii=False)[:260])
        for k, i in o["tender_lots"].items():
            if i["how"] != "title" or len(set(map(str, i["key_numbers_by_notice"].values()))) > 1:
                print("    LOT", k, json.dumps(i, ensure_ascii=False)[:300])
        for r in o["results"]:
            if r["verdict"] not in ("ok", "null"): print("    RES", json.dumps(r, ensure_ascii=False)[:300])
        for e in o["lot_facts"]["mis"][:10]: print("    FACTMIS", json.dumps(e, ensure_ascii=False)[:300])
