import json,sys,os
def fv(s,f):
    return [v.get('value', v.get('code')) for v in s['values'] if v['field_id']==f]
for path in sys.argv[1:]:
    n=json.load(open(path))
    td=[v.get('code') for s in n['sections'] for v in s['values'] if v['field_id']=='TED-TD_DOCUMENT_TYPE']
    kinds={}
    for s in n['sections']: kinds[s['kind']]=kinds.get(s['kind'],0)+1
    print('#####', path, 'TD', td, kinds, [k for k in n.keys() if k!='sections'])
    for s in n['sections']:
        if s['kind'] in ('Lot','LotResult','LotsGroup','Part','SettledContract'):
            out={}
            for v in s['values']:
                f=v['field_id']
                if f in ('TED-ITEM','TED-LOT_NO','TED-LOT_NUMBER','TED-TITLE','TED-LOT_TITLE','TED-CONTRACT_NO','TED-CONTRACT_NUMBER','TED-CPV_CODE','TED-OFFICIALNAME','TED-VAL_TOTAL','TED-VAL_ESTIMATED_TOTAL','TED-VAL_OBJECT'):
                    out.setdefault(f.replace('TED-',''),[]).append(str(v.get('value', v.get('code')))[:80])
            print('  ',s['section_id'],s['kind'],'par',s.get('parent_section_id'),json.dumps(out,ensure_ascii=False))
