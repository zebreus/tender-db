import json,sys,os,re
L='live'; C='../cache_k2'
def load(name):
    p=os.path.join(L,name)
    if not os.path.exists(p): p=os.path.join(C,name)
    return json.load(open(p)), p
def fv(s,fs):
    return [str(v.get('value', v.get('code'))) for v in s['values'] if v['field_id'] in fs]
def norm(x):
    d=re.findall(r'\d+',x)
    return str(int(d[0])) if len(d)==1 else re.sub(r'[^0-9a-z]','',x.lower())
NO=('TED-LOT_NO','TED-LOT_NUMBER')
for tid in sys.argv[1:]:
    t,tp=load(f'tender_{tid}.json')
    print('='*90); print('TENDER',tid,tp,'v',t['version'],'lots',t['lots'],t['title'][:80])
    for l in t['lot_details']: print('  served',l['lot_key'],'|',(l['title'] or '')[:90])
    maps={}
    for v in t['versions']:
        n=v['caused_by_notice_id']
        c,p=load(f'notice_{n}.json')
        td=[x.get('code') for s in c['sections'] for x in s['values'] if x['field_id']=='TED-TD_DOCUMENT_TYPE']
        lots={s['section_id']:(fv(s,NO),fv(s,('TED-ITEM',)),(fv(s,('TED-TITLE','TED-LOT_TITLE')) or [''])[0]) for s in c['sections'] if s['kind']=='Lot'}
        res={s['section_id']:(fv(s,NO),fv(s,('TED-ITEM',)),(fv(s,('TED-TITLE',)) or [''])[0]) for s in c['sections'] if s['kind']=='LotResult'}
        print('  NOTICE',n,p,'td',td,'nlots',len(lots),'nres',len(res))
        for k,x in lots.items(): print('     L',k,x[0],'item',x[1],'|',x[2][:80])
        for k,x in res.items(): print('     R',k,x[0],'item',x[1],'|',x[2][:80])
        if lots: maps[n]=lots
    # disagreement
    ns=list(maps)
    for i in range(len(ns)):
        for j in range(i+1,len(ns)):
            a,b=maps[ns[i]],maps[ns[j]]
            for k in sorted(set(a)&set(b)):
                na={norm(x) for x in a[k][0]}; nb={norm(x) for x in b[k][0]}
                if na!=nb: print('  DISAGREE key',k,ns[i],a[k][0],ns[j],b[k][0])
            ia={norm(x):k for k,s in a.items() for x in s[0]}; ib={norm(x):k for k,s in b.items() for x in s[0]}
            for x in sorted(set(ia)&set(ib)):
                if ia[x]!=ib[x]: print('  DISAGREE num',x,ns[i],ia[x],ns[j],ib[x])
            for k in sorted(set(a)&set(b)):
                if a[k][2] and b[k][2] and a[k][2].strip().lower()!=b[k][2].strip().lower(): print('  TITLEDIFF',k,'|',a[k][2][:70],'|',b[k][2][:70])
    served={l['lot_key']:l['title'] for l in t['lot_details']}
    for r in t['lot_results']:
        c,_=load(f"notice_{r['notice_id']}.json")
        sec=[s for s in c['sections'] if s['kind']=='LotResult' and s['section_id']==r['key']]
        pn=fv(sec[0],NO) if sec else None
        own=None
        if pn:
            own=[s['section_id'] for s in c['sections'] if s['kind']=='Lot' and {norm(x) for x in fv(s,NO)}&{norm(x) for x in pn}]
        print('  RESULT',r['notice_id'],r['key'],'printed',pn,'own-sec',own,'served-lot',r['lot'],'|',(served.get(r['lot']) or '')[:60], r['decision'], [w['organization_name'][:25] for w in r['winners']])
    print('  parties-with-lot',[(p['lot'],p['organization_name'][:30],p['role']) for p in t['parties'] if p['lot']])
