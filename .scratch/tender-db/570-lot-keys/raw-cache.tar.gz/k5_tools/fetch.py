# k5 fetcher for issue 570: GET /v1/tenders/{id} and /v1/notices/{id}/content for every version notice
# (plus any lot_results notice not among versions, plus the group's CAN). <=1 GET / 1.6 s; a 408 retried once.
import json, os, time, subprocess
BASE = 'https://tenders.zebreus.click'
ROOT = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
CACHE = ROOT + '/cache_k5'
last = [0.0]
def get(path, out):
    if os.path.exists(out):
        return json.load(open(out))
    for attempt in range(2):
        wait = 1.6 - (time.time() - last[0])
        if wait > 0: time.sleep(wait)
        last[0] = time.time()
        tmp = out + '.tmp'
        r = subprocess.run(['curl', '-sS', '-o', tmp, '-w', '%{http_code}', '--max-time', '120',
                            '-H', 'Accept: application/json', BASE + path], capture_output=True, text=True)
        code = r.stdout.strip()
        print(path, code, flush=True)
        if code == '200':
            os.rename(tmp, out); return json.load(open(out))
        if code == '408' and attempt == 0:
            continue
        with open(out + '.err', 'w') as f: f.write(code + '\n' + r.stderr)
        return None
g = json.load(open(ROOT + '/groups.json'))
items = [it for grp in g['groups'] if grp['key'] == 'k5' for it in grp['items']]
for it in items:
    tid = it['tender_id']
    t = get(f'/v1/tenders/{tid}', f'{CACHE}/tender_{tid}.json')
    if not t: continue
    nids = [v['caused_by_notice_id'] for v in t.get('versions', [])]
    nids += [r.get('notice_id') for r in t.get('lot_results', []) if r.get('notice_id')]
    nids.append(it['can_notice_id'])
    for nid in dict.fromkeys(nids):
        if nid is None: continue
        get(f'/v1/notices/{nid}/content', f'{CACHE}/notice_{nid}.json')
print('DONE', flush=True)
