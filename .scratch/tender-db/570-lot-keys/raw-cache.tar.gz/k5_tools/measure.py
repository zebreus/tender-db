# k5 measurer for issue 570. Reads only cache_k5 (raw API reads made by k5_tools/fetch.py); writes measure_k5.json.
# Per tender: each lot-publishing notice's map section key -> printed LOT_NO/LOT_NUMBER (+ title); pairwise
# disagreement (same key, different normalised number; same number, different key; unnumbered -> title compare);
# the identity of each served Tender lot (the printed number of the section, at that key, whose title the served
# lot carries); served lot_results whose printed number is not that identity (misattributed at Tender level);
# lot facts (classifications/texts/dates/lot_details title) whose only source section prints another number.
import json, re, unicodedata, difflib
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
C = ROOT + "/cache_k5"
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-TITLE", "TED-LOT_TITLE")
RTITF = ("TED-TITLE", "TED-CONTRACT_TITLE")
PREFIX = r"^(lot|lots|los|lose|lote|lotes|lotto|lotti|lotu|loti|part|partie|cast|zadanie|pakiet|delkontrakt|osa|tranche)\b\.?"

def strip_acc(s):
    s = unicodedata.normalize("NFKD", str(s))
    return "".join(ch for ch in s if not unicodedata.combining(ch))

def norm_no(x):
    s = strip_acc(x).lower().strip()
    s = re.sub(PREFIX, "", s).strip()
    s = re.sub(r"^(n[o°º]\.?|nr\.?|num\.?)\s*", "", s).strip()
    toks = re.findall(r"[0-9]+|[a-z]+", s)
    toks = [str(int(t)) if t.isdigit() else t for t in toks]
    return ".".join(toks)

def norm_txt(x):
    return re.sub(r"[\W_]", "", strip_acc(x).lower())

def tsim(a, b):
    a, b = norm_txt(a), norm_txt(b)
    if not a or not b: return 0.0
    if a == b: return 1.0
    if len(a) >= 12 and len(b) >= 12 and (a in b or b in a): return 0.95
    return difflib.SequenceMatcher(None, a, b).ratio()

def vals(sec, fids):
    return [v.get("value", v.get("code")) for v in sec["values"] if v["field_id"] in fids]

def info(sec, titf):
    nos = vals(sec, NOF)
    return {"no": nos, "nno": sorted(set(norm_no(n) for n in nos if norm_no(n))), "item": vals(sec, ("TED-ITEM",)),
            "titles": [t for t in vals(sec, titf) if t], "values": sec["values"]}

def kn(k):
    m = re.search(r"(\d+)$", k); return int(m.group(1)) if m else 0

def one(nno):
    return nno[0] if len(nno) == 1 else None

def load_notice(n):
    c = json.load(open(f"{C}/notice_{n}.json"))
    lots = {s["section_id"]: info(s, TITF) for s in c["sections"] if s["kind"] == "Lot"}
    res = {s["section_id"]: info(s, RTITF) for s in c["sections"] if s["kind"] == "LotResult"}
    return lots, res

def fact_in(kind, val, sec):
    for v in sec["values"]:
        x = v.get("value", v.get("code"))
        if x is None: continue
        if kind == "classification":
            if v["type"] == "classification" and str(x) == str(val): return True
        elif kind == "date":
            if v["type"] == "date" and str(x)[:10] == str(val)[:10]: return True
        else:
            if isinstance(x, str) and tsim(x, val) >= 0.9: return True
    return False

def measure(tid):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    vn = [v["caused_by_notice_id"] for v in t["versions"]]
    allnids = list(dict.fromkeys(vn + [r["notice_id"] for r in t["lot_results"]]))
    N = {n: load_notice(n) for n in allnids}
    lotpub = [n for n in allnids if N[n][0]]
    maps = {n: {k: N[n][0][k]["no"] for k in sorted(N[n][0], key=kn)} for n in lotpub}
    titles = {n: {k: (N[n][0][k]["titles"] or [None])[0] for k in sorted(N[n][0], key=kn)} for n in lotpub}
    unnumbered = {n: [k for k, s in N[n][0].items() if not s["nno"]] for n in lotpub}
    unnumbered = {n: ks for n, ks in unnumbered.items() if ks}
    dis = []
    for i, a in enumerate(lotpub):
        for b in lotpub[i + 1:]:
            A, B = N[a][0], N[b][0]
            for k in sorted(set(A) & set(B), key=kn):
                ta, tb = (A[k]["titles"] or [""])[0], (B[k]["titles"] or [""])[0]
                if A[k]["nno"] and B[k]["nno"]:
                    if A[k]["nno"] != B[k]["nno"]:
                        dis.append({"type": "same-key-different-number", "key": k, "a": a, "a_no": A[k]["no"], "a_title": ta[:60],
                                    "b": b, "b_no": B[k]["no"], "b_title": tb[:60], "title_sim": round(tsim(ta, tb), 2)})
                else:
                    s = tsim(ta, tb)
                    if s < 0.6:
                        dis.append({"type": "unnumbered-title-differs", "key": k, "a": a, "a_title": ta[:60], "b": b, "b_title": tb[:60], "title_sim": round(s, 2)})
            na = {x: k for k, s in A.items() for x in s["nno"]}; nb = {x: k for k, s in B.items() for x in s["nno"]}
            for x in sorted(set(na) & set(nb)):
                if na[x] != nb[x]:
                    dis.append({"type": "same-number-different-key", "number": x, "a": a, "a_key": na[x], "b": b, "b_key": nb[x]})
    # identity of served Tender lots
    ident = {}
    for l in t["lot_details"]:
        k, T = l["lot_key"], l["title"] or ""
        cand = []
        for n in lotpub:
            s = N[n][0].get(k)
            if s and s["titles"]:
                cand.append((max(tsim(T, x) for x in s["titles"]), n, one(s["nno"])))
        good = [c for c in cand if c[0] >= 0.9]
        if good:
            nos = sorted({c[2] for c in good} - {None}); src = [c[1] for c in good]
        else:
            nos = sorted({c[2] for c in cand} - {None}); src = []
        ident[k] = {"title": T, "title_from": src, "number": nos[0] if len(nos) == 1 else (nos or None),
                    "numbers_at_key_by_notice": {n: N[n][0][k]["no"] for n in lotpub if k in N[n][0]}}
    # results
    rows, mis = [], []
    for r in t["lot_results"]:
        n = r["notice_id"]; lots, res = N[n]
        b = res.get(r["key"], {"no": [], "nno": [], "item": [], "titles": []})
        p = one(b["nno"]); L = r["lot"]
        own = [k for k, s in lots.items() if p is not None and p in s["nno"]]
        idn = ident.get(L, {}).get("number") if L else None
        row = {"notice": n, "key": r["key"], "printed": b["no"], "item": b["item"], "served_lot": L, "own_section": own,
               "tender_lot_number": idn, "tender_lot_title": (ident.get(L, {}).get("title") or "")[:60] if L else None,
               "block_title": (b["titles"] or [""])[0][:60], "decision": r["decision"],
               "winners": [w.get("organization_name") for w in r.get("winners", [])]}
        if L is None:
            v = "unplaced"
        elif isinstance(idn, list) or idn is None:
            v = "identity-ambiguous"
        elif p is not None:
            v = "ok" if p == idn else "MISATTRIBUTED"
        else:
            on = one(lots[L]["nno"]) if L in lots else None
            v = ("MISATTRIBUTED(no-number; own %s=%s)" % (L, on)) if (on is not None and on != idn) else ("ok(no-number; own %s=%s)" % (L, on))
        if p is not None and own and L is not None and L not in own: row["same_notice_mismatch"] = True
        row["verdict"] = v
        rows.append(row)
        if v.startswith("MIS"): mis.append(row)
    # lot facts
    facts = []
    for c in t["classifications"]:
        if c.get("lot"): facts.append(("classification", c["lot"], c["code"], "%s:%s" % (c["scheme"], c["field"])))
    for x in t["texts"]:
        if x.get("lot"): facts.append(("text", x["lot"], x["value"], "text:" + x["field"]))
    for x in t["dates"]:
        if x.get("lot"): facts.append(("date", x["lot"], x["value"], "date:" + x["field"]))
    for l in t["lot_details"]:
        if l.get("title"): facts.append(("text", l["lot_key"], l["title"], "lot_details.title"))
    fo = {"total": 0, "ok": 0, "misattributed": 0, "unsourced": 0, "ambiguous_identity": 0, "examples": []}
    for kind, K, val, label in facts:
        fo["total"] += 1
        idn = ident.get(K, {}).get("number")
        home = [n for n in lotpub if K in N[n][0] and fact_in(kind, val, N[n][0][K])]
        if not home:
            fo["unsourced"] += 1
            if len([e for e in fo["examples"] if "unsourced" in e]) < 3: fo["examples"].append({"unsourced": label, "lot": K, "value": str(val)[:60]})
            continue
        if idn is None or isinstance(idn, list):
            fo["ambiguous_identity"] += 1; continue
        good = [n for n in home if one(N[n][0][K]["nno"]) in (idn, None)]
        if good: fo["ok"] += 1
        else:
            fo["misattributed"] += 1
            fo["examples"].append({"MIS": label, "lot": K, "value": str(val)[:60], "from": home,
                                   "from_numbers": {n: N[n][0][K]["no"] for n in home}, "tender_lot_number": idn})
    # duplicate Tender lots: two served keys whose identity is the same printed number
    byno = {}
    for k, d in ident.items():
        if isinstance(d["number"], str): byno.setdefault(d["number"], []).append(k)
    dups = {x: ks for x, ks in byno.items() if len(ks) > 1}
    # lots printed by some notice but absent from the served identities
    printed = {x for n in lotpub for s in N[n][0].values() for x in s["nno"]}
    lost = sorted(printed - set(byno), key=lambda x: (len(x), x))
    real_dis = [d for d in dis if d["type"] != "unnumbered-title-differs"]
    if len(lotpub) <= 1: cls = "single_lot_notice"
    elif unnumbered and not real_dis: cls = "unnumbered"
    elif not dis: cls = "consistent"
    elif mis or fo["misattributed"]: cls = "disagree_harmful"
    else: cls = "disagree_harmless"
    return {"tender_id": tid, "versions": vn, "lot_publishing_notices": lotpub, "n_notices_with_lot_sections": len(lotpub),
            "maps": maps, "titles": titles, "unnumbered": unnumbered, "disagreements": dis, "tender_lots": ident,
            "duplicate_tender_lots": dups, "printed_lots_not_on_tender": lost, "results": rows,
            "results_total": len(rows), "results_unplaced": sum(1 for r in rows if r["served_lot"] is None),
            "results_misattributed": len(mis), "lot_facts": fo, "cls": cls}

g = json.load(open(ROOT + "/groups.json"))
items = [it for grp in g["groups"] if grp["key"] == "k5" for it in grp["items"]]
out = []
for it in items:
    o = measure(it["tender_id"]); o["can_notice_id"] = it["can_notice_id"]; o["profile"] = it["profile"]; o["year"] = it["year"]
    out.append(o)
json.dump(out, open(ROOT + "/measure_k5.json", "w"), indent=1, ensure_ascii=False)
for o in out:
    print(o["tender_id"], o["profile"], o["cls"], "lotpub", o["lot_publishing_notices"], "dis", len(o["disagreements"]),
          "res", o["results_total"], "unplaced", o["results_unplaced"], "mis", o["results_misattributed"],
          "facts", {k: v for k, v in o["lot_facts"].items() if k != "examples"}, "dups", o["duplicate_tender_lots"], "lost", o["printed_lots_not_on_tender"])
    for d in o["disagreements"]: print("    DIS", d)
    for r in o["results"]:
        if r["verdict"] not in ("ok",) or r.get("same_notice_mismatch"): print("    RES", r)
    for e in o["lot_facts"]["examples"]: print("    FACT", e)
    for k, d in o["tender_lots"].items():
        if not d["title_from"] or isinstance(d["number"], list) or d["number"] is None: print("    IDENT?", k, d)
