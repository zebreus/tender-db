import json, re, sys, unicodedata, difflib
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k3"
G = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/groups.json"
LOTK = ("Lot", "LotsGroup", "Part")
NOF = ("TED-LOT_NO", "TED-LOT_NUMBER")
TITF = ("TED-LOT_TITLE", "TED-TITLE", "TED-TITLE_CONTRACT", "TED-CONTRACT_TITLE")
def norm(x):
    x = x.strip()
    d = re.findall(r"\d+", x)
    if len(d) == 1:
        return str(int(d[0]))
    return re.sub(r"[^0-9a-z]", "", x.lower())
def ntit(s):
    if not s: return ""
    s = "".join(ch for ch in unicodedata.normalize("NFKD", s) if not unicodedata.combining(ch)).casefold()
    return "".join(ch for ch in s if ch.isalnum())
def tsim(a, b):
    a, b = ntit(a), ntit(b)
    if not a or not b: return None
    if a == b or a in b or b in a: return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()
def sk(k):
    m = re.match(r"^([A-Z]+)-(\d+)$", k or ""); return int(m.group(2)) if m else 0
def secmap(c, kinds):
    out = {}
    for s in c["sections"]:
        if s["kind"] in kinds:
            nos = [v["value"] for v in s["values"] if v["field_id"] in NOF]
            items = [v["value"] for v in s["values"] if v["field_id"] == "TED-ITEM"]
            tit = [v["value"] for v in s["values"] if v["field_id"] in TITF]
            out[s["section_id"]] = {"no": nos, "nno": [norm(x) for x in nos], "item": items, "title": tit[0] if tit else None}
    return out
items = [x for x in json.load(open(G))["groups"] if x["key"] == "k3"][0]["items"]
out = []
for it in items:
    tid = it["tender_id"]
    t = json.load(open(f"{C}/tender_{tid}.json"))
    notices = {}
    for v in sorted(t["versions"], key=lambda v: v["seq"]):
        n = v["caused_by_notice_id"]
        c = json.load(open(f"{C}/notice_{n}.json"))
        notices[n] = (secmap(c, LOTK), secmap(c, ("LotResult",)))
    lotpub = [(n, l) for n, (l, r) in notices.items() if l]
    dis = []
    for i in range(len(lotpub)):
        for j in range(i + 1, len(lotpub)):
            (na_, a), (nb_, b) = lotpub[i], lotpub[j]
            for k in sorted(set(a) & set(b), key=sk):
                if a[k]["nno"] and b[k]["nno"] and set(a[k]["nno"]) != set(b[k]["nno"]):
                    dis.append(["key", k, na_, a[k]["no"], nb_, b[k]["no"]])
                s = tsim(a[k]["title"], b[k]["title"])
                if s is not None and s < 0.8:
                    dis.append(["title", k, na_, a[k]["title"], nb_, b[k]["title"], round(s, 2)])
            ma = {x: k for k, s in a.items() for x in s["nno"]}
            mb = {x: k for k, s in b.items() for x in s["nno"]}
            for x in set(ma) & set(mb):
                if ma[x] != mb[x]:
                    dis.append(["num", x, na_, ma[x], nb_, mb[x]])
            if set(a) != set(b):
                dis.append(["keyset", na_, sorted(a, key=sk), nb_, sorted(b, key=sk)])
    unnumbered = [n for n, l in lotpub if any(not s["nno"] for s in l.values())]
    served = {l["lot_key"]: l["title"] for l in t["lot_details"]}
    # served lot title vs each lot-publishing notice's section title at that key
    lotsrc = {}
    lotbad = []
    for k, tt in served.items():
        srcs = []
        for n, l in lotpub:
            if k in l:
                s = tsim(tt, l[k]["title"])
                if s is not None and s >= 0.8: srcs.append(n)
                elif s is not None: lotbad.append([k, tt, n, l[k]["title"], round(s, 2)])
            else:
                lotbad.append([k, tt, n, "KEY-ABSENT"])
        lotsrc[k] = srcs
    # results
    res = []
    mis = []
    for r in t["lot_results"]:
        if r["notice_id"] not in notices:
            mis.append(["result-notice-not-in-versions", r["notice_id"], r["key"]]); continue
        lots, rs = notices[r["notice_id"]]
        sec = rs.get(r["key"])
        pno = sec["no"] if sec else None
        npno = sec["nno"] if sec else []
        own = None
        if len(npno) == 1:
            m = [k for k, s in lots.items() if npno[0] in s["nno"]]
            own = m[0] if len(m) == 1 else None
        # title check of the served lot vs the block's title
        ts = tsim(sec["title"] if sec else None, served.get(r["lot"])) if r["lot"] else None
        row = {"notice": r["notice_id"], "key": r["key"], "printed": pno, "item": sec["item"] if sec else None,
               "own_sec": own, "lot": r["lot"], "served_title": served.get(r["lot"]), "block_title": sec["title"] if sec else None,
               "title_sim": None if ts is None else round(ts, 2)}
        res.append(row)
        if r["lot"] is not None:
            if own is not None and r["lot"] != own:
                mis.append(["served!=own-section", row])
            elif own is None and ts is not None and ts < 0.5:
                mis.append(["no-own-section,title-mismatch", row])
            # cross-notice: the served Tender lot's identity (printed number at that key in other lot notices)
            for n, l in lotpub:
                if r["lot"] in l and len(npno) == 1 and l[r["lot"]]["nno"] and npno[0] not in l[r["lot"]]["nno"]:
                    mis.append(["served-key-is-other-number-in", n, r["lot"], l[r["lot"]]["no"], row])
    def compact(lots):
        ks = sorted(lots, key=sk)
        pairs = [(sk(k), lots[k]["no"][-1] if lots[k]["no"] else "-") for k in ks]
        if pairs and all(str(a) == norm(b) for a, b in pairs) and [a for a, _ in pairs] == list(range(1, len(pairs) + 1)):
            f = "LOT_NUMBER" if any(v for v in [1]) else ""
            return f"LOT-1..{len(pairs)}=no 1..{len(pairs)}"
        return ", ".join(f"LOT-{a}={b}" for a, b in pairs)
    maps = "; ".join(f"{n}: {compact(l)}" for n, l in lotpub)
    o = {"tender_id": tid, "can": it["can_notice_id"], "profile": it["profile"], "versions": list(notices), "notices_with_lots": len(lotpub),
         "lotpub": [n for n, _ in lotpub], "maps": maps, "dis": dis, "unnumbered_in": unnumbered, "served_lots": len(served),
         "lot_src": {k: v for k, v in lotsrc.items()}, "lotbad": lotbad, "results_total": len(t["lot_results"]),
         "results_null": sum(1 for r in t["lot_results"] if r["lot"] is None), "mis": mis, "results": res}
    out.append(o)
json.dump(out, open("/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k3/k3_measure_raw.json", "w"), indent=1, ensure_ascii=False)
for o in out:
    print(o["tender_id"], o["profile"], "vers", o["versions"], "lotpub", o["lotpub"], "| maps:", o["maps"])
    print("    served_lots", o["served_lots"], "results", o["results_total"], "null", o["results_null"], "unnumbered_in", o["unnumbered_in"])
    for d in o["dis"]: print("    DIS", d)
    for d in o["lotbad"]: print("    LOTBAD", d)
    for m in o["mis"]: print("    MIS", m)
    for r in o["results"]:
        if r["title_sim"] is not None and r["title_sim"] < 0.8: print("    LOWSIM", r)
