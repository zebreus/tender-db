import json, sys, re
FACTS = __import__("os").environ.get("FACTS") == "1"
C = "/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k3"
def sk(s):
    m = re.match(r"^([A-Z]+)-(\d+)$", s or "")
    return (m.group(1), int(m.group(2))) if m else (s or "", 0)
def vals(s, fids):
    out = []
    for v in s["values"]:
        if v["field_id"] in fids:
            out.append((v["field_id"].replace("TED-", ""), v.get("value", v.get("code"))))
    return out
NUMF = ("TED-ITEM", "TED-LOT_NO", "TED-LOT_NUMBER", "TED-CONTRACT_NO", "TED-CONTRACT_NUMBER")
TITF = ("TED-LOT_TITLE", "TED-TITLE", "TED-TITLE_CONTRACT", "TED-CONTRACT_TITLE")
def tdump(tid, full=False):
    t = json.load(open(f"{C}/tender_{tid}.json"))
    print("=" * 100)
    print("TENDER", tid, "ver", t["version"], (t["title"] or "")[:100])
    for l in sorted(t["lot_details"], key=lambda l: sk(l["lot_key"])):
        print("  servedlot", l["lot_key"], "v", l["version"], "|", (l["title"] or "")[:110])
    for r in sorted(t["lot_results"], key=lambda r: (r["notice_id"], sk(r["key"]))):
        print("  result", r["notice_id"], r["key"], "lot=", r["lot"], r["decision"], r["awarded"], [w["organization_name"][:30] for w in r["winners"]][:2])
    for k in (("amounts","classifications","dates","texts","parties") if FACTS else ()):
        lf = [x for x in t[k] if x.get('lot')]
        for x in sorted(lf, key=lambda x: sk(x['lot'])):
            v = x.get('value') if k != 'parties' else (x.get('role'), x.get('organization_name'))
            if k == 'classifications': v = x.get('code')
            print("  fact", k, x['lot'], x.get('field', x.get('role')), str(v)[:90])
    for v in t["versions"]:
        n = v["caused_by_notice_id"]
        c = json.load(open(f"{C}/notice_{n}.json"))
        td = None
        for s in c["sections"]:
            for x in s["values"]:
                if x["field_id"] in ("TED-TD_DOCUMENT_TYPE",):
                    td = x.get("code")
        print(" NOTICE", n, "seq", v["seq"], v["published_at"], "td", td, "kinds", sorted({s["kind"] for s in c["sections"]}))
        for s in sorted(c["sections"], key=lambda s: sk(s["section_id"])):
            if s["kind"] in ("Lot", "LotsGroup", "Part", "LotResult"):
                print("   ", s["section_id"], s["kind"], "par", s["parent_section_id"], vals(s, NUMF), "|", [str(x[1])[:90] for x in vals(s, TITF)])
                if full:
                    print("        CPV", [x[1] for x in vals(s, ("TED-CPV_CODE",))], "DESC", [str(x[1])[:80] for x in vals(s, ("TED-SHORT_DESCR","TED-LOT_DESCRIPTION"))][:1])
for a in sys.argv[1:]:
    tdump(int(a.strip('+')), a.endswith('+'))
