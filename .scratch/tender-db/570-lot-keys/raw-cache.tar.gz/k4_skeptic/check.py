# k4 skeptic: independent re-derivation from live tender detail (k4_skeptic/live) + cached notice contents (cache_k4).
import json, re, sys, os, unicodedata
R = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
LIVE = R + '/k4_skeptic/live'
C = R + '/cache_k4'
NOF = ('TED-LOT_NO', 'TED-LOT_NUMBER')

def v(sec, fids):
    return [x.get('value', x.get('code')) for x in sec['values'] if x['field_id'] in fids]

def nn(x):
    s = re.sub(r'[^0-9a-z]', '', unicodedata.normalize('NFKD', str(x)).lower())
    return str(int(s)) if s.isdigit() else s

def notice(n):
    p = f'{LIVE}/notice_{n}.json'
    if not os.path.exists(p): p = f'{C}/notice_{n}.json'
    if not os.path.exists(p): return None
    return json.load(open(p))

def kn(k):
    m = re.search(r'(\d+)$', k or ''); return int(m.group(1)) if m else 0

for tid in sys.argv[1:]:
    t = json.load(open(f'{LIVE}/tender_{tid}.json'))
    print('=' * 110); print('TENDER', tid, (t.get('title') or '')[:90])
    vn = [x['caused_by_notice_id'] for x in t['versions']]
    rn = [r['notice_id'] for r in t['lot_results']]
    print(' versions:', [(x['caused_by_notice_id'], x['published_at']) for x in t['versions']], ' result notices not in versions:', sorted(set(rn) - set(vn)))
    maps = {}
    for n in dict.fromkeys(vn + rn):
        c = notice(n)
        if c is None: print('  NOTICE', n, 'MISSING'); continue
        nt = [s for s in c['sections'] if s['kind'] == 'Notice']
        kinds = sorted({s['kind'] for s in c['sections']})
        print(f'  NOTICE {n} kinds={kinds} pub={v(nt[0], ("TED-DATE_PUB",)) if nt else None}')
        m = {}
        for s in sorted([s for s in c['sections'] if s['kind'] == 'Lot'], key=lambda s: kn(s['section_id'])):
            nos = v(s, NOF); tit = v(s, ('TED-TITLE', 'TED-LOT_TITLE'))
            m[s['section_id']] = ([nn(x) for x in nos], tit[0] if tit else None)
            print(f'    Lot {s["section_id"]:7} ITEM={v(s, ("TED-ITEM",))} NO={nos} T={(tit[0] if tit else "")[:70]!r} cpv={v(s, ("TED-CPV_CODE",))[:3]}')
        for s in sorted([s for s in c['sections'] if s['kind'] == 'LotResult'], key=lambda s: kn(s['section_id'])):
            tit = v(s, ('TED-TITLE', 'TED-CONTRACT_TITLE'))
            print(f'    Res {s["section_id"]:7} ITEM={v(s, ("TED-ITEM",))} NO={v(s, NOF)} T={(tit[0] if tit else "")[:60]!r} unsucc={bool(v(s, ("TED-PROCUREMENT_UNSUCCESSFUL","TED-NO_AWARDED_CONTRACT")))}')
        for s in [s for s in c['sections'] if s['kind'] == 'Change']:
            print(f'    Chg {s["section_id"]:7} {[(x["field_id"], str(x.get("value", x.get("code")))[:40]) for x in s["values"]]}')
        if m: maps[n] = m
    # disagreement
    ns = list(maps)
    dis = []
    for i, a in enumerate(ns):
        for b in ns[i + 1:]:
            for k in set(maps[a]) & set(maps[b]):
                na, nb = maps[a][k][0], maps[b][k][0]
                if na and nb and set(na) != set(nb): dis.append((k, a, na, b, nb))
            ia = {x: k for k, (nos, _) in maps[a].items() for x in nos}
            ib = {x: k for k, (nos, _) in maps[b].items() for x in nos}
            for x in set(ia) & set(ib):
                if ia[x] != ib[x]: dis.append(('num ' + x, a, ia[x], b, ib[x]))
    print(' LOT-PUBLISHING NOTICES:', len(maps), ' DISAGREE:', dis)
    print(' SERVED lots:', [(l['lot_key'], (l['title'] or '')[:50]) for l in sorted(t['lot_details'], key=lambda l: kn(l['lot_key']))])
    # results: own section by printed number
    bad = 0
    for r in t['lot_results']:
        c = notice(r['notice_id'])
        sec = next((s for s in c['sections'] if s['kind'] == 'LotResult' and s['section_id'] == r['key']), None)
        pno = [nn(x) for x in v(sec, NOF)] if sec else []
        own = [k for k, (nos, _) in maps.get(r['notice_id'], {}).items() if set(pno) & set(nos)]
        # Tender-level identity of served lot: what number do the lot-publishing notices give that key?
        ident = {n: maps[n][r['lot']][0] for n in maps if r['lot'] in maps[n]} if r['lot'] else {}
        flag = ''
        if r['lot'] and pno and any(set(pno) != set(x) for x in ident.values() if x): flag = 'MISATTR?'; bad += 1
        print(f'   result {r["notice_id"]} {r["key"]} printed={pno} ownsec={own} -> served {r["lot"]} ident={ident} {r.get("decision")} {flag}')
    # lot facts
    facts = []
    for k in ('classifications', 'texts', 'dates', 'amounts', 'parties', 'contracts', 'bids'):
        for f in t.get(k) or []:
            if isinstance(f, dict) and f.get('lot'): facts.append((k, f))
    for l in t['lot_details']: facts.append(('lot_details', l))
    notfound = []
    for k, f in facts:
        key = f.get('lot') or f.get('lot_key')
        val = f.get('code') or f.get('value') or f.get('title') or f.get('organization_name')
        if val is None: continue
        hit = []
        for n, m in maps.items():
            c = notice(n)
            sec = next((s for s in c['sections'] if s['kind'] == 'Lot' and s['section_id'] == key), None)
            if sec and any(str(val)[:40] == str(x.get('value', x.get('code')))[:40] for x in sec['values']): hit.append(n)
            elif sec and isinstance(val, str) and k == 'dates' and any(str(val)[:10] == str(x.get('value'))[:10] for x in sec['values']): hit.append(n)
        if not hit: notfound.append((k, key, str(val)[:60]))
    print(f' LOT FACTS: {len(facts)}  not found in any notice section at the same key: {notfound[:12]}{" ..." if len(notfound) > 12 else ""} ({len(notfound)})')
    print(' results flagged:', bad, 'of', len(t['lot_results']))
