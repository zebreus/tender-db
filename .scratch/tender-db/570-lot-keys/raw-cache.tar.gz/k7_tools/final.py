# k7 final: hand-checked classes over cache_k7/measure_k7.auto.json; writes ../measure_k7.json and prints compact maps
import json, re
ROOT = "/home/user/tender-db/.scratch/tender-db/570-lot-keys"
auto = json.load(open(ROOT + "/cache_k7/measure_k7.auto.json"))
def kn(k): return int(re.search(r"(\d+)$", k).group(1))
def compact(o):
    parts = []
    for n, m in o["maps"].items():
        ks = sorted(m, key=kn)
        ident = all(len(m[k]["no"]) == 1 and re.sub(r"^0+", "", m[k]["no"][0]) == str(kn(k)) for k in ks)
        if ident:
            parts.append(f"{n}: LOT-1..{len(ks)}=1..{len(ks)}" if ks == [f"LOT-{i}" for i in range(1, len(ks) + 1)] else f"{n}: " + ",".join(f"{k}={m[k]['no']}" for k in ks))
        else:
            parts.append(f"{n}: " + ", ".join(f"{k}={'/'.join(m[k]['no']) or '-'}" for k in ks))
    return "; ".join(parts)
hand = {
 6399916: {"cls": "consistent"},
 5317587: {"cls": "disagree_harmful", "lot_facts_misattributed": 7},
 5540787: {"cls": "disagree_harmless"},
}
out = []
for o in auto:
    h = hand.get(o["tender_id"], {})
    out.append({"tender_id": o["tender_id"], "cls": h.get("cls", o["cls_auto"]), "cls_auto": o["cls_auto"],
                "n_notices_with_lot_sections": o["n_notices_with_lot_sections"], "results_total": o["results_total"],
                "results_null": o["results_null"], "results_misattributed": o["results_misattributed"],
                "lot_facts_misattributed": h.get("lot_facts_misattributed", o["lot_facts"]["misattributed"]),
                "maps_compact": compact(o), "maps": o["maps"], "disagreements": o["disagreements"],
                "title_differences_same_key": o["title_differences_same_key"], "tender_lots": o["tender_lots"],
                "results": o["results"], "lot_facts": o["lot_facts"]})
json.dump(out, open(ROOT + "/measure_k7.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(Counter(x["cls"] for x in out), "results", sum(x["results_total"] for x in out), "null", sum(x["results_null"] for x in out),
      "mis", sum(x["results_misattributed"] for x in out), "facts_mis", sum(x["lot_facts_misattributed"] for x in out))
for x in out:
    print(x["tender_id"], x["cls"], x["n_notices_with_lot_sections"], x["results_total"], x["results_null"], x["results_misattributed"], x["lot_facts_misattributed"], "|", x["maps_compact"][:400])
