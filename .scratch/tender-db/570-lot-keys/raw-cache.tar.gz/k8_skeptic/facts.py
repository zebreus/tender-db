# For each served lot fact, find which notices' section at the same key carries the value; and which section of any notice (any key) carries it.
import json, sys, re
C='/home/user/tender-db/.scratch/tender-db/570-lot-keys/cache_k8'
L='/home/user/tender-db/.scratch/tender-db/570-lot-keys/k8_skeptic/live'
def norm(s): return re.sub(r'\s+',' ',str(s or '')).strip().lower()
tid=sys.argv[1]
t=json.load(open(f'{L}/tender_{tid}.json'))
nids=list(dict.fromkeys([v['caused_by_notice_id'] for v in t['versions']]+[r['notice_id'] for r in t['lot_results']]))
secs={}
for n in nids:
    try: c=json.load(open(f'{C}/notice_{n}.json'))
    except FileNotFoundError: continue
    for s in c['sections']:
        if s['kind'] in ('Lot','LotResult'):
            secs[(n,s['kind'],s['section_id'])]=s
def has(s, val):
    v=norm(val)
    for x in s['values']:
        for f in ('value','code'):
            if f in x and x[f] is not None and (norm(x[f])==v or (len(v)>20 and v[:60] in norm(x[f]))): return True
    return False
def no(s):
    return [x.get('value') for x in s['values'] if x['field_id'] in ('TED-LOT_NO','TED-LOT_NUMBER')]
bad=0; tot=0
for k in ('amounts','bids','contracts','dates','parties','classifications','texts'):
    for x in t[k]:
        if not isinstance(x,dict) or not x.get('lot'): continue
        tot+=1
        val = x.get('value') if k=='texts' else x.get('code') if k=='classifications' else x.get('mention_name') or x.get('organization_name') if k=='parties' else None
        if val is None:
            # amounts/dates/etc: try cents or date
            val = x.get('cents') or (x.get('amount') or {}).get('cents') or x.get('date') or x.get('value')
        same=[f'{n}:{kd}:{sid}' for (n,kd,sid),s in secs.items() if sid==x['lot'] and kd=='Lot' and has(s,val)]
        anyk=[f'{n}:{kd}:{sid}(NO={no(s)})' for (n,kd,sid),s in secs.items() if has(s,val)]
        flag='' if same else '  <-- not at same key'
        if not same: bad+=1
        print(k, x['lot'], str(val)[:50], '| same-key:', same, '| any:', anyk[:6], flag)
print('total',tot,'not-same-key',bad)
