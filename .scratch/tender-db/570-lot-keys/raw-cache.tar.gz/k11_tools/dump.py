# k11 dump for issue 570: per tender, every version notice's lot/result sections (key, ITEM, LOT_NO/LOT_NUMBER, title)
# and the served lots / lot_results / per-lot facts.
import json, os, re, sys
ROOT = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
CACHE = ROOT + '/cache_k11'
g = json.load(open(ROOT + '/groups.json'))
items = [it for grp in g['groups'] if grp['key'] == "k11" for it in grp['items']]
def kn(k):
    m = re.search(r'(\d+)$', k or ''); return int(m.group(1)) if m else 0
def vals(s):
    out = {}
    for v in s['values']:
        x = v.get('value', v.get('code'))
        out.setdefault(v['field_id'], []).append(x)
    return out
def first(d, *ks):
    for k in ks:
        if d.get(k): return d[k][0]
    return None
def sec_summary(s):
    d = vals(s)
    return dict(key=s['section_id'], parent=s.get('parent_section_id'), item=first(d, 'TED-ITEM'),
                lot_no=first(d, 'TED-LOT_NO'), lot_number=first(d, 'TED-LOT_NUMBER'),
                title=first(d, 'TED-TITLE', 'TED-LOT_TITLE', 'TED-TITLE_CONTRACT'),
                contract_no=first(d, 'TED-CONTRACT_NO'), fields=sorted(d))
only = sys.argv[1:]
for it in items:
    tid = it['tender_id']
    if only and str(tid) not in only: continue
    p = f'{CACHE}/tender_{tid}.json'
    if not os.path.exists(p): print('MISSING', tid); continue
    t = json.load(open(p))
    print('=' * 100)
    print('TENDER', tid, it['profile'], it['year'], 'CAN', it['can_notice_id'], 'title:', t.get('title'))
    nids = [v['caused_by_notice_id'] for v in t['versions']]
    for v in t['versions']:
        print('  version', v['seq'], v['caused_by_notice_id'], v['published_at'], v['publication_id'])
    extra = [r.get('notice_id') for r in t['lot_results'] if r.get('notice_id') not in nids]
    for nid in list(dict.fromkeys(nids + extra + [it['can_notice_id']])):
        np_ = f'{CACHE}/notice_{nid}.json'
        if not os.path.exists(np_): print('  NOTICE MISSING', nid); continue
        n = json.load(open(np_))
        kinds = {}
        for s in n['sections']: kinds[s['kind']] = kinds.get(s['kind'], 0) + 1
        nsec = [s for s in n['sections'] if s['kind'] == 'Notice']
        form = first(vals(nsec[0]), 'TED-FORM', 'TED-TD_DOCUMENT_TYPE') if nsec else None
        print(f'  NOTICE {nid} kinds={kinds} form={form}')
        for kind in ('Lot', 'LotResult', 'Change'):
            ss = sorted([s for s in n['sections'] if s['kind'] == kind], key=lambda s: kn(s['section_id']))
            for s in ss:
                x = sec_summary(s)
                if kind == 'Change':
                    print(f'    Change {x["key"]}: ' + json.dumps({k: v for k, v in vals(s).items()}, ensure_ascii=False)[:400])
                    continue
                print(f'    {kind:9} {x["key"]:7} item={x["item"]!s:5} LOT_NO={x["lot_no"]!s:6} LOT_NUMBER={x["lot_number"]!s:6} cno={x["contract_no"]!s:8} title={str(x["title"])[:90]!r}')
    print('  SERVED lots:')
    for l in sorted(t['lot_details'], key=lambda l: kn(l['lot_key'])):
        print(f'    {l["lot_key"]:7} v{l["version"]} value={l.get("value")} title={str(l.get("title"))[:90]!r}')
    print('  SERVED lot_results:')
    for r in sorted(t['lot_results'], key=lambda r: (r.get('notice_id') or 0, kn(r['key']))):
        w = ','.join((x.get('organization_name') or '')[:30] for x in r.get('winners') or [])
        print(f'    {r["key"]:7} lot={r.get("lot")!s:7} notice={r.get("notice_id")} dec={r.get("decision")} aw={r.get("awarded")} win={w}')
    print('  SERVED lot facts:')
    for kind in ('classifications', 'dates', 'amounts', 'texts', 'parties'):
        for f in t.get(kind) or []:
            if f.get('lot'):
                v = f.get('value', f.get('code'))
                if kind == 'parties': v = (f.get('role'), f.get('organization_name'))
                print(f'    {kind:15} {f["lot"]:7} {f.get("field", f.get("scheme"))} {str(v)[:100]}')
