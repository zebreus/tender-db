# k11 measurer for issue 570.
# Per tender: each lot-publishing notice's map section key -> printed number (LOT_NO / LOT_NUMBER) and title;
# disagreements on shared keys; the served lot's identity (which notice's section title the served lot_details title equals);
# served lot_results whose block's own-notice printed number differs from the identity's printed number;
# served lot facts (classifications / dates / amounts / texts / lot_details value) sourced only from a notice section
# whose printed number differs from the identity's printed number.
import json, os, re, sys, unicodedata
ROOT = '/home/user/tender-db/.scratch/tender-db/570-lot-keys'
CACHE = ROOT + '/cache_k11'
g = json.load(open(ROOT + '/groups.json'))
items = [it for grp in g['groups'] if grp['key'] == "k11" for it in grp['items']]
def kn(k):
    m = re.search(r'(\d+)$', k or ''); return int(m.group(1)) if m else 0
def norm(s):
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode().casefold()
    return re.sub(r'[^0-9a-z]+', ' ', s).strip()
def normno(s):
    if s is None: return None
    s = norm(s)
    s = re.sub(r'^(lot|lote|los|lotto|grupa|part|zad)\s*', '', s)
    return ' '.join(str(int(t)) if t.isdigit() else t for t in s.split())
def vals(s):
    out = {}
    for v in s['values']:
        x = v.get('value', v.get('code'))
        if x is None and v.get('cents') is not None: x = 'CENTS:%d' % v['cents']
        out.setdefault(v['field_id'], []).append(x)
    return out
def first(d, *ks):
    for k in ks:
        if d.get(k): return d[k][0]
    return None
def sec_info(s):
    d = vals(s)
    no = first(d, 'TED-LOT_NO', 'TED-LOT_NUMBER')
    return dict(key=s['section_id'], item=first(d, 'TED-ITEM'), no=no, nno=normno(no),
                title=first(d, 'TED-TITLE', 'TED-LOT_TITLE', 'TED-TITLE_CONTRACT'), vals=d)
def fact_candidates(kind, f):
    v = f.get('value', f.get('code'))
    if kind == 'amounts' and isinstance(v, dict):
        c = v.get('cents')
        if c is None: return set()
        return {norm('CENTS:%d' % c)}
    if kind == 'dates':
        return {norm(str(v)[:10])}
    return {norm(v)}
def sec_has(sec, cands):
    for fid, xs in sec['vals'].items():
        for x in xs:
            nx = norm(x) if x is not None else ''
            if kind_date(fid): nx = norm(str(x)[:10])
            if nx in cands: return True
            try:
                if norm(float(x)) in cands: return True
            except Exception: pass
    return False
def kind_date(fid): return 'DATE' in fid
only = sys.argv[1:]
out = []
for it in items:
    tid = it['tender_id']
    if only and str(tid) not in only: continue
    t = json.load(open(f'{CACHE}/tender_{tid}.json'))
    nids = [v['caused_by_notice_id'] for v in t['versions']]
    extra = [r.get('notice_id') for r in t['lot_results'] if r.get('notice_id') not in nids]
    notices = {}
    for nid in dict.fromkeys(nids + extra):
        n = json.load(open(f'{CACHE}/notice_{nid}.json'))
        lots = {s['section_id']: sec_info(s) for s in n['sections'] if s['kind'] == 'Lot'}
        res = {s['section_id']: sec_info(s) for s in n['sections'] if s['kind'] == 'LotResult'}
        notices[nid] = dict(lots=lots, res=res)
    lotpub = [nid for nid in notices if notices[nid]['lots']]
    # maps
    maps = {nid: {k: (v['nno'], v['no'], v['title']) for k, v in notices[nid]['lots'].items()} for nid in lotpub}
    disagree = []
    keys = sorted({k for nid in lotpub for k in maps[nid]}, key=kn)
    for k in keys:
        have = [(nid, maps[nid][k]) for nid in lotpub if k in maps[nid]]
        nos = {h[1][0] for h in have}
        if len(have) > 1 and len(nos) > 1:
            disagree.append((k, [(nid, m[1], (m[2] or '')[:60]) for nid, m in have]))
    # same number at different keys
    numkey = {}
    for nid in lotpub:
        for k, m in maps[nid].items():
            if m[0] is not None: numkey.setdefault(m[0], set()).add(k)
    samenum_diffkey = {n: sorted(ks, key=kn) for n, ks in numkey.items() if len(ks) > 1}
    # served lot identity by title
    ident = {}
    for l in t['lot_details']:
        k = l['lot_key']; st = norm(l.get('title') or '')
        src = [nid for nid in lotpub if k in maps[nid] and norm(maps[nid][k][2] or '') == st]
        nnos = {maps[nid][k][0] for nid in src}
        ident[k] = dict(title=l.get('title'), src=src, nno=(nnos.pop() if len(nnos) == 1 else (None if not nnos else 'AMBIG')),
                        no=(maps[src[0]][k][1] if src else None))
    # results
    res_mis = []
    for r in t['lot_results']:
        nid = r.get('notice_id'); lot = r.get('lot')
        if lot is None: continue
        blk = notices.get(nid, {}).get('res', {}).get(r['key'])
        bno = blk['nno'] if blk else None
        idn = ident.get(lot, {}).get('nno')
        if bno is not None and idn not in (None, 'AMBIG') and bno != idn:
            res_mis.append((r['key'], nid, blk['no'], lot, ident[lot]['no'], (ident[lot]['title'] or '')[:50]))
    # facts
    fact_mis = []; nfacts = 0
    for kind in ('classifications', 'dates', 'amounts', 'texts'):
        for f in t.get(kind) or []:
            k = f.get('lot')
            if not k: continue
            nfacts += 1
            cands = fact_candidates(kind, f)
            if not cands: continue
            srcs = [nid for nid in lotpub if k in notices[nid]['lots'] and sec_has(notices[nid]['lots'][k], cands)]
            idn = ident.get(k, {}).get('nno')
            if not srcs:
                fact_mis.append(('UNSOURCED', kind, k, f.get('field'), str(f.get('value', f.get('code')))[:60])); continue
            good = [nid for nid in srcs if maps[nid][k][0] == idn or idn in (None, 'AMBIG')]
            if not good:
                fact_mis.append(('OTHERLOT', kind, k, f.get('field'), str(f.get('value', f.get('code')))[:60], srcs, [maps[n][k][1] for n in srcs]))
    for l in t['lot_details']:
        if l.get('value'):
            nfacts += 1
    rec = dict(tender_id=tid, versions=nids, lotpub=lotpub, nlots_served=len(t['lot_details']),
               maps={nid: {k: [m[1], (m[2] or '')[:70]] for k, m in sorted(maps[nid].items(), key=lambda x: kn(x[0]))} for nid in lotpub},
               disagree=disagree, samenum_diffkey=samenum_diffkey,
               ident={k: dict(no=v['no'], src=v['src'], title=(v['title'] or '')[:70]) for k, v in sorted(ident.items(), key=lambda x: kn(x[0]))},
               results_total=len(t['lot_results']), results_with_lot=sum(1 for r in t['lot_results'] if r.get('lot')),
               res_mis=res_mis, nfacts=nfacts, fact_mis=fact_mis)
    out.append(rec)
json.dump(out, open(ROOT + '/k11_tools/measure_k11.auto.json', 'w'), ensure_ascii=False, indent=1)
for rec in out:
    print('=' * 80)
    print(rec['tender_id'], 'lotpub', rec['lotpub'], 'served lots', rec['nlots_served'], 'results', rec['results_total'], 'with lot', rec['results_with_lot'], 'lot facts', rec['nfacts'])
    print('  disagree:', json.dumps(rec['disagree'], ensure_ascii=False)[:1500])
    print('  samenum_diffkey:', rec['samenum_diffkey'])
    print('  ident:', {k: (v['no'], v['src']) for k, v in rec['ident'].items()})
    print('  res_mis:', rec['res_mis'])
    print('  fact_mis:', len(rec['fact_mis']))
    for x in rec['fact_mis'][:40]: print('     ', x)
