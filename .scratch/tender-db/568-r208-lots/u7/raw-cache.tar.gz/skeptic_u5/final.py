#!/usr/bin/env python3
"""Skeptic u5 final: the measurer's u5 table, checked field by field against the independent rebuild
(table.py over a fresh fetch), with the skeptic's re-read notes and class changes applied."""
import importlib.util, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("table", os.path.join(HERE, "table.py"))
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)

meas = json.load(open(os.path.join(HERE, "..", "u5_result.json")))

# Independent rebuild
mine = {}
for tid in sorted({b["tender_id"] for b in meas["blocks"]}):
    _, lots, blocks = T.build(tid)
    for b in blocks:
        mine[(tid, b["result_key"])] = (b, lots)

CONFIRM = {
    (4514627, "RES-1"): "Skeptic re-read: confirmed multi_lot_contract. CONTRACT_TITLE 'lots no1, 2, 5, 6, 9, 10, 30, 31, 33, 34, 45, 46, 50, 51, 86, 133, 174' names 17 distinct lots of the 182 legal lots; these are lot numbers, not quantities (the other 23 blocks print the same 'lots no...' form, and each one's LOT_NUMBER is its first listed lot). One Mylan contract (CONTRACT_NUMBER 20111050140209, 255,310 EUR) now sits on LOT-1, the CN's only lot section (number 1, which stands for the whole 182-lot procedure). It is a 1-lot Tender, so G1 does not fire.",
    (5001424, "RES-1"): "Skeptic re-read: confirmed multi_lot_contract. The block has no title. It prints LOT_NUMBER six times (1, 2, 3, 4, 5, 6) under ONE award: one winner (Zaun & Sicherheit GmbH), CONTRACT_NUMBER 1, 1 offer, and one VALUE_COST of 229,778.91 EUR, which is also the CAN's only value. The rule keeps the first LOT_NUMBER, so the 6-lot award sits on LOT-1. title_lot_numbers stays [] because there is no title text. The multi-lot signal is the repeated LOT_NUMBER, which a title-only G3 would miss.",
    (4968281, "RES-1"): "Skeptic re-read: confirmed wrong_other. TITLE_CONTRACT '2 Solo-Niederflubusse ca. 15 m' is CN LOT-2's subject ('2 Solo-Busse ca. 15m 3-achsig'). CN LOT-1 ('1 Standard-Niederflurbus ca. 12m') was only the alternative if a single solo bus were bought. The CAN numbers its one award LOT_NUMBER 1 = ITEM 1 = CONTRACT_NO 1, a sequential counter, so lot 2's award sits on LOT-1. The '2' counts buses and is not a lot number. Not multi-lot: 2 solo buses is LOT-2's full scope, without LOT-1's 12 m bus. No value is printed.",
}

RANDOM = {
    (4579152, "RES-2"): "Skeptic random re-read: confirmed. 'Pakiet nr 2.' = CN LOT-2 'Pakiet nr 2'; LN 2. NEUCA. The awarded 60,879.63 is printed in EUR beside a PLN estimate of 69,051.20, a currency slip at the source, not a placement problem.",
    (4579152, "RES-7"): "Skeptic random re-read: confirmed. 'Pakiet nr 7.' = CN LOT-7 'Pakiet nr 7'; LN 7. Awarded 53,144.64 PLN against an estimate of 48,436.40 PLN; Bialmed.",
    (4817404, "RES-1"): "Skeptic random re-read: confirmed. 'RCT/O.' = CN LOT-1 'Polizza RCT/O.'; the initial estimate of 210,000 = CN LOT-1's text premium base (210 000,00 EUR); LN 1.",
    (4817404, "RES-3"): "Skeptic random re-read: confirmed. 'Infortuni Cumulativa.' = CN LOT-3 'Polizza Infortuni.'; the initial estimate of 6,000 = CN LOT-3's text premium base (6 000,00 EUR); LN 3.",
    (4904027, "RES-1"): "Skeptic random re-read: confirmed. Title = CN LOT-1 (bacs sur roues 'voie publique'); '31 RL 2013' is a contract reference (32 and 33 RL 2013 go on lots 2 and 3), not a lot number; LN 1. No value.",
    (5116934, "RES-2"): "Skeptic random re-read: confirmed. 'Brašna i tjestenine' = CN LOT-2 title; the initial estimate of 221,915.00 HRK = CN LOT-2 VALUE exactly; LN 2.",
    (8343228, "RES-10"): "Skeptic random re-read: confirmed. 'Pakiet 13' = CN LOT-13 (anaesthesia machine review); LN 13 while CONTRACT_NUMBER 10 is the counter; Eres Medical.",
    (8343228, "RES-20"): "Skeptic random re-read: confirmed. 'Pakiet 35' = CN LOT-35 (ultrasound, echocardiograph); LN 35; GE Medical Systems.",
    (8343228, "RES-21"): "Skeptic random re-read: confirmed. 'Pakiet 37' = CN LOT-37 (electrophysiology stimulator); LN 37; ADO-MED.",
    (5757708, "RES-3"): "Skeptic extra re-read: placement confirmed. Title = CN LOT-3 'Konteineris šaldytuvas-šaldiklis' (6 pcs); LN 3. Its value 3,789,000.00 EUR looks 10x too large: with 378,900.00, the three blocks sum to 1,174,717.00, the CAN global (printed 117,471,700.00). That is a value-scale slip at the source and does not make it a multi-lot award (all three blocks name one lot each).",
    (8281034, "RES-1"): "Skeptic extra re-read: confirmed. '5 Nr' counts turbines, not lots. The CAN's only value (210,985 GBP, a notice-level GLOBAL) falls in CN LOT-1's range (200k-275k), not LOT-2's (500k-720k), and below even LOT-1's LOW + LOT-2's LOW, so it is not a sum of both lots. lot_results carries no awarded value.",
    (8275759, "RES-1"): "Skeptic extra re-read: confirmed. All three blocks print CONTRACT_NUMBER 1 and the same UTE (Telefónica), but each names one lot, carries its own value, and its initial estimate = that lot's CN VALUE exactly (3,911,800.00). One lot per block, not a multi-lot block.",
    (5370408, "RES-1"): "Skeptic extra re-read: confirmed. 6 blocks = 3 lots x 2 co-winners (BAM, Hegeman), all with CONTRACT_NUMBER 1 and no values. Each block prints exactly one LOT_NUMBER, so no block carries several lots' value. LN 1 -> LOT-1.",
}

CHANGE = {
    (5364153, "RES-4"): dict(
        cls="wrong_other",
        why="SKEPTIC: single_right -> wrong_other. '3a Leki do uzytku zewnętrznego' is NOT just a second award of lot 3. Corrigendum 18188432 (2015/S 022-035220) split positions 31-35 off pakiet 3 into a separate lot: 'Pozycje od 31 do 35 z pakietu nr 3 wydzielono do osobnego pakietu nr 3a', with its own wadium (3: 180 PLN, 3a: 38 PLN). Lot 3a exists only in prose, with no lot section, so no Tender lot is its own. The CAN prints LN 3 (CONTRACT_NUMBER 4; the numbers shift by one after it, while LN keeps the real lot), so the rule puts lot 3a's award (Aqua-Med, 1,378.00 PLN, estimate 2,227.80) on LOT-3 beside lot 3's own award RES-3 (Urtica). It is one lot, not multi-lot. Same shape as 5267810 RES-7 'Pakiet 1A' in u4. A softer reading: LOT-3 as the CN first published it did cover positions 31-35, so this is its parent lot. title_lot_numbers [3] is the numeric part of the designator '3a'."),
}

out = []
mismatch = []
for b in meas["blocks"]:
    k = (b["tender_id"], b["result_key"])
    mb, lots = mine[k]
    # field checks
    if (mb["lot_numbers"] or [None])[0] != b["printed"]:
        mismatch.append((k, "printed", mb["lot_numbers"], b["printed"]))
    if mb["served_lot"] != b["served_lot"]:
        mismatch.append((k, "served_lot", mb["served_lot"], b["served_lot"]))
    if mb["awarded"] != b["awarded_cents"]:
        mismatch.append((k, "awarded", mb["awarded"], b["awarded_cents"]))
    if not b["title"].startswith(mb["title"][:60]):
        mismatch.append((k, "title", mb["title"][:80], b["title"][:80]))
    lot = next((l for l in lots.values() if l["key"] == mb["served_lot"]), None)
    lv = lot["value"][0][0] if lot and lot["value"] else None
    if lv != b["lot_value_cents"]:
        mismatch.append((k, "lot_value", lv, b["lot_value_cents"]))
    r = dict(b)
    r["title"] = r["title"][:300]
    tln = sorted(set(r["title_lot_numbers"]))
    r["title_lot_numbers"] = tln
    r["names_several"] = len(tln) >= 2
    r["printed_in_title"] = (int(r["printed"]) in tln) if r["printed"] and r["printed"].isdigit() else False
    if r["awarded_cents"] and r["lot_value_cents"]:
        r["ratio"] = round(r["awarded_cents"] / r["lot_value_cents"], 4)
    else:
        r["ratio"] = None
    if k in CHANGE:
        r.update(CHANGE[k])
    elif k in CONFIRM:
        r["why"] = CONFIRM[k]
    elif k in RANDOM:
        r["why"] = RANDOM[k]
    out.append(r)

res = dict(tenders_read=25, tenders_without_r208_blocks=[], blocks=out)
json.dump(res, open(os.path.join(HERE, "u5_skeptic_final.json"), "w"), ensure_ascii=False, indent=1)
print("mismatches:", mismatch)
from collections import Counter
print(len(out), Counter(x["cls"] for x in out))
for x in out:
    if x["cls"] != "single_right" or x["names_several"] or (x["ratio"] and (x["ratio"] >= 1.5 or x["ratio"] <= 0.25)):
        print(x["tender_id"], x["result_key"], x["cls"], x["title_lot_numbers"], x["ratio"])
