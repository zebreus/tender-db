#!/usr/bin/env python3
"""Skeptic u5: rebuild every R2.0.8 award block of the 25 tenders from the cache, independently.

For each tender: the CN lots (latest section per key: number, title, VALUE_COST, LOW/HIGH),
and every LotResult of a notice that has no Lot section of its own (the legacy CAN shape),
with all LOT_NUMBER values, title, CONTRACT_NUMBER, VALUE_COST, initial estimate, winners,
and the lot the served Tender put it on. Also: subset sums of CN lot values that equal a block's
awarded or initial-estimate value (2+ lots), and a regex pass over the title for lot designators.
"""
import itertools, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(HERE, "cache")


def load(name):
    fn = os.path.join(C, name)
    return json.load(open(fn)) if os.path.exists(fn) else None


def vals(sec, fid):
    return [v for v in sec["values"] if v["field_id"] == fid]


def text(sec, fid):
    return [str(v.get("value")) for v in vals(sec, fid)]


def cents(sec, fid):
    out = []
    for v in vals(sec, fid):
        if v.get("type") == "amount":
            out.append((v.get("cents"), v.get("currency")))
    return out


LOTWORD = re.compile(
    r"(?i)\b(lots?|los(?:e|es)?|lotes?|lotti|lotto|part(?:ie|ies|ij|ija)?s?|pakiet(?:y|ów)?|zadani[ae]|zadań|"
    r"części?|cz\.|częśc|обособен\w*\s+позици\w*|позиции|позиция|osa|osat|del|dio|dalis|dalys|daļa|"
    r"tétel\w*|rész\w*|loten|perceel|percelen|cast|časť|část\w*|partida\w*|sklop\w*|grupa|grupy|grupe)\b"
    r"\s*(?:n[°ºo.]*|nr\.?|no\.?|č\.?|№)?\s*([0-9][0-9 ,;/\-–andetiuyorazи&]*)")


def title_numbers(t):
    nums = []
    for m in LOTWORD.finditer(t or ""):
        seg = m.group(2)
        for a, b in re.findall(r"(\d+)\s*[-–]\s*(\d+)", seg):
            a, b = int(a), int(b)
            if 0 < b - a < 60:
                nums.extend(range(a, b + 1))
        nums.extend(int(x) for x in re.findall(r"\d+", seg))
    return sorted(set(nums))


def build(tid):
    t = load(f"v1_tenders_{tid}.json")
    nids = sorted({v["caused_by_notice_id"] for v in t.get("versions") or [] if v.get("caused_by_notice_id")} |
                  {r["notice_id"] for r in t.get("lot_results") or [] if r.get("notice_id")})
    cn_lots = {}  # key -> dict, latest wins
    notices = {}
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        notices[nid] = n
        if not n:
            continue
        for s in n["sections"]:
            if s["kind"] == "Lot":
                cn_lots[s["section_id"]] = dict(
                    notice=nid, key=s["section_id"],
                    number=(text(s, "TED-LOT_NO") or text(s, "TED-LOT_NUMBER") or [None])[0],
                    title=(text(s, "TED-LOT_TITLE") or [""])[0],
                    desc=(text(s, "TED-LOT_DESCRIPTION") or [""])[0],
                    value=cents(s, "TED-VALUE_COST"),
                    low=cents(s, "TED-LOW_VALUE"), high=cents(s, "TED-HIGH_VALUE"),
                    qty=(text(s, "TED-TOTAL_QUANTITY_OR_SCOPE") or [""])[0])
    served = {(r["notice_id"], r["key"]): r for r in t.get("lot_results") or []}
    blocks = []
    for nid, n in notices.items():
        if not n:
            continue
        if any(s["kind"] == "Lot" for s in n["sections"]):
            continue
        orgs = {s["section_id"]: (text(s, "TED-OFFICIALNAME") or [""])[0]
                for s in n["sections"] if s["kind"] == "Organization"}
        for s in n["sections"]:
            if s["kind"] != "LotResult":
                continue
            r = served.get((nid, s["section_id"]), {})
            title = (text(s, "TED-CONTRACT_TITLE") or text(s, "TED-TITLE_CONTRACT") or [""])[0]
            winners = [orgs.get(str(v.get("value")), v.get("value")) for v in s["values"]
                       if v["field_id"] in ("TED-ECONOMIC_OPERATOR_NAME_ADDRESS", "TED-AWARD_AND_CONTRACT_VALUE")]
            blocks.append(dict(
                tender_id=tid, can_notice_id=nid, result_key=s["section_id"],
                lot_numbers=text(s, "TED-LOT_NO") + text(s, "TED-LOT_NUMBER"),
                item=text(s, "TED-ITEM"),
                contract_no=text(s, "TED-CONTRACT_NUMBER") + text(s, "TED-CONTRACT_NO"),
                title=title, title_auto=title_numbers(title),
                value_cost=cents(s, "TED-VALUE_COST"),
                initial=cents(s, "TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.VALUE_COST"),
                winners=winners,
                served_lot=r.get("lot"), awarded=(r.get("awarded") or {}).get("cents"),
                awarded_cur=(r.get("awarded") or {}).get("currency")))
    return t, cn_lots, blocks


def subset_sums(target, lots):
    """CN lots (2+) whose VALUE_COST sums exactly to target."""
    pool = [(l["key"], l["value"][0][0]) for l in lots.values() if l["value"]]
    hits = []
    if not target or len(pool) < 2:
        return hits
    for k in range(2, min(len(pool), 6) + 1):
        for combo in itertools.combinations(pool, k):
            if sum(c for _, c in combo) == target:
                hits.append([key for key, _ in combo])
    return hits


if __name__ == "__main__":
    for a in sys.argv[1:]:
        tid = int(a)
        t, lots, blocks = build(tid)
        print(f"######## {tid}: {t.get('title')!r}  lots={len(lots)}")
        for l in lots.values():
            print(f"  CN {l['key']} no={l['number']!r} v={l['value']} lo={l['low']} hi={l['high']} t={l['title'][:120]!r} q={l['qty'][:80]!r}")
        for b in blocks:
            ss = subset_sums(b["awarded"], lots) + subset_sums((b["initial"] or [(None,)])[0][0], lots)
            print(f"  {b['result_key']:6} LN={b['lot_numbers']} item={b['item']} cno={b['contract_no']} -> {b['served_lot']} "
                  f"aw={b['awarded']} {b['awarded_cur']} vc={b['value_cost']} init={b['initial']} auto={b['title_auto']} "
                  f"ss={ss} w={b['winners']} t={b['title'][:200]!r}")
