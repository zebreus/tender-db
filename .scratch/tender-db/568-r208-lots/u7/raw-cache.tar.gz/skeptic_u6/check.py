#!/usr/bin/env python3
"""Cross-check the measurer's u6 blocks against a fresh fetch."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(HERE, "cache")
M = json.load(open(os.path.join(HERE, "..", "u6_result.json")))

def load(name):
    fn = os.path.join(C, name)
    return json.load(open(fn)) if os.path.exists(fn) else None

def fv(s, f):
    return [v for v in s["values"] if v["field_id"] == f]

mb = {(b["tender_id"], b["can_notice_id"], b["result_key"]): b for b in M["blocks"]}
seen = set()
tids = sorted({b["tender_id"] for b in M["blocks"]})
for tid in tids:
    t = load(f"v1_tenders_{tid}.json")
    lv = {l["lot_key"]: (l.get("value") or {}).get("cents") for l in t.get("lot_details") or []}
    for r in t.get("lot_results") or []:
        nid = r["notice_id"]
        n = load(f"v1_notices_{nid}_content.json")
        own_lots = [s for s in n["sections"] if s["kind"] == "Lot"]
        sec = [s for s in n["sections"] if s["kind"] == "LotResult" and s["section_id"] == r["key"]]
        key = (tid, nid, r["key"])
        if own_lots:
            if key in mb:
                print("MEASURED BUT NOTICE HAS OWN LOTS", key)
            continue
        if r["lot"] is None:
            if key in mb:
                print("MEASURED BUT NULL", key)
            continue
        seen.add(key)
        if key not in mb:
            print("MISSING FROM MEASURER", key, r["lot"])
            continue
        b = mb[key]
        s = sec[0] if sec else None
        ln = [v.get("value") for v in fv(s, "TED-LOT_NUMBER")] + [v.get("value") for v in fv(s, "TED-LOT_NO")]
        tt = (fv(s, "TED-CONTRACT_TITLE") or fv(s, "TED-TITLE_CONTRACT") or fv(s, "TED-TITLE") or [{}])[0].get("value") or ""
        aw = (r.get("awarded") or {}).get("cents")
        probs = []
        if b["served_lot"] != r["lot"]:
            probs.append(f"served {b['served_lot']} vs {r['lot']}")
        if b["printed"] != (ln[0] if ln else None):
            probs.append(f"printed {b['printed']} vs {ln}")
        if len(ln) > 1:
            probs.append(f"several LN {ln}")
        if b["title"] != tt[:300]:
            probs.append(f"title differs: {b['title'][:80]!r} vs {tt[:80]!r}")
        if b["awarded_cents"] != aw:
            probs.append(f"awarded {b['awarded_cents']} vs {aw}")
        if b["lot_value_cents"] != lv.get(r["lot"]):
            probs.append(f"lot_value {b['lot_value_cents']} vs {lv.get(r['lot'])}")
        exp_ratio = round(aw / b["lot_value_cents"], 4) if aw and b["lot_value_cents"] else None
        if (b["ratio"] is None) != (exp_ratio is None) or (exp_ratio and abs(b["ratio"] - exp_ratio) > 1e-3):
            probs.append(f"ratio {b['ratio']} vs {exp_ratio}")
        if probs:
            print(key, "; ".join(probs))
for k in mb:
    if k not in seen:
        print("MEASURER BLOCK NOT SEEN", k)
print("checked", len(seen), "of", len(mb))
