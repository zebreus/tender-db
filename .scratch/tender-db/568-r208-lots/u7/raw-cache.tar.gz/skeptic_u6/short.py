#!/usr/bin/env python3
"""Condense whys for the structured return (full whys stay in u6_skeptic_final.json)."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "u6_skeptic_final.json")))
T = {
 4489994: "Insurance-class title = CN lot title for its LN. One lot. Re-read: kept.",
 8271291: "Title and award fit CN lot LN; VALUE printed per CN lot. One lot. Re-read: kept.",
 5030818: "Title = CN lot description for its LN; 'Marché n° 2013-051' is a contract number. One lot. Re-read: kept.",
 5498027: "Title = CN lot description; tonnes are vehicle weights, tranches are not lots. One lot. Re-read: kept.",
 6332640: "Title = CN Zadanie description for its LN; litres are quantities. One lot. Re-read: kept.",
 4772662: "Title names the CN lot's sector; arrondissement/departement numbers are geography; award = the lot's own HIGH_VALUE. One lot. Re-read: kept.",
 5476961: "Title names 'Обособена позиция № k' = LN; '4 обособени позиции' is a count; INITIAL = CN lot VALUE. One lot. Re-read: kept.",
 4555894: "Title = CN lot title for its LN; award near its own INITIAL. One lot. Re-read: kept.",
 5506659: "Catalogue-brand title = CN lot title for its LN; award near its own INITIAL. One lot. Re-read: kept.",
 4505292: "Title = CN lot title; '2' counts vehicles. One lot. Re-read: kept.",
 8037800: "'Pakiet nr k' = CN 'Pakiet k' = LN = CONTRACT_NUMBER. One lot. Re-read: kept.",
 4903612: "Title = CN lot description for its LN. One lot. Re-read: kept.",
 4963067: "Title = CN LOT-1 title. One lot. Re-read: kept.",
 5106209: "Roman part number in the title = LN = CN lot k at the award version; several framework winners per lot each repeat the lot value. One lot. (Later 2016 F20 re-keys LOT-1 as lot XX: frozen key, outside this rule.) Re-read: kept.",
 5399590: "2015 CAN: 'Delaftale k' = LN = CN 18257899 lot k; no award value. (2019 notices later re-key LOT-1/LOT-2 titles: frozen key, outside this rule.) Re-read: kept.",
 4866521: "Title = CN lot description (LOT-1 hand tools / LOT-2 motorised); 'article 77' is a legal reference. One lot. Re-read: kept.",
 4495263: "Trade-package title = CN lot description for its LN. One lot. Re-read: kept.",
 5028924: "Title = CN lot title for its LN; 'IMC 068' is the framework reference. One lot. Re-read: kept.",
 5018140: "Title = CN LOT-2 title; '-2/13' suffix of KC-zp.272-463-2/13 denotes part 2, 'szt.' figures are quantities. RES-1 printed no LN and stays null. One lot. Re-read: kept.",
 5008329: "Title = CN lot description for its LN; counts, tonnes and m3 are quantities. One lot. Re-read: kept.",
 8313642: "2013 CAN: food-group title = CN 17421506 lot title for its LN. One lot. (2017 F03 later re-keys LOT-15 as lot 18: frozen key, outside this rule.) Re-read: kept.",
 5148795: "CN prints LOT-1 as no. 2 and LOT-2 as no. 1; LN resolves by printed number and the title agrees. One lot. Re-read: kept.",
 5123099: "LN 00k = CN no. k after normalisation; place name matches CN lot description. One lot. Re-read: kept.",
 4975428: "Title = CN lot title for its LN; '3' counts cylinders, 'P5' is a model. One lot. Re-read: kept.",
}
SPECIAL = {
 (5395010, "RES-1"): "Generic procedure title. RES-1 LOW 17,871.90 gross brackets CN LOT-1 (16,545.84 net); CAN GLOBAL 25,848.45 = 17,871.90 + 7,976.55, so values are per lot despite near-identical contract numbers. One lot. Re-read: kept.",
 (5395010, "RES-2"): "Generic procedure title. 7,976.55 gross fits CN LOT-2 laptop (7,024.45 net); ratio compares gross to net. Far below CN total 23,570.29. One lot. Re-read: kept.",
 (4975428, "RES-2"): "LN 9 but title is verbatim CN LOT-8's distinctive 'Supra 1000' curing-light title; CN LOT-9's own title is a verbatim copy of LOT-3's (awarded by RES-4). Tried the refutation (LN right, title copied): 155.60 EUR with 4 offers fits curing-light parts, while every dental-unit-parts lot drew 1 offer and 2,201-7,708 EUR. No block awards LOT-8. One lot, most likely LOT-8 with a typo in the LN, now on LOT-9. Re-read: kept wrong_other.",
 (8037800, "RES-1"): "'Pakiet nr 1' = LN = CONTRACT_NUMBER 1. Award 1,274,700 is 5.36x its own INITIAL 237,799.34. An exhaustive subset-sum over the other lots' estimates and awards finds no exact match (the near misses all include lot 1 itself). Lots 2-8 each have their own block near their own estimate. The CAN GLOBAL 1,351,015.22 = the sum of the 8 estimates. Not multi-lot, likely a typo in the value. One lot. Re-read: kept.",
 (8271291, "RES-2"): "Title = CN LOT-2's four machines (no truck); award 694,600 = 0.98 of LOT-2 VALUE 706,000; the INITIAL field repeats the procedure total 825,900. One lot. Re-read: kept.",
 (5148795, "RES-1"): "Title = CN lot no. 4. The INITIAL 348,963.36 on every 17866982 block = the sum of the four awards (procedure total), and each award is distinct. One lot. Re-read: kept.",
}
for b in d["blocks"]:
    k = (b["tender_id"], b["result_key"])
    if b["tender_id"] == 5148795 and b["can_notice_id"] != 17866982:
        k = None
    b["why"] = SPECIAL.get(k) or T[b["tender_id"]]
json.dump(d, open(os.path.join(HERE, "u6_skeptic_final.short.json"), "w"), ensure_ascii=False, separators=(",", ":"))
print(len(json.dumps(d, ensure_ascii=False, separators=(",", ":"))))
