#!/usr/bin/env python3
"""Compact per-tender view: CN lot sections (number, title, value) and CAN award blocks."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(HERE, "cache")

def load(name):
    fn = os.path.join(C, name)
    return json.load(open(fn)) if os.path.exists(fn) else None

def vals(s, f):
    return [v for v in s["values"] if v["field_id"] == f]

def first(s, f):
    x = vals(s, f)
    if not x:
        return None
    v = x[0]
    if v.get("type") == "amount":
        return f"{v.get('cents')}c {v.get('currency')}"
    return v.get("value") if not isinstance(v.get("value"), (dict, list)) else json.dumps(v.get("value"), ensure_ascii=False)

def show(tid, ml=220):
    t = load(f"v1_tenders_{tid}.json")
    print(f"######## {tid}: {(t.get('title') or '')[:200]}")
    for l in t.get("lot_details") or []:
        print(f"  lot {l['lot_key']}: {(l.get('title') or '')[:ml]!r} v={(l.get('value') or {}).get('cents')}")
    for r in t.get("lot_results") or []:
        w = [x.get("organization_name") for x in r.get("winners") or []]
        print(f"  res {r['notice_id']} {r['key']} -> {r['lot']} aw={(r.get('awarded') or {}).get('cents')} {w}")
    nids = sorted({v["caused_by_notice_id"] for v in t.get("versions") or [] if v.get("caused_by_notice_id")})
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        if not n:
            print(f"  -- {nid} MISSING"); continue
        ns = [s for s in n["sections"] if s["kind"] == "Notice"]
        form = first(ns[0], "TED-FORM") if ns else None
        dt = first(ns[0], "TED-TD_DOCUMENT_TYPE") if ns else None
        print(f"  ---- notice {nid} form={form} doctype={dt}")
        for s in n["sections"]:
            k = s["kind"]
            if k == "Lot":
                print(f"   L {s['section_id']} no={first(s,'TED-LOT_NO')} num={first(s,'TED-LOT_NUMBER')} item={first(s,'TED-ITEM')} t={str(first(s,'TED-LOT_TITLE') or first(s,'TED-LOT_DESCRIPTION') or '')[:ml]!r} V={first(s,'TED-VALUE_COST') or first(s,'TED-VALUE')} LO={first(s,'TED-LOW_VALUE')} HI={first(s,'TED-HIGH_VALUE')}")
            elif k == "LotResult":
                print(f"   R {s['section_id']} LN={[v.get('value') for v in vals(s,'TED-LOT_NUMBER')]} LNO={[v.get('value') for v in vals(s,'TED-LOT_NO')]} CN={first(s,'TED-CONTRACT_NUMBER') or first(s,'TED-CONTRACT_NO')} T={str(first(s,'TED-CONTRACT_TITLE') or first(s,'TED-TITLE_CONTRACT') or first(s,'TED-TITLE') or '')[:ml]!r} V={first(s,'TED-VALUE_COST')} INIT={first(s,'TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.VALUE_COST')} LO={first(s,'TED-LOW_VALUE')} HI={first(s,'TED-HIGH_VALUE')} OFF={first(s,'TED-OFFERS_RECEIVED_NUMBER')}")

if __name__ == "__main__":
    ml = 220
    a = sys.argv[1:]
    if a and a[0].startswith("--max="):
        ml = int(a[0][6:]); a = a[1:]
    for x in a:
        show(int(x), ml)
