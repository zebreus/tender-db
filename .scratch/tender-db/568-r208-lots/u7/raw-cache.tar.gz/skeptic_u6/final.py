#!/usr/bin/env python3
"""Skeptic u6 final: measurer blocks with skeptic notes (no class changed)."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
M = json.load(open(os.path.join(HERE, "..", "u6_result.json")))

NOTES = {
    (4975428, 18326140, "RES-2"): "Skeptic re-read: kept wrong_other. I tried the opposite reading (LN 9 is right and the CAN copied lot 8's title). It does not hold. CN LOT-9's own title is a verbatim copy of LOT-3's, which RES-4 already awards. 155.60 EUR with 4 offers fits curing-light parts, while every dental-unit-parts lot (2, 3, 4, 5) drew 1 offer and 2,201-7,708 EUR. Most likely lot 8 with a typo in the LN.",
    (8037800, 19682407, "RES-1"): "Skeptic re-read: kept. I ran an exhaustive subset-sum over the other lots' initial estimates and awards: none equals 1,274,700. The near misses (within 0.2 %) all include lot 1's own estimate. Lots 2-8 each have their own block, near their own estimate. The CAN's GLOBAL 1,351,015.22 is the sum of all 8 estimates. So this is not a multi-lot award. Most likely a typo in the value.",
    (8271291, 12396371, "RES-2"): "Skeptic re-read: kept. The INITIAL field repeats the procedure total (825,900 = CN GLOBAL). The award, 694,600, is 0.98 of CN LOT-2 (706,000) and far from LOT-1 + LOT-2. The title lists LOT-2's four machines and not LOT-1's truck.",
    (5395010, 18390541, "RES-1"): "Skeptic re-read: kept. RES-1 and RES-2 share a winner and near-identical contract numbers (ZP/42/004/D15 vs D/15), but the CAN's GLOBAL 25,848.45 = 17,871.90 (RES-1 LOW) + 7,976.55 (RES-2). So the value is split per lot, and RES-1 is not the whole procedure.",
    (5395010, 18390541, "RES-2"): "Skeptic re-read: kept. The GLOBAL total splits into a per-lot value for each block (see RES-1). 7,976.55 is far below the CN total of 23,570.29 net.",
    (5148795, 17866982, "RES-1"): "Skeptic re-read: kept. The INITIAL 348,963.36 printed on every block of 17866982 equals the sum of the four awards, i.e. the procedure total. Each block's own award is distinct, and its title names one area.",
}
SAMPLE = {(5148795, 17934014, "RES-2"), (5106209, 17818582, "RES-34"), (8271291, 12396371, "RES-1"),
          (5506659, 18663866, "RES-24"), (5506659, 18663866, "RES-26"), (8313642, 17513951, "RES-10"),
          (5506659, 18663866, "RES-2"), (6332640, 20240501, "RES-2"), (5106209, 17818582, "RES-38"),
          (5106209, 17818582, "RES-47")}
out = []
for b in M["blocks"]:
    k = (b["tender_id"], b["can_notice_id"], b["result_key"])
    b = dict(b)
    if k in NOTES:
        b["why"] = (b.get("why") or "") + " | " + NOTES[k]
    elif k in SAMPLE:
        b["why"] = (b.get("why") or "") + " | Skeptic re-read (random sample): confirmed. The fresh fetch matches the LN, the CN lot and the title."
    out.append(b)
res = {"tenders_read": 25, "tenders_without_r208_blocks": [], "blocks": out}
json.dump(res, open(os.path.join(HERE, "u6_skeptic_final.json"), "w"), ensure_ascii=False, indent=1)
from collections import Counter
print(len(out), Counter(b["cls"] for b in out), sum(1 for b in out if b["names_several"]))
