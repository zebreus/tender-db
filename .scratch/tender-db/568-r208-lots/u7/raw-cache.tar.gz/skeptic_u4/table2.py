#!/usr/bin/env python3
import json, os, sys, itertools
HERE = os.path.dirname(os.path.abspath(__file__)); C = os.path.join(HERE, "cache")
def load(n):
    fn = os.path.join(C, n); return json.load(open(fn)) if os.path.exists(fn) else None
def sv(s, fid):
    return [v.get("cents") if v.get("type") == "amount" else (v.get("value") if v.get("value") is not None else v.get("code")) for v in s["values"] if v["field_id"] == fid]
SKIP=("TED-TI_","TED-CPV","TED-ORIGINAL_CPV","TED-ECONOMIC_OPERATOR","TED-EXCLUDING","TED-INCLUDING","TED-NO_CONTRACT_LIKELY","TED-VAT_PRCT","TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.INCLUDING","TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.EXCLUDING","TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.VAT")
def main(tid, ml):
    t = load(f"v1_tenders_{tid}.json")
    nids = sorted({v["caused_by_notice_id"] for v in t.get("versions") or [] if v.get("caused_by_notice_id")} | {r["notice_id"] for r in t.get("lot_results") or [] if r.get("notice_id")})
    print(f"######## {tid} {t.get('title')!r} lots={len(t.get('lot_details') or [])} nids={nids}")
    cn = {}
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        if not n: print("  MISSING", nid); continue
        nl = [s for s in n["sections"] if s["kind"] == "Lot"]
        nr = [s for s in n["sections"] if s["kind"] == "LotResult"]
        notice = [s for s in n["sections"] if s["kind"] == "Notice"]
        nv = notice[0] if notice else None
        if nv:
            print(f"  -- {nid}: lots={len(nl)} results={len(nr)} TITLE={(sv(nv,'TED-TITLE_CONTRACT') or sv(nv,'TED-TITLE') or [''])[0]!s:.150} VAL={sv(nv,'TED-VALUE')[:6]} VALUE_COST={sv(nv,'TED-VALUE_COST')[:3]}")
        for s in nl:
            d = dict(nid=nid, ln=(sv(s,"TED-LOT_NUMBER") or sv(s,"TED-LOT_NO") or [None])[0], title=" | ".join(str(x) for x in sv(s,"TED-LOT_TITLE") + sv(s,"TED-TITLE") if x),
                     desc=" | ".join(str(x) for x in sv(s,"TED-LOT_DESCRIPTION") + sv(s,"TED-SHORT_DESCR") if x), val=(sv(s,"TED-VALUE_COST") or sv(s,"TED-VALUE") or sv(s,"TED-LOW_VALUE") or [None]), cur=None)
            cn.setdefault(s["section_id"], []).append(d)
    for k in sorted(cn, key=lambda k: (len(k), k)):
        d = cn[k][-1]
        print(f"   CN {k} ln={d['ln']} val={d['val']} T={d['title'][:ml]!r} D={d['desc'][:ml]!r}")
    res = {(r["notice_id"], r["key"]): r for r in t.get("lot_results") or []}
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        if not n: continue
        for s in n["sections"]:
            if s["kind"] != "LotResult": continue
            r = res.get((nid, s["section_id"])) or {}
            vals = [f"{v['field_id'].replace('TED-','')}={(v.get('cents') if v.get('type')=='amount' else (v.get('value') if v.get('value') is not None else v.get('code')))!s:.{ml}}" for v in s["values"] if not v["field_id"].startswith(SKIP)]
            print(f"  [{nid} {s['section_id']}] served={r.get('lot')} aw={(r.get('awarded') or {}).get('cents')} {(r.get('awarded') or {}).get('currency')} dec={r.get('decision')} W={[w.get('organization_name')[:60] for w in r.get('winners') or []]}")
            print("      " + " | ".join(vals))
if __name__ == "__main__":
    ml = 160; a = sys.argv[1:]
    if a and a[0].startswith("--max="): ml = int(a[0][6:]); a = a[1:]
    for x in a: main(int(x), ml)
