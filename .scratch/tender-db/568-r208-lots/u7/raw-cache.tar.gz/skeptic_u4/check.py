import json, os
M = json.load(open('../u4_result.json'))['blocks']
def load(n): return json.load(open(os.path.join('cache', n)))
def sv(s, f): return [v.get('cents') if v.get('type')=='amount' else (v.get('value') if v.get('value') is not None else v.get('code')) for v in s['values'] if v['field_id']==f]
mine = {}
tids = sorted({b['tender_id'] for b in M})
cnval = {}
for tid in tids:
    t = load(f'v1_tenders_{tid}.json')
    nids = sorted({v['caused_by_notice_id'] for v in t['versions'] if v.get('caused_by_notice_id')})
    secs = {}
    lotsec = {}
    for nid in nids:
        n = load(f'v1_notices_{nid}_content.json')
        for s in n['sections']:
            if s['kind']=='LotResult': secs[(nid, s['section_id'])] = s
            if s['kind']=='Lot' and nid < max(nids):
                lotsec.setdefault(s['section_id'], s)
    for r in t['lot_results']:
        if r['lot'] is None: continue
        s = secs.get((r['notice_id'], r['key']))
        ln = (sv(s,'TED-LOT_NUMBER') or sv(s,'TED-LOT_NO') or [None])[0] if s else None
        title = ' | '.join(str(x) for x in (sv(s,'TED-CONTRACT_TITLE')[:1] + sv(s,'TED-TITLE_CONTRACT')) if x) if s else None
        ls = lotsec.get(r['lot'])
        lv = (sv(ls,'TED-VALUE_COST') or sv(ls,'TED-VALUE') or [None])[0] if ls else None
        mine[(tid, r['notice_id'], r['key'])] = dict(printed=ln, served=r['lot'], aw=(r.get('awarded') or {}).get('cents'), title=title, lv=lv)
mk = {(b['tender_id'], b['can_notice_id'], b['result_key']): b for b in M}
print('mine', len(mine), 'measurer', len(mk))
print('missing in measurer', sorted(set(mine)-set(mk)))
print('extra in measurer', sorted(set(mk)-set(mine)))
for k in sorted(set(mine)&set(mk)):
    a, b = mine[k], mk[k]
    diffs = []
    if str(a['printed']) != b['printed']: diffs.append(('printed', a['printed'], b['printed']))
    if a['served'] != b['served_lot']: diffs.append(('served', a['served'], b['served_lot']))
    if a['aw'] != b['awarded_cents']: diffs.append(('aw', a['aw'], b['awarded_cents']))
    if (a['title'] or '')[:300] != b['title']: diffs.append(('title', (a['title'] or '')[:120], b['title'][:120]))
    if a['lv'] != b['lot_value_cents']: diffs.append(('lv', a['lv'], b['lot_value_cents']))
    if b['awarded_cents'] and b['lot_value_cents']:
        r = round(b['awarded_cents']/b['lot_value_cents'], 4)
        if abs(r - (b['ratio'] or 0)) > 0.0002: diffs.append(('ratio', r, b['ratio']))
    elif b['ratio'] is not None: diffs.append(('ratio-not-null', b['ratio']))
    if diffs: print(k, diffs)
