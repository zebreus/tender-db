import json, sys
def fmt(v):
    if v.get('type')=='amount': return f"{v.get('cents')}c {v.get('currency')}"
    return str(v.get('code') or v.get('value'))
SKIP=("TED-TI_","TED-CPV","TED-ORIGINAL_CPV")
ml=int(sys.argv[2]) if len(sys.argv)>2 else 300
n=json.load(open(f'cache/v1_notices_{sys.argv[1]}_content.json'))
for s in n['sections']:
    if s['kind'] in ('Organization','Notice'): continue
    vals=[f"{v['field_id'].replace('TED-','')}={fmt(v)[:ml]}" for v in s['values'] if not v['field_id'].startswith(SKIP)]
    print(s['kind'],s['section_id'],'<',s.get('parent_section_id'),'>',' | '.join(vals))
