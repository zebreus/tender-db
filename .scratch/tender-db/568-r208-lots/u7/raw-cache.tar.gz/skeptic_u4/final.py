import json, re
B = json.load(open('../u4_result.json'))['blocks']
W5051 = {1:4734,2:11163,3:190,4:1080,5:2147,6:399,7:15156,8:11360,9:1170,10:44,11:994,12:5081,13:2415,14:4975,15:2547,16:2978,17:3875,18:4873,19:8285,20:3176,21:2780,22:1760}
can = json.load(open('cache/v1_notices_17689000_content.json'))
est5051 = {}
for s in can['sections']:
    if s['kind'] == 'LotResult':
        est5051[s['section_id']] = [v['cents'] if v.get('cents') is not None else v.get('value') for v in s['values'] if v['field_id'] == 'TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.VALUE_COST'][0]
out = []
for b in B:
    b = dict(b)
    t, k = b['tender_id'], b['result_key']
    if t == 5051007:
        p = b['title_lot_numbers'][0]
        e = est5051[k] / 100
        if b['cls'] == 'wrong_other':
            eq = '=' if round(e*0.02) == W5051[p] else '~'
            b['why'] = (f"Confirmed: LN {b['printed']} = CONTRACT_NUMBER counter (pakiety 4, 20 unawarded); title pakiet {p}. "
                        f"Estimate {e:,.2f} x 2% {eq} CN wadium for pakiet {p} ({W5051[p]}), not pakiet {b['printed']} ({W5051[int(b['printed'])]}). Belongs on LOT-{p}; one lot.")
        else:
            b['why'] = f"Confirmed: title pakiet {p} = LN {b['printed']}; estimate x 2% = CN wadium for pakiet {p} ({W5051[p]} PLN). One lot."
    elif t == 5267810:
        if k == 'RES-3':
            b['why'] = ("SKEPTIC: class kept, reason corrected. LN 3 = CONTRACT_NUMBER 3 (counter); on LOT-3 (pakiet 3, Bisacodylum/Phenylbuthazonum), which its text 'Pakiet 1 poz. 8' does not name. "
                        "Its own lot is NOT simply LOT-1: pakiet 1 is awarded whole in RES-1 (Salus, 44,412.64 PLN) and corrigendum 17996722 moved original poz. 8 (Atorvastatinum) out of pakiet I; "
                        "most likely a typo for pakiet 10 poz. 8 (LOT-39 Dacarbazinum, the only pakiet-10 position without a block; winner Asclepios also won 10/1 and 10/6). Wrong either way; one lot.")
        elif k == 'RES-7':
            b['why'] = ("SKEPTIC: class kept, reason corrected. LN 7 = CONTRACT_NUMBER 7; on LOT-7 (pakiet 7). 'Pakiet 1A' is NOT a sub-part of LOT-1: corrigendum 17996722 created 'Pakiet I A' "
                        "(Atorvastatinum, Fluoxetinum, Carvedilolum, Doxazosinum) in prose only, with no lot section, so no Tender lot is its own; it should stay on the Tender (null). One lot.")
        elif k == 'RES-8':
            b['cls'] = 'wrong_other'
            b['why'] = ("SKEPTIC: unclear -> wrong_other. Bare 'Pakiet', LN 8 = CONTRACT_NUMBER 8 in a CAN whose LN is a contract counter (CONTRACT_NUMBER = LOT_NUMBER on all 32 blocks; 30 of 31 numbered titles name another lot). "
                        "Served LOT-8 = 'pakiet 8 poz. 1', which RES-9 claims by name with a different contract (estimate 19,800 vs 27,285 PLN, 2 vs 3 offers, bid range 20,412-20,477 vs 26,191-26,702). "
                        "So it is not LOT-8's award; its own lot (pakiet 3, 7 or an unnamed pakiet-8 position) cannot be read.")
        elif k == 'RES-1':
            b['why'] = "Confirmed: 'PAKIET 1' = CN 17979642 LOT-1 'pakiet 1'; winner text 'Pakiet 1 - 44 412,64 zl' = awarded. One lot."
        else:
            m = re.findall(r'instead of (LOT-\d+)', b['why'])
            tgt = m[0] if m else '?'
            sev = " Its 2 numbers = pakiet+poz. of ONE lot." if len(b['title_lot_numbers']) == 2 else ""
            b['why'] = (f"Confirmed: LN = CONTRACT_NUMBER counter; '{b['title']}' is CN {tgt}, not {b['served_lot']}. One lot, wrong lot." + sev)
    elif t == 8319667:
        b['why'] = f"Confirmed: no title; LN {b['printed']} = CN 'Czesc nr {b['printed']}' (LN has gaps, not a counter; value fits the subject). Rests on the number; one lot."
    elif t == 4484810:
        b['why'] = f"Confirmed: LN {b['printed']} -> CN LOT-{b['printed']}; RA-2 is a model. No 'Pirkimo objekto dalys' list here; the CAN's multi-lot contracts print that list and no LOT_NUMBER, and stay null. One lot."
    elif t == 4648835:
        b['why'] = f"Confirmed: title = CN 12506628 {b['served_lot']} description; one lot."
    else:
        NOTE = {8030352: "R1/R6 are cluster codes (R6 = perceel 2)", 4597624: "HLF 20/16 is a vehicle type", 4591166: "300/400/500 MHz are field strengths",
                4721348: "4 ans / 200 000 EUR / 1 an are terms and caps", 5457731: "VII = LOT_NUMBER 7 of CN LOT-1", 5491199: "6 vehicles / 9 seats are quantities; '0k' normalises",
                8359853: "'Biohazard II' is safety class II, not lot 2", 5409061: "block estimate = CN lot VALUE to the grosz", 4484810: "",
                5451989: "CN 18352252 LOT-1 prints LOT_NUMBER 1", 8303947: "multilingual title, first kept", 8345508: "CN VALUE per lot"}
        n = NOTE.get(t, "")
        r = f" ratio {b['ratio']}." if b['ratio'] is not None else ""
        b['why'] = f"Confirmed: title = CN lot under LN {b['printed']} ({b['served_lot']}); one lot." + (f" {n}." if n else "") + r
    out.append(b)
res = dict(tenders_read=25, tenders_without_r208_blocks=[], blocks=out)
json.dump(res, open('u4_skeptic_final.json', 'w'), ensure_ascii=False, indent=1)
json.dump(res, open('u4_skeptic_final.min.json', 'w'), ensure_ascii=False, separators=(',', ':'))
from collections import Counter
print(Counter(b['cls'] for b in out), len(out))
print(len(open('u4_skeptic_final.min.json').read()))
