#!/usr/bin/env python3
"""Compact dump of a tender: lots, lot_results, CN lot sections, CAN award blocks."""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(HERE, "cache")
SKIP = ("TED-TI_", "TED-LODGING", "TED-CPV", "TED-ORIGINAL_CPV", "TED-CRITERIA")


def load(name):
    fn = os.path.join(C, name)
    return json.load(open(fn)) if os.path.exists(fn) else None


def fmt(v):
    t = v.get("type")
    if t == "amount":
        return f"{v.get('cents')}c {v.get('currency')}"
    if t == "code":
        return v.get("code")
    if t == "classification":
        return v.get("code")
    val = v.get("value")
    if isinstance(val, (dict, list)):
        return json.dumps(val, ensure_ascii=False)
    return str(val)


def dump(tid, maxlen=400):
    t = load(f"v1_tenders_{tid}.json")
    print(f"######## TENDER {tid}: {t.get('title')}")
    lots = t.get("lot_details") or []
    for l in lots:
        print(f"  lot {l['lot_key']}: {l.get('title')!r} value={(l.get('value') or {}).get('cents')}")
    for r in t.get("lot_results") or []:
        w = [x.get("organization_name") for x in r.get("winners") or []]
        print(f"  res {r['key']} lot={r['lot']} notice={r['notice_id']} awarded={(r.get('awarded') or {}).get('cents')} dec={r.get('decision')} winners={w}")
    nids = sorted({v["caused_by_notice_id"] for v in t.get("versions") or [] if v.get("caused_by_notice_id")} |
                  {r["notice_id"] for r in t.get("lot_results") or [] if r.get("notice_id")})
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        if not n:
            print(f"  -- notice {nid}: MISSING")
            continue
        orgs = {}
        for s in n["sections"]:
            if s["kind"] == "Organization":
                for v in s["values"]:
                    if v["field_id"] == "TED-OFFICIALNAME":
                        orgs[s["section_id"]] = v.get("value")
        print(f"  ---- notice {nid}")
        for s in n["sections"]:
            if s["kind"] == "Organization":
                continue
            if s["kind"] == "Notice":
                keep = []
                for v in s["values"]:
                    f = v["field_id"]
                    if f in ("TED-TITLE_CONTRACT", "TED-VALUE", "TED-VALUE_COST", "TED-FORM", "TED-TD_DOCUMENT_TYPE",
                             "TED-SHORT_CONTRACT_DESCRIPTION", "TED-DIV_INTO_LOT_YES", "TED-LOT_DIVISION",
                             "TED-NO_DOC_OJS", "TED-LOW", "TED-HIGH", "TED-CONTRACT_NO", "TED-LOT_NUMBER",
                             "TED-CONTRACT_TITLE", "TED-TITLE") or f.startswith("TED-VAL"):
                        keep.append(f"{f}={fmt(v)[:maxlen]}")
                print(f"   [Notice] " + "\n            ".join(keep))
                continue
            vals = []
            for v in s["values"]:
                f = v["field_id"]
                if f.startswith(SKIP):
                    continue
                x = fmt(v)
                if v.get("type") == "id" and x in orgs:
                    x = f"{x}:{orgs[x]}"
                vals.append(f"{f.replace('TED-','')}={x[:maxlen]}")
            print(f"   [{s['kind']} {s['section_id']} <{s.get('parent_section_id')}>] " + " | ".join(vals))


if __name__ == "__main__":
    ml = 400
    args = sys.argv[1:]
    if args and args[0].startswith("--max="):
        ml = int(args[0][6:])
        args = args[1:]
    for a in args:
        dump(int(a), ml)
