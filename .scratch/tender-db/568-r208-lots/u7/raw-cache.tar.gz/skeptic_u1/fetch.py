#!/usr/bin/env python3
"""Skeptic u1 fetcher: GET /v1/tenders/{id} and every version's notice content.

At most 1 GET per 1.5 s; a 408 retried once, never more. Writes only under ./cache.
"""
import json, os, subprocess, sys, time

BASE = "https://tenders.zebreus.click"
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")
os.makedirs(CACHE, exist_ok=True)
_last = [0.0]


def get(path):
    fn = os.path.join(CACHE, path.strip("/").replace("/", "_") + ".json")
    if os.path.exists(fn):
        return json.load(open(fn))
    for attempt in range(2):
        wait = _last[0] + 1.55 - time.time()
        if wait > 0:
            time.sleep(wait)
        _last[0] = time.time()
        out = subprocess.run(
            ["curl", "-sS", "-w", "\n%{http_code}", BASE + path],
            capture_output=True, text=True, timeout=120,
        ).stdout
        body, _, code = out.rpartition("\n")
        if code == "200":
            open(fn, "w").write(body)
            return json.loads(body)
        print(f"{path} -> {code}", file=sys.stderr)
        if code != "408":
            return None
    return None


def main(ids):
    for tid in ids:
        t = get(f"/v1/tenders/{tid}")
        if not t:
            continue
        nids = set()
        for v in t.get("versions") or []:
            if v.get("caused_by_notice_id"):
                nids.add(v["caused_by_notice_id"])
        for r in t.get("lot_results") or []:
            if r.get("notice_id"):
                nids.add(r["notice_id"])
        for nid in sorted(nids):
            get(f"/v1/notices/{nid}/content")
        print(tid, sorted(nids), flush=True)


if __name__ == "__main__":
    main([int(x) for x in sys.argv[1:]])
