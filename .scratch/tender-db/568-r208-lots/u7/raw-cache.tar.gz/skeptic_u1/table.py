#!/usr/bin/env python3
"""Per-block table: printed LN, CONTRACT_TITLE, served lot, CN lot (by LOT_NUMBER) title/value, block values."""
import json, os, sys, re

HERE = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(HERE, "cache")


def load(name):
    fn = os.path.join(C, name)
    return json.load(open(fn)) if os.path.exists(fn) else None


def norm(s):
    s = (s or "").strip()
    return s.lstrip("0") or s


def secvals(s, fid):
    out = []
    for v in s["values"]:
        if v["field_id"] == fid:
            out.append(v.get("cents") if v.get("type") == "amount" else v.get("value"))
    return out


def blocks(tid):
    t = load(f"v1_tenders_{tid}.json")
    nids = sorted({v["caused_by_notice_id"] for v in t.get("versions") or [] if v.get("caused_by_notice_id")} |
                  {r["notice_id"] for r in t.get("lot_results") or [] if r.get("notice_id")})
    cnlots = {}
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        for s in n["sections"]:
            if s["kind"] == "Lot":
                ln = secvals(s, "TED-LOT_NUMBER")
                cnlots.setdefault(s["section_id"], []).append(dict(
                    nid=nid, ln=ln[0] if ln else None,
                    title=" | ".join(x for x in secvals(s, "TED-LOT_TITLE") if x),
                    desc=" | ".join(x for x in secvals(s, "TED-LOT_DESCRIPTION") if x),
                    value=(secvals(s, "TED-VALUE_COST") or secvals(s, "TED-VALUE") or [None])[0]))
    res = {(r["notice_id"], r["key"]): r for r in t.get("lot_results") or []}
    out = []
    for nid in nids:
        n = load(f"v1_notices_{nid}_content.json")
        for s in n["sections"]:
            if s["kind"] != "LotResult":
                continue
            r = res.get((nid, s["section_id"]))
            ln = secvals(s, "TED-LOT_NUMBER")
            out.append(dict(
                nid=nid, key=s["section_id"], printed=ln[0] if ln else None,
                title=" | ".join(x for x in secvals(s, "TED-CONTRACT_TITLE") + secvals(s, "TED-TITLE_CONTRACT") if x),
                cno=secvals(s, "TED-CONTRACT_NUMBER") + secvals(s, "TED-CONTRACT_NO"),
                est=secvals(s, "TED-INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT.VALUE_COST"),
                val=secvals(s, "TED-VALUE_COST"),
                served=r and r["lot"], awarded=r and (r.get("awarded") or {}).get("cents"),
                dec=r and r.get("decision")))
    return t, cnlots, out


if __name__ == "__main__":
    for a in sys.argv[1:]:
        t, cn, bl = blocks(int(a))
        print(f"### {a} lots={len(t.get('lot_details') or [])} cnlots={len(cn)}")
        for b in bl:
            c = (cn.get(b["served"]) or [{}])[-1]
            print(f"{b['key']:>6} LN={b['printed']!s:>4} -> {b['served']} aw={b['awarded']} est={b['est']} cno={b['cno']} | T: {b['title'][:120]}")
            print(f"        CN[{c.get('ln')}] v={c.get('value')} T: {(c.get('title') or '')[:100]} D: {(c.get('desc') or '')[:120]}")
